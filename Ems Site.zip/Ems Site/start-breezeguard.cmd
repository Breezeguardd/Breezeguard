@echo off
REM ============================================================================
REM  Breezeguard - start the storefront and its database.
REM  Double-click this file, or run:  node breezeguard-db\start.mjs
REM  Keep this window open while you work. Ctrl+C or closing it stops the server.
REM ============================================================================

cd /d "%~dp0"
node "breezeguard-db\start.mjs"

echo.
echo   The server has stopped.
pause