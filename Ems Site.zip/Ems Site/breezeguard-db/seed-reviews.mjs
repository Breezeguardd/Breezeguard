/* Seeds demo customer reviews for the product page.
   Run once: node seed-reviews.mjs   (safe to re-run, it clears and rewrites)   */
import { DatabaseSync } from 'node:sqlite';

const db = new DatabaseSync('store.sqlite');

db.exec(`CREATE TABLE IF NOT EXISTS product_reviews (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id   TEXT    NOT NULL,
  author       TEXT    NOT NULL,
  email        TEXT    NOT NULL DEFAULT '',
  rating       INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title        TEXT    NOT NULL DEFAULT '',
  body         TEXT    NOT NULL DEFAULT '',
  is_verified  INTEGER NOT NULL DEFAULT 0 CHECK (is_verified IN (0,1)),
  is_published INTEGER NOT NULL DEFAULT 1 CHECK (is_published IN (0,1)),
  created_at   TEXT    NOT NULL DEFAULT (datetime('now'))
);`);

const daysAgo = n => `datetime('now', '-${n} days')`;

/* author, email, rating, title, body, verified, days old */
const ROWS = [
  ['classic', 'Mara L.',   'mara.l@example.com',   5, '',
   'Ang ganda ng airflow, hindi na ako kinakagat sa lalamunan. Naglalaro kami ng mahjong tuwing gabi at nakatira na kami sa sala.', 1, 34],
  ['classic', 'Jomar R.',  'jomar.r@example.com',  5, '',
   'We use one in the sala and one outside. Two months of nightly use, zero problems. The battery lasts about three weeks on one charge.', 1, 27],
  ['classic', 'Alyssa P.', 'alyssa.p@example.com', 4, '',
   'Works well. I only wish the cable were longer for our extension setup. The fan hum is barely noticeable once it is running.', 1, 21],
  ['classic', 'Rhea T.',   '',                     5, '',
   'Recycled paper, no plastic, and the guide was actually useful. Set it up in under two minutes.', 0, 16],
  ['classic', 'Dennis C.', '', 4, '',
   'Bought this instead of a coil because I did not want smoke in a small room. No more ash, no more stubbing out a coil at 2am.', 0, 12],
  ['classic', 'Sofia B.',  '',                     5, '',
   'My two kids stop asking me to close the window. That alone was worth the price.', 0, 8],
  ['classic', 'Paolo V.',  '',                     3, '',
   'The device itself feels solid and well made. I think I just use it more than the average person, so eight hours per pad goes quickly.', 0, 4],

  ['twin', 'Grace M.',   'grace.m@example.com',  5, '',
   'The two-chamber run means I do not wake up at 3am to swap anything. Both units have been running every night for six weeks.', 1, 30],
  ['twin', 'Carlo S.',   '',                     4, '',
   'I work nights so sleeping through the day matters. These two have been solid.', 0, 11],

  ['mini', 'Jun P.',     '',                     4, '',
   'Bought one for the van. Half the size of the Classic and it still clears a whole vehicle. Battery is the trade-off, lasts about four nights.', 0, 19],
  ['mini', 'Bea O.',     '',                     5, '',
   'Fits in a carry-on with room to spare. I keep one in the car and one in my hotel bag.', 0, 6],

  ['deck', 'Tina A.',    'tina.a@example.com',   5, '',
   'It sits on our veranda permanently. Rain, humidity, sun. Still looks new after a year on the balcony.', 1, 40],
  ['deck', 'Mark H.',    '',                     5, '',
   'Longer pads means I do not have to remember a refill schedule. Very happy with it.', 0, 14],

  ['kit', 'Elena G.',   'elena.g@example.com',  5, '',
   'Bought the kit for our two rooms. The twenty pads are what sold me, they last a long time and the paper sleeve is recyclable.', 1, 23],
  ['kit', 'Rob D.',     '',                     4, '',
   'Two units plus pads at that price works out well. Delivery to our province took four days.', 0, 9],

  ['refill', 'Liza F.',  '',                    5, '',
   'Consistent every time. No leaking, no odd smell, and the sleeve is paper not plastic.', 0, 18],
  ['refill', 'Nico B.',  '',                    4, '',
   'Ten pads for the price of three from the mall. Will keep buying these.', 0, 5],
];

db.exec('DELETE FROM product_reviews');
const ins = db.prepare(
  `INSERT INTO product_reviews (product_id, author, email, rating, title, body, is_verified, created_at)
   VALUES (?,?,?,?,?,?,?,${daysAgo('?')})`.replace("datetime('now', '-? days')", "datetime('now', ?)"));

for (const [pid, author, email, rating, title, body, verified, age] of ROWS) {
  ins.run(pid, author, email, rating, title, body, verified, `-${age} days`);
}

const byProduct = db.prepare(
  `SELECT product_id, COUNT(*) count, ROUND(AVG(rating),2) avg
     FROM product_reviews WHERE is_published = 1 GROUP BY product_id ORDER BY product_id`).all();

console.log(`seeded ${ROWS.length} reviews`);
for (const r of byProduct) console.log(`  ${r.product_id.padEnd(8)} ${String(r.count).padStart(2)} reviews · ${r.avg} average`);