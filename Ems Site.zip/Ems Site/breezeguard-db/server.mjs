/* ============================================================================
   BREEZEGUARD — store API + static host
   Zero dependencies: Node's built-in http + node:sqlite.

   Run:   node server.mjs        →  http://localhost:3000
   Then:  storefront  http://localhost:3000/
          dashboard   http://localhost:3000/admin

   Serves the static site from ../breezeguard so the SAME pages you uploaded to
   Netlify now save real orders into store.sqlite.
   ========================================================================== */
import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { extname, join, normalize, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
// SITE and PORT can be overridden by environment variables, so the folder can be
// renamed or moved without editing this file. The defaults are the normal layout.
const SITE = process.env.SITE ? resolve(process.env.SITE) : join(HERE, '..', 'breezeguard');
const ADMIN = join(HERE, 'admin');                      // the dashboard
const DB_FILE = process.env.DB_FILE ? resolve(process.env.DB_FILE) : join(HERE, 'store.sqlite');
const PORT = Number(process.env.PORT || 3000);

if (!existsSync(DB_FILE)) {
  console.error('\n  No database yet. Run:  node seed.mjs\n');
  process.exit(1);
}

const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA foreign_keys = ON;');

/* Tiny forward-only migrations: SQLite cannot add columns to an existing table
   with CREATE TABLE IF NOT EXISTS, so check and patch what is missing. */
function addColumnIfMissing(table, column, definition) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
  if (!cols.length || cols.includes(column)) return false;
  db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  console.log(`  migrated: ${table}.${column}`);
  return true;
}
addColumnIfMissing('order_items', 'variant_id', 'INTEGER REFERENCES product_variants(id) ON DELETE SET NULL');
/* A bundle option can either carry its own price, or a markup added to the
   parent product's price. The markup is what keeps "+10 pads" in step when the
   unit is repriced, so those rows get one backfilled on first run. */
addColumnIfMissing('product_variants', 'markup', 'INTEGER');
/* "Unit + N pads" should follow the price of the refill product, so a change
   to that one row moves every bundle that includes pads. */
addColumnIfMissing('product_variants', 'bundle_ref', 'TEXT');
addColumnIfMissing('product_variants', 'bundle_qty', 'INTEGER');
db.exec(`UPDATE product_variants SET bundle_ref = 'BG-RFL-10',
                                   bundle_qty = CAST(substr(sku, -3) AS INTEGER) / 10
          WHERE bundle_ref IS NULL AND sku LIKE '%-K10'`);
db.exec(`UPDATE product_variants SET bundle_ref = 'BG-RFL-10',
                                   bundle_qty = CAST(substr(sku, -3) AS INTEGER) / 10
          WHERE bundle_ref IS NULL AND sku LIKE '%-K20'`);
/* Backfill once: an option that shares its unit's SKU is a plain mirror and
   should follow it exactly (markup 0); anything else keeps its difference as
   a markup. */
db.exec(`UPDATE product_variants SET markup = 0
          WHERE markup IS NULL
            AND sku = (SELECT p.sku FROM products p WHERE p.id = product_variants.product_id)`);
db.exec(`UPDATE product_variants
            SET markup = price - (SELECT p.price FROM products p WHERE p.id = product_variants.product_id)
          WHERE markup IS NULL
            AND price > (SELECT p.price FROM products p WHERE p.id = product_variants.product_id)`);

/* New tables are also created here, so an existing store.sqlite picks them up on
   restart without needing a re-seed. CREATE TABLE IF NOT EXISTS is idempotent. */
db.exec(`CREATE TABLE IF NOT EXISTS message_replies (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id INTEGER NOT NULL REFERENCES contact_messages(id) ON DELETE CASCADE,
  body       TEXT    NOT NULL,
  author     TEXT    NOT NULL DEFAULT 'Breezeguard',
  created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_replies_message ON message_replies(message_id, created_at);`);

/* customer reviews + the summary view the product page reads */
db.exec(`CREATE TABLE IF NOT EXISTS product_reviews (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id   TEXT    NOT NULL,
  author       TEXT    NOT NULL,
  email        TEXT    NOT NULL DEFAULT '',
  rating       INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title        TEXT    NOT NULL DEFAULT '',
  body         TEXT    NOT NULL DEFAULT '',
  is_verified  INTEGER NOT NULL DEFAULT 0 CHECK (is_verified IN (0,1)),
  is_published INTEGER NOT NULL DEFAULT 1 CHECK (is_published IN (0,1)),
  created_at   TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON product_reviews(product_id, is_published, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_reviews_one_per_email ON product_reviews(product_id, email) WHERE email <> '';
CREATE VIEW IF NOT EXISTS v_review_summary AS
SELECT product_id,
       COUNT(*)              AS count,
       ROUND(AVG(rating), 2) AS average,
       SUM(rating = 5)       AS five,
       SUM(rating = 4)       AS four,
       SUM(rating = 3)       AS three,
       SUM(rating = 2)       AS two,
       SUM(rating = 1)       AS one
FROM product_reviews
WHERE is_published = 1
GROUP BY product_id;`);

/* review slugs must match the storefront's product ids */
const REVIEW_PRODUCTS = ['classic', 'twin', 'mini', 'deck', 'kit', 'refill'];

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp',
  '.json': 'application/json; charset=utf-8', '.xml': 'application/xml', '.txt': 'text/plain; charset=utf-8'
};

/* ------------------------------------------------------------- helpers --- */
const all = (sql, ...p) => db.prepare(sql).all(...p);
const get = (sql, ...p) => db.prepare(sql).get(...p);
const run = (sql, ...p) => db.prepare(sql).run(...p);
const setting = (k, fb) => (get('SELECT value FROM settings WHERE key = ?', k)?.value ?? fb);
/* What a bundle option actually sells for. A "bundle_ref" says "whatever the
   unit costs, plus N of this other product", so "+10 pads" always tracks the
   price you set on the refill product itself. A plain markup is the fallback
   for options with nothing to track. The storefront and the order endpoint
   both call this, so the advertised price and the charged price can never
   drift apart. */
const variantPrice = (v, parent, priceOf = () => null) => {
  const unit = parent?.price ?? 0;
  if (v.bundle_ref && v.bundle_qty > 0) {
    const p = priceOf(v.bundle_ref);
    if (p != null) return Math.max(0, unit + p * v.bundle_qty);
  }
  if (v.markup != null) return Math.max(0, unit + v.markup);
  return v.price;
};
const int = (v, fb = 0) => (Number.isFinite(Number(v)) ? Math.trunc(Number(v)) : fb);
/* flags arrive as booleans from the form switches and as 0/1 from the quick
   action buttons - a plain `=== false` check silently rejects the numeric 0 */
const flag = (v, fb = 1) => (v === undefined || v === null || v === '' ? fb : (v === true || v === 1 || v === '1' || v === 'true' ? 1 : 0));
const num = (v, fb = 0) => (Number.isFinite(Number(v)) ? Number(v) : fb);

function send(res, code, data, headers = {}) {
  const body = typeof data === 'string' || Buffer.isBuffer(data) ? data : JSON.stringify(data);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(body);
}
const ok = (res, data) => send(res, 200, data);
const created = (res, data) => send(res, 201, data);
const bad = (res, msg, code = 400) => send(res, code, { error: msg });

async function readBody(req) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > 1_000_000) throw new Error('payload too large');
    chunks.push(c);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw new Error('invalid JSON'); }
}

/* order numbers: readable, collision-checked */
function newOrderNo() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let attempt = 0; attempt < 40; attempt++) {
    let s = 'BG-';
    for (let i = 0; i < 6; i++) s += alphabet[Math.floor(Math.random() * alphabet.length)];
    if (!get('SELECT 1 x FROM orders WHERE order_no = ?', s)) return s;
  }
  return 'BG-' + Date.now().toString(36).toUpperCase();
}

/* ---------------------------------------------------------------- API ---- */
const api = {

  /* ---- health + stats ---- */
  'GET /api/health': () => ({ ok: true, db: 'store.sqlite', time: new Date().toISOString() }),

  'GET /api/stats': () => {
    const k = get('SELECT * FROM v_kpis');
    // cancelled orders are not revenue - these two must agree with v_kpis
    // and with the chart, which both exclude them
    const NOT_CANCELLED = "status <> 'cancelled'";
    const today = get(`SELECT COUNT(*) c, COALESCE(SUM(total),0) r FROM orders WHERE ${NOT_CANCELLED} AND date(created_at) = date('now')`);
    const month = get(`SELECT COUNT(*) c, COALESCE(SUM(total),0) r FROM orders WHERE ${NOT_CANCELLED} AND created_at >= date('now','-30 day')`);
    const daily = all('SELECT day, orders, revenue FROM v_daily_revenue');
    const byStatus = all('SELECT status, COUNT(*) c, COALESCE(SUM(total),0) r FROM orders GROUP BY status');
    const top = all('SELECT id, name, price, stock, units_sold, revenue FROM v_top_products LIMIT 6');
    const lowStock = all('SELECT id, name, sku, stock, low_stock_at FROM products WHERE is_active = 1 AND stock <= low_stock_at ORDER BY stock ASC');
    const recent = all(`SELECT o.id, o.order_no, o.customer_name, o.total, o.status, o.created_at,
                               (SELECT COUNT(*) FROM order_items i WHERE i.order_id = o.id) AS lines
                        FROM orders o ORDER BY o.id DESC LIMIT 8`);
    const series = [];
    // revenue per day, split by status, so the chart can stack the bands
    const dailyStatus = all(`SELECT date(created_at) AS day, status,
                                    COALESCE(SUM(total),0) AS revenue, COUNT(*) AS orders
                             FROM orders WHERE ${NOT_CANCELLED} GROUP BY day, status`);
    for (let i = 29; i >= 0; i--) {
      const d = new Date(Date.now() - i * 864e5).toISOString().slice(0, 10);
      const hit = daily.find(x => x.day === d);
      const parts = {};
      for (const row of dailyStatus) if (row.day === d) parts[row.status] = row.revenue;
      series.push({ day: d, revenue: hit?.revenue ?? 0, orders: hit?.orders ?? 0, parts });
    }
    const methods = all('SELECT payment_method m, COUNT(*) c FROM orders GROUP BY payment_method ORDER BY c DESC');
    const cities = all('SELECT city, COUNT(*) c FROM orders WHERE city IS NOT NULL GROUP BY city ORDER BY c DESC LIMIT 6');
    return {
      kpis: { ...k, revenue_today: today.r, orders_today: today.c, revenue_30d: month.r, orders_30d: month.c },
      series, byStatus, top, lowStock, recent, methods, cities,
      inventory_value: get('SELECT COALESCE(SUM(price * stock),0) v FROM products').v
    };
  },

  /* ---- settings ---- */
  'GET /api/settings': () => {
    const rows = all('SELECT key, value FROM settings');
    const out = {};
    for (const r of rows) {
      const n = Number(r.value);
      out[r.key] = r.value !== '' && Number.isFinite(n) ? n : r.value;
    }
    return out;
  },
  'PATCH /api/settings': (body) => {
    const allowed = ['store_name', 'announcement', 'announcement_active', 'free_shipping_threshold',
      'shipping_metro', 'shipping_provincial', 'currency', 'support_email', 'support_phone', 'hero_headline', 'hero_subtext'];
    const changed = [];
    for (const [k, v] of Object.entries(body || {})) {
      if (!allowed.includes(k)) continue;
      run('INSERT INTO settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', k, String(v));
      changed.push(k);
    }
    if (changed.length) broadcast('settings');
    return { updated: changed, settings: api['GET /api/settings']() };
  },

  /* ---- products ---- */
  'GET /api/products': (q) => {
    const search = `%${(q.search || '').trim()}%`;
    const category = q.category || '';
    const active = q.active;
    let sql = `SELECT p.*, (SELECT COALESCE(SUM(i.qty),0) FROM order_items i WHERE i.product_id = p.id) AS units_sold
               FROM products p WHERE (p.name LIKE ? OR p.sku LIKE ? OR p.slug LIKE ?)`;
    const args = [search, search, search];
    if (category) { sql += ' AND p.category = ?'; args.push(category); }
    if (active === '1') sql += ' AND p.is_active = 1';
    if (active === '0') sql += ' AND p.is_active = 0';
    sql += ' ORDER BY p.is_active DESC, p.id ASC';
    return all(sql, ...args);
  },
  'GET /api/products/:id': ({ id }) => {
    const p = get('SELECT * FROM products WHERE id = ?', int(id));
    if (!p) throw { status: 404, error: 'Product not found' };
    return p;
  },
  'POST /api/products': (body) => {
    const b = body || {};
    if (!b.name || !b.sku) throw { status: 400, error: 'name and sku are required' };
    if (get('SELECT 1 x FROM products WHERE sku = ?', b.sku)) throw { status: 409, error: 'That SKU already exists' };
    const slug = (b.slug || b.name).toString().trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const r = run(`INSERT INTO products (sku, slug, name, tagline, description, price, compare_price,
                     category, image, burn_hours, stock, low_stock_at, is_active)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      b.sku, slug, b.name, b.tagline || '', b.description || '', Math.max(0, int(b.price)), b.compare_price ? Math.max(0, int(b.compare_price)) : null,
      b.category || 'holder', b.image || 'product-classic.png', b.burn_hours ? int(b.burn_hours) : null,
      Math.max(0, int(b.stock)), Math.max(0, int(b.low_stock_at, 10)), flag(b.is_active));
    return api['GET /api/products/:id']({ id: r.lastInsertRowid });
  },
  'PATCH /api/products/:id': ({ id, ...body }) => {
    const p = api['GET /api/products/:id']({ id });
    const b = body || {};
    run(`UPDATE products SET name = ?, tagline = ?, description = ?, price = ?, compare_price = ?,
           category = ?, image = ?, burn_hours = ?, stock = ?, low_stock_at = ?, is_active = ?
         WHERE id = ?`,
      b.name ?? p.name, b.tagline ?? p.tagline, b.description ?? p.description,
      Math.max(0, int(b.price, p.price)), b.compare_price === '' || b.compare_price == null ? null : Math.max(0, int(b.compare_price)),
      b.category ?? p.category, b.image ?? p.image,
      b.burn_hours === '' || b.burn_hours == null ? null : int(b.burn_hours),
      Math.max(0, int(b.stock, p.stock)), Math.max(0, int(b.low_stock_at, p.low_stock_at)),
      flag(b.is_active, p.is_active), p.id);
    return api['GET /api/products/:id']({ id: p.id });
  },
  'POST /api/products/:id/adjust': ({ id, delta }) => {
    const p = api['GET /api/products/:id']({ id });
    const next = Math.max(0, p.stock + int(delta));
    run('UPDATE products SET stock = ? WHERE id = ?', next, p.id);
    return { id: p.id, stock: next };
  },
  'DELETE /api/products/:id': ({ id }) => {
    const p = api['GET /api/products/:id']({ id });
    run('UPDATE products SET is_active = 0 WHERE id = ?', p.id);
    return { id: p.id, is_active: 0, note: 'archived (is_active = 0) — order history keeps its snapshot' };
  },
  'POST /api/products/:id/restore': ({ id }) => {
    const p = api['GET /api/products/:id']({ id });
    run('UPDATE products SET is_active = 1 WHERE id = ?', p.id);
    return { id: p.id, is_active: 1 };
  },
  'DELETE /api/products/:id/purge': ({ id }) => {
    const p = api['GET /api/products/:id']({ id });
    run('DELETE FROM products WHERE id = ?', p.id);
    return { id: p.id, deleted: true, note: 'row removed; past order items keep their snapshot' };
  },

  /* ---- orders ---- */
  'GET /api/orders': (q) => {
    const search = `%${(q.search || '').trim()}%`;
    const status = q.status || '';
    let sql = `SELECT o.*, (SELECT COUNT(*) FROM order_items i WHERE i.order_id = o.id) AS line_count
               FROM orders o WHERE (o.order_no LIKE ? OR o.customer_name LIKE ? OR o.email LIKE ?)`;
    const args = [search, search, search];
    if (status && status !== 'all') { sql += ' AND o.status = ?'; args.push(status); }
    sql += ' ORDER BY o.id DESC LIMIT ?';
    args.push(Math.min(500, int(q.limit, 100)));
    return all(sql, ...args);
  },
  'GET /api/orders/:id': ({ id }) => {
    const o = get('SELECT * FROM orders WHERE id = ?', int(id));
    if (!o) throw { status: 404, error: 'Order not found' };
    o.items = all('SELECT * FROM order_items WHERE order_id = ? ORDER BY id', o.id);
    o.events = all('SELECT * FROM order_events WHERE order_id = ? ORDER BY created_at, id', o.id);
    return o;
  },
  /* the storefront calls this when a customer checks out.
     Totals are recomputed server-side — the browser's numbers are never trusted. */
  'POST /api/orders': (body) => {
    const b = body || {};
    const c = b.customer || {};
    if (!c.name || !c.email) throw { status: 400, error: 'Customer name and email are required' };
    if (!Array.isArray(b.items) || !b.items.length) throw { status: 400, error: 'Cart is empty' };

    const products = all('SELECT id, sku, name, price, stock, is_active FROM products');
    const bySku = new Map(products.map(p => [p.sku, p]));
    // sellable options (bundle pricing) — resolved first, so the browser can
    // never talk us into a different price
    const variants = all('SELECT id, product_id, sku, label, price, markup, bundle_ref, bundle_qty, stock, is_active FROM product_variants WHERE is_active = 1');
    const variantBySku = new Map(variants.map(v => [v.sku, v]));
    const priceOfSku = sku => bySku.get(sku)?.price;

    let subtotal = 0;
    const lines = b.items.map(i => {
      const variant = i.variant_sku ? variantBySku.get(i.variant_sku) : null;
      const p = variant
        ? products.find(x => x.id === variant.product_id)
        : (i.sku ? bySku.get(i.sku) : products.find(x => x.id === int(i.product_id)));
      const providedVariant = String(i.variant || '');
      const optionLabel = variant?.label || '';
      // keep whatever the page described, but never lose the option name
      const variantText = (providedVariant && optionLabel && !providedVariant.toLowerCase().includes(optionLabel.toLowerCase()))
        ? `${providedVariant} · ${optionLabel}`
        : (providedVariant || optionLabel);
      // never trust a price from the browser; a bundle follows its unit's price
      const unit = variant ? variantPrice(variant, p, priceOfSku) : (p ? p.price : int(i.unit_price));
      const qty = Math.max(1, int(i.qty, 1));

      // stock is checked here so the shop cannot be oversold from the cart.
      // a variant with its own stock count limits that option; otherwise the
      // product decides.
      const limit = variant && variant.stock !== null ? variant.stock : (p ? p.stock : null);
      if (limit !== null && limit < qty) {
        throw { status: 409, error: limit === 0
          ? `${p?.name || 'That item'} is out of stock`
          : `Only ${limit} left of ${p?.name || 'that item'}` };
      }

      subtotal += unit * qty;
      return {
        product_id: p?.id ?? null,
        variant_id: variant?.id ?? null,
        name: p?.name || i.name || 'Item',
        variant: variantText,
        unit_price: unit, qty, line_total: unit * qty
      };
    });

    // coupon, validated against the coupons table
    let discount = 0, couponCode = null;
    if (b.coupon_code) {
      const cp = get('SELECT * FROM coupons WHERE code = ? AND is_active = 1', String(b.coupon_code).toUpperCase());
      if (cp) {
        couponCode = cp.code;
        discount = cp.kind === 'pct' ? Math.round(subtotal * cp.value / 100) : Math.min(cp.value, subtotal);
      }
    }

    // shipping, from settings
    const method = ['metro', 'provincial', 'pickup'].includes(b.shipping_method) ? b.shipping_method : 'metro';
    const threshold = int(setting('free_shipping_threshold', '1500'));
    const base = method === 'metro' ? int(setting('shipping_metro', '59'))
      : method === 'provincial' ? int(setting('shipping_provincial', '129')) : 0;
    const shipping_fee = (subtotal - discount) >= threshold ? 0 : base;
    const total = Math.max(0, subtotal - discount + shipping_fee);

    // customer, reused by email
    let cust = get('SELECT id FROM customers WHERE lower(email) = lower(?)', c.email);
    if (!cust) run('INSERT INTO customers (name,email,phone,city) VALUES (?,?,?,?)', c.name, c.email, c.phone || null, c.city || null);
    if (!cust) broadcast('customers');   // a genuinely new customer
    const customer_id = cust ? cust.id : get('SELECT id FROM customers WHERE lower(email) = lower(?)', c.email).id;

    const order_no = newOrderNo();
    const r = run(`INSERT INTO orders (order_no, customer_id, customer_name, email, phone, address, city, zip, notes,
                      payment_method, shipping_method, subtotal, discount, shipping_fee, total, coupon_code, status)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'pending')`,
      order_no, customer_id, c.name, c.email, c.phone || null, c.address || null, c.city || null, c.zip || null,
      b.notes || null, b.payment_method || 'cod', method, subtotal, discount, shipping_fee, total, couponCode);

    const orderId = r.lastInsertRowid;
    for (const l of lines) {
      run(`INSERT INTO order_items (order_id, product_id, variant_id, product_name, variant, unit_price, qty, line_total)
           VALUES (?,?,?,?,?,?,?,?)`, orderId, l.product_id, l.variant_id, l.name, l.variant, l.unit_price, l.qty, l.line_total);
      if (l.product_id) run('UPDATE products SET stock = MAX(0, stock - ?) WHERE id = ?', l.qty, l.product_id);
    }
    run('INSERT INTO order_events (order_id, status, note) VALUES (?,?,?)', orderId, 'pending', 'Order received from the website');
    broadcast('orders');

    return api['GET /api/orders/:id']({ id: orderId });
  },
  'PATCH /api/orders/:id': ({ id, ...body }) => {
    const o = api['GET /api/orders/:id']({ id });
    const b = body || {};
    const statuses = ['pending', 'paid', 'packed', 'shipped', 'delivered', 'cancelled'];
    const nextStatus = statuses.includes(b.status) ? b.status : o.status;
    run(`UPDATE orders SET customer_name = ?, email = ?, phone = ?, address = ?, city = ?, zip = ?, notes = ?,
           payment_method = ?, status = ? WHERE id = ?`,
      b.customer_name ?? o.customer_name, b.email ?? o.email, b.phone ?? o.phone, b.address ?? o.address,
      b.city ?? o.city, b.zip ?? o.zip, b.notes ?? o.notes, b.payment_method ?? o.payment_method, nextStatus, o.id);

    if (nextStatus !== o.status) {
      const notes = { pending: 'Order placed', paid: 'Payment confirmed', packed: 'Packed at the workshop', shipped: 'Handed to courier', delivered: 'Delivered — thank you!', cancelled: 'Order cancelled' };
      run('INSERT INTO order_events (order_id, status, note) VALUES (?,?,?)', o.id, nextStatus, notes[nextStatus]);
      // returning stock when an order is cancelled
      if (nextStatus === 'cancelled' && o.status !== 'cancelled') {
        for (const it of o.items) if (it.product_id) run('UPDATE products SET stock = stock + ? WHERE id = ?', it.qty, it.product_id);
      }
    }
    return api['GET /api/orders/:id']({ id: o.id });
  },
  'DELETE /api/orders/:id': ({ id }) => {
    const o = api['GET /api/orders/:id']({ id });
    // a cancelled order already handed its stock back when the status changed -
    // crediting it again here would count the same units twice
    if (o.status !== 'cancelled') {
      for (const it of o.items) if (it.product_id) run('UPDATE products SET stock = stock + ? WHERE id = ?', it.qty, it.product_id);
    }
    run('DELETE FROM orders WHERE id = ?', o.id);   // items + events cascade
    return { id: o.id, deleted: true, order_no: o.order_no };
  },

  /* ---- customers ---- */
  'GET /api/customers': () => all(`SELECT c.*,
      (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id) AS order_count,
      (SELECT COALESCE(SUM(o.total),0) FROM orders o WHERE o.customer_id = c.id AND o.status <> 'cancelled') AS spent,
      (SELECT MAX(o.created_at) FROM orders o WHERE o.customer_id = c.id) AS last_order
    FROM customers c ORDER BY spent DESC, c.id DESC`),
  'PATCH /api/customers/:id': ({ id, ...body }) => {
    const c = get('SELECT * FROM customers WHERE id = ?', int(id));
    if (!c) throw { status: 404, error: 'Customer not found' };
    const b = body || {};
    run('UPDATE customers SET name = ?, email = ?, phone = ?, city = ? WHERE id = ?',
      b.name ?? c.name, b.email ?? c.email, b.phone ?? c.phone, b.city ?? c.city, c.id);
    broadcast('customers');
    return get('SELECT * FROM customers WHERE id = ?', c.id);
  },
  'DELETE /api/customers/:id': ({ id }) => {
    run('DELETE FROM customers WHERE id = ?', int(id));
    broadcast('customers');
    return { id: int(id), deleted: true };
  },

  /* ---- messages ---- */
  'GET /api/messages': () => all(`SELECT m.*,
      (SELECT COUNT(*) FROM message_replies r WHERE r.message_id = m.id) AS reply_count,
      (SELECT r.created_at FROM message_replies r WHERE r.message_id = m.id ORDER BY r.id DESC LIMIT 1) AS last_reply_at
    FROM contact_messages m ORDER BY m.is_read, m.created_at DESC`),
  'PATCH /api/messages/:id': ({ id, ...b }) => {
    run('UPDATE contact_messages SET is_read = ? WHERE id = ?', b.is_read ? 1 : 0, int(id));
    return get('SELECT * FROM contact_messages WHERE id = ?', int(id));
  },
  'DELETE /api/messages/:id': ({ id }) => { run('DELETE FROM contact_messages WHERE id = ?', int(id)); return { id: int(id), deleted: true }; },

  /* ---- replies to contact messages ---- */
  'GET /api/messages/:id/replies': ({ id }) =>
    all('SELECT * FROM message_replies WHERE message_id = ? ORDER BY created_at, id', int(id)),
  'POST /api/messages/:id/replies': ({ id, ...b }) => {
    const body = String(b.body ?? b.reply ?? '').trim();
    if (!body) throw { status: 400, error: 'Write a reply first' };
    if (body.length > 4000) throw { status: 400, error: 'Reply is too long (4000 characters max)' };
    if (!get('SELECT 1 x FROM contact_messages WHERE id = ?', int(id))) throw { status: 404, error: 'Message not found' };
    run('INSERT INTO message_replies (message_id, body, author) VALUES (?,?,?)', int(id), body, String(b.author || 'Breezeguard'));
    // answering a message counts as reading it
    run('UPDATE contact_messages SET is_read = 1 WHERE id = ?', int(id));
    const reply = get('SELECT * FROM message_replies WHERE message_id = ? ORDER BY id DESC LIMIT 1', int(id));
    return { reply, sent: true };
  },
  'DELETE /api/replies/:id': ({ id }) => { run('DELETE FROM message_replies WHERE id = ?', int(id)); return { id: int(id), deleted: true }; },

  /* ---- subscribers ---- */
  'GET /api/subscribers': () => all('SELECT * FROM subscribers ORDER BY created_at DESC'),
  'POST /api/subscribers': (body) => {
    const email = String(body?.email || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email)) throw { status: 400, error: 'Valid email required' };
    // Say honestly whether the row is new. INSERT OR IGNORE used to throw a
    // repeated address away silently and still answer "subscribed: true", so
    // signing up twice looked like it worked while nothing was ever written.
    const res = run('INSERT OR IGNORE INTO subscribers (email, source) VALUES (?,?)',
      email, body?.source || 'homepage');
    if (res.changes > 0) broadcast('subscribers');   // a genuinely new address
    return { email, subscribed: true, already: res.changes === 0 };
  },
  'DELETE /api/subscribers/:email': ({ email }) => {
    run('DELETE FROM subscribers WHERE email = ?', decodeURIComponent(email).toLowerCase());
    return { deleted: true };
  },

  /* ---- contact form ---- */
  'POST /api/contact': (body) => {
    const b = body || {};
    if (!b.name || !b.email) throw { status: 400, error: 'Name and email are required' };
    if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(String(b.email))) throw { status: 400, error: 'Valid email required' };
    const r = run('INSERT INTO contact_messages (name, email, topic, message) VALUES (?,?,?,?)',
      b.name, String(b.email).toLowerCase(), b.topic || 'General', b.message || '');
    return { id: r.lastInsertRowid, received: true };
  },

  /* ---- storefront catalogue ----------------------------------------------
     The public prices live here, so editing a price in the dashboard updates
     the shop rather than leaving the page advertising a stale number. The
     storefront polls this, so prices and stock both go live. */
  'GET /api/catalogue': () => {
    const products = all(`SELECT sku, slug, name, tagline, description, price, compare_price,
                                category, image, burn_hours, stock, is_active
                         FROM products WHERE is_active = 1 ORDER BY id`);
    const priceBySku = Object.fromEntries(products.map(p => [p.sku, p.price]));
    const priceOf = sku => priceBySku[sku];
    return {
      products,
      variants: all(`SELECT v.sku, v.label, v.price, v.markup, v.bundle_ref, v.bundle_qty,
                            v.stock, p.sku AS parent_sku, p.price AS parent_price
                       FROM product_variants v JOIN products p ON p.id = v.product_id
                      WHERE v.is_active = 1 ORDER BY v.id`)
        .map(v => ({ sku: v.sku, label: v.label, stock: v.stock,
                     price: variantPrice(v, { price: v.parent_price }, priceOf) }))
    };
  },

  /* ---- live stock for the storefront --------------------------------------
     Small payload so the shop can grey out anything the seller has set to
     zero, without the page having to know how the catalogue is structured. */
  'GET /api/stock': () => {
    const products = {};
    for (const p of all('SELECT sku, stock FROM products WHERE is_active = 1')) products[p.sku] = p.stock;
    const options = {};
    for (const v of all('SELECT sku, stock FROM product_variants WHERE is_active = 1')) options[v.sku] = v.stock;
    return { products, options, updated_at: new Date().toISOString() };
  },

  /* ---- reviews / comments ---- */
  /* Everything the dashboard needs, including the reviewer's email, which the
     public endpoint above deliberately never returns. */
  'GET /api/reviews/all': () => {
    const rows = all(`SELECT * FROM product_reviews ORDER BY created_at DESC, id DESC`);
    const summary = all('SELECT * FROM v_review_summary ORDER BY product_id');
    return {
      reviews: rows,
      summary,
      total: rows.length,
      average: summary.length
        ? Math.round((summary.reduce((n, s) => n + s.average * s.count, 0) /
            summary.reduce((n, s) => n + s.count, 0)) * 100) / 100
        : null
    };
  },
  'PATCH /api/reviews/:id': ({ id, ...b }) => {
    const r = get('SELECT * FROM product_reviews WHERE id = ?', int(id));
    if (!r) throw { status: 404, error: 'Review not found' };
    // build the SET list from whatever was actually sent, so a hide/show toggle
    // never wipes the rating and a rating change never touches visibility
    const sets = [], vals = [];
    if (b.is_published !== undefined) { sets.push('is_published = ?'); vals.push(flag(b.is_published, r.is_published)); }
    if (b.rating !== undefined && b.rating !== null && b.rating !== '') {
      const rating = int(b.rating, 0);
      if (rating < 1 || rating > 5) throw { status: 400, error: 'Rating must be between 1 and 5 stars' };
      sets.push('rating = ?'); vals.push(rating);
    }
    if (!sets.length) throw { status: 400, error: 'Nothing to change' };
    run(`UPDATE product_reviews SET ${sets.join(', ')} WHERE id = ?`, ...vals, r.id);
    broadcast('reviews');
    return get('SELECT * FROM product_reviews WHERE id = ?', r.id);
  },
  'GET /api/reviews': ({ product }) => {
    // product is optional: without it we return the summary for every product
    if (!product) {
      return all('SELECT * FROM v_review_summary ORDER BY product_id');
    }
    const list = all(
      `SELECT id, product_id, author, rating, title, body, is_verified, created_at
         FROM product_reviews
        WHERE product_id = ? AND is_published = 1
        ORDER BY is_verified DESC, created_at DESC
        LIMIT 60`, String(product));
    const s = get('SELECT * FROM v_review_summary WHERE product_id = ?', String(product));
    return { product: String(product), average: s?.average ?? null, count: s?.count ?? 0,
             breakdown: { five: s?.five ?? 0, four: s?.four ?? 0, three: s?.three ?? 0, two: s?.two ?? 0, one: s?.one ?? 0 },
             reviews: list };
  },
  'POST /api/reviews': (body) => {
    const b = body || {};
    const product = String(b.product_id || '').trim();
    if (!REVIEW_PRODUCTS.includes(product)) throw { status: 400, error: 'Unknown product' };
    const author = String(b.author || '').trim();
    const rating = int(b.rating, 0);
    const text = String(b.body || '').trim();
    if (author.length < 2) throw { status: 400, error: 'Please add your name' };
    if (rating < 1 || rating > 5) throw { status: 400, error: 'Please pick a star rating' };
    if (text.length < 10) throw { status: 400, error: 'Please write a little more about the product (at least 10 characters)' };
    if (text.length > 2000) throw { status: 400, error: 'Review is too long' };

    const email = String(b.email || '').trim().toLowerCase();
    if (email && !/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email)) throw { status: 400, error: 'Valid email required' };
    if (email && get('SELECT 1 x FROM product_reviews WHERE product_id = ? AND email = ?', product, email)) {
      throw { status: 409, error: 'You have already reviewed this product' };
    }

    const title = String(b.title || '').trim().slice(0, 120);
    // mark as verified when the email matches a real order for this product
    const verified = email ? Number(!!get(
      `SELECT 1 x FROM orders o
         JOIN order_items i ON i.order_id = o.id
        WHERE o.email = ? AND i.product_name LIKE ? AND o.status <> 'cancelled'
        LIMIT 1`, email, `%${product === 'refill' ? 'Refill' : product === 'twin' ? 'Twin' : product === 'kit' ? 'Family' : product === 'deck' ? 'Deck' : product === 'mini' ? 'Mini' : 'Classic'}%`)) : 0;

    const r = run(
      `INSERT INTO product_reviews (product_id, author, email, rating, title, body, is_verified)
       VALUES (?,?,?,?,?,?,?)`,
      product, author, email, rating, title, text, verified);
    broadcast('reviews');
    const s = get('SELECT * FROM v_review_summary WHERE product_id = ?', product);
    return { id: r.lastInsertRowid, posted: true, verified,
             average: s?.average ?? rating, count: s?.count ?? 1 };
  },
  'DELETE /api/reviews/:id': ({ id }) => {
    run('DELETE FROM product_reviews WHERE id = ?', int(id));
    broadcast('reviews');
    return { id: int(id), deleted: true };
  },

  /* ---- coupons ---- */
  'GET /api/coupons': () => all(`SELECT c.*, (SELECT COUNT(*) FROM orders o WHERE o.coupon_code = c.code) AS uses
                                 FROM coupons c ORDER BY c.created_at DESC`),
  'POST /api/coupons': (body) => {
    const b = body || {};
    if (!b.code) throw { status: 400, error: 'Code is required' };
    const code = String(b.code).toUpperCase().replace(/[^A-Z0-9_-]/g, '');
    if (!code) throw { status: 400, error: 'Code needs at least one letter or number' };
    if (get('SELECT 1 x FROM coupons WHERE code = ?', code)) throw { status: 409, error: 'That code already exists' };
    run('INSERT INTO coupons (code, kind, value, label, is_active, expires_at) VALUES (?,?,?,?,?,?)',
      code, b.kind === 'flat' ? 'flat' : 'pct', Math.max(1, int(b.value, 10)), b.label || (b.kind === 'flat' ? `₱${int(b.value, 10)} off` : `${int(b.value, 10)}% off`), flag(b.is_active), b.expires_at || null);
    broadcast('coupons');
    return get('SELECT * FROM coupons WHERE code = ?', code);
  },
  'PATCH /api/coupons/:code': ({ code, ...b }) => {
    const key = String(code).toUpperCase();
    const c = get('SELECT * FROM coupons WHERE code = ?', key);
    if (!c) throw { status: 404, error: 'Coupon not found' };
    run('UPDATE coupons SET kind = ?, value = ?, label = ?, is_active = ?, expires_at = ? WHERE code = ?',
      b.kind ?? c.kind, Math.max(1, int(b.value, c.value)), b.label ?? c.label,
      flag(b.is_active, c.is_active), b.expires_at === '' ? null : (b.expires_at ?? c.expires_at), key);
    broadcast('coupons');
    return get('SELECT * FROM coupons WHERE code = ?', key);
  },
  'DELETE /api/coupons/:code': ({ code }) => {
    run('DELETE FROM coupons WHERE code = ?', String(code).toUpperCase());
    broadcast('coupons');
    return { code: String(code).toUpperCase(), deleted: true };
  }
};

/* ------------------------------------------------- live updates (SSE) ---
   The dashboard used to poll on a timer, which meant a new subscriber or order
   sat invisible for up to six seconds. These connections let the server push a
   note the instant a row is written, so the list updates straight away. Only the
   fact that something changed goes down the wire - never the customer's details;
   the dashboard refetches those over the normal API like everything else. */
const liveClients = new Set();

function broadcast(event) {
  if (!liveClients.size) return;
  const frame = 'event: ' + event + '\ndata: {}\n\n';
  for (const res of liveClients) {
    try { res.write(frame); }
    catch { liveClients.delete(res); }
  }
}

/* ------------------------------------------------------------- routing -- */
const routes = [];
for (const key of Object.keys(api)) {
  const [method, path] = key.split(' ');
  const names = [];
  const pattern = path.replace(/:([A-Za-z_]+)/g, (_, n) => { names.push(n); return '([^/]+)'; });
  routes.push({ method, re: new RegExp('^' + pattern + '$'), names, fn: api[key] });
}

async function handleApi(req, res, url) {
  for (const r of routes) {
    if (r.method !== req.method) continue;
    const m = url.pathname.match(r.re);
    if (!m) continue;
    const params = {};
    r.names.forEach((n, i) => params[n] = decodeURIComponent(m[i + 1]));
    let body = {};
    if (req.method !== 'GET' && req.method !== 'DELETE') body = await readBody(req);
    const query = Object.fromEntries(url.searchParams);
    return r.fn({ ...params, ...query, ...body, __body: body }, res);
  }
  throw { status: 404, error: `No API route for ${req.method} ${url.pathname}` };
}

/* -------------------------------------------------------- static files -- */
const DB_MARKER = '<script>window.__BG_DB__=1</script>';

async function serveFile(res, base, rel, { injectDbMarker = false } = {}) {
  const clean = normalize(rel).replace(/^([/\\])+/, '');
  const file = join(base, clean);
  if (!file.startsWith(base)) return false;                     // path traversal guard
  try {
    let buf = await readFile(file);
    // tell the storefront a database is behind this page, so the shop never
    // has to guess (and never logs a failed request on a static host)
    if (injectDbMarker && file.endsWith('.html')) {
      buf = Buffer.from(buf.toString('utf8').replace('</head>', DB_MARKER + '</head>'), 'utf8');
    }
    res.writeHead(200, { 'Content-Type': TYPES[extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(buf);
    return true;
  } catch { return false; }
}

createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  /* The live stream. Handled before the JSON router because it never ends and
     never produces a normal response body. */
  if (url.pathname === '/api/events' && req.method === 'GET') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no'          // stop any proxy buffering the stream
    });
    res.write('retry: 2000\n\n');
    liveClients.add(res);
    // a comment line every 25s keeps proxies and the OS from dropping an idle socket
    const beat = setInterval(() => {
      try { res.write(': ping\n\n'); } catch { clearInterval(beat); }
    }, 25000);
    const drop = () => { clearInterval(beat); liveClients.delete(res); };
    req.on('close', drop);
    res.on('error', drop);
    return;
  }

  if (url.pathname.startsWith('/api/')) {
    try {
      const data = await handleApi(req, res, url);
      if (!res.writableEnded) ok(res, data ?? { ok: true });
    } catch (e) {
      const status = e?.status || 500;
      if (status >= 500) console.error('API error:', e);
      bad(res, e?.error || e?.message || 'Server error', status);
    }
    return;
  }

  // dashboard — redirect to a trailing slash so relative asset paths resolve
  if (url.pathname === '/admin') {
    res.writeHead(302, { Location: '/admin/' });
    res.end();
    return;
  }
  if (url.pathname.startsWith('/admin/')) {
    const rel = url.pathname.replace(/^\/admin\/?/, '') || 'index.html';
    if (await serveFile(res, ADMIN, rel)) return;
    if (await serveFile(res, ADMIN, 'index.html')) return;      // SPA fallback
  }

  // storefront
  let rel = decodeURIComponent(url.pathname);
  if (rel.endsWith('/')) rel += 'index.html';
  if (await serveFile(res, SITE, rel, { injectDbMarker: true })) return;
  if (!extname(rel) && (await serveFile(res, SITE, rel + '.html', { injectDbMarker: true }))) return;   // /products -> products.html
  res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end('<h1>404 — not found</h1><p><a href="/">Back to the store</a></p>');
}).listen(PORT, () => {
  // report what is genuinely connected, so a silent failure is obvious at startup
  const counts = {};
  try {
    for (const t of ['orders', 'customers', 'subscribers', 'product_reviews']) {
      counts[t] = get(`SELECT COUNT(*) n FROM ${t}`).n;
    }
  } catch (e) {
    counts.error = e.message;
  }
  const line = '-'.repeat(46);
  console.log('');
  console.log('  Breezeguard store server');
  console.log('  ' + line);
  console.log('  storefront   http://localhost:' + PORT + '/');
  console.log('  dashboard    http://localhost:' + PORT + '/admin');
  console.log('');
  console.log('  database     ' + DB_FILE);
  console.log('  site folder  ' + SITE + (existsSync(SITE) ? '' : '   <-- NOT FOUND, pages will 404'));
  console.log('');
  if (counts.error) {
    console.log('  ! database problem: ' + counts.error);
  } else {
    console.log('  live rows    orders ' + counts.orders +
      ' | customers ' + counts.customers +
      ' | subscribers ' + counts.subscribers +
      ' | reviews ' + counts.product_reviews);
    console.log('');
    console.log('  Orders, signups and reviews are now saved to store.sqlite.');
    console.log('  Stop this server with Ctrl+C.');
  }
  console.log('');
});