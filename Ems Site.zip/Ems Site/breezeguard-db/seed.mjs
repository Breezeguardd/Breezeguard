/* Seeds the Breezeguard store database.
   Run:  node seed.mjs            (drops + recreates, then inserts)
   Idempotent: wipes the tables first so you can re-run any time.        */
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const db = new DatabaseSync(join(HERE, 'store.sqlite'));
db.exec('PRAGMA foreign_keys = ON;');
db.exec(readFileSync(join(HERE, 'schema.sql'), 'utf8'));

// product_reviews is deliberately NOT in the wipe list: customer reviews are real
// data and must survive a reseed of the shop. Reset the demo ones with seed-reviews.mjs.
const wipe = ['order_events', 'order_items', 'orders', 'customers', 'product_variants', 'products', 'coupons', 'message_replies', 'contact_messages', 'subscribers', 'settings'];
db.exec('PRAGMA foreign_keys = OFF;');
for (const t of wipe) db.exec(`DELETE FROM ${t};`);
db.exec(`DELETE FROM sqlite_sequence WHERE name IN (${wipe.map(t => `'${t}'`).join(',')});`);
db.exec('PRAGMA foreign_keys = ON;');

/* ------------------------------------------------------------- catalogue -- */
const products = [
  ['BG-CLS-SGE', 'breezeguard-classic', 'Breezeguard Classic', 'One pad. Eight quiet hours.', 1299, 1599, 'holder', 'product-classic.png', 8, 15, 43, 10],
  ['BG-TWN-SGE', 'breezeguard-twin-duo', 'Breezeguard Twin Duo', 'Two chambers, 12 hours.', 1899, null, 'holder', 'product-twin.png', 12, 22, 26, 10],
  ['BG-MIN-SGE', 'breezeguard-mini', 'Breezeguard Mini', 'Travel size, 6 hours.', 899, null, 'holder', 'product-mini.png', 6, 9, 24, 10],
  ['BG-DCK-SGE', 'breezeguard-deck-guard', 'Deck Guard', 'Weather-sealed, for verandas.', 2199, null, 'holder', 'product-deck.png', 6, 18, 17, 8],
  ['BG-KIT-2X', 'breezeguard-family-kit', 'Breezeguard Family Kit', 'Two units + 20 pads.', 2499, 2947, 'bundle', 'product-kit.png', 16, 30, 5, 6],
  ['BG-RFL-10', 'refill-pads-10', 'Refill Pads · 10 pads', 'Ten 8-hour pads.', 349, 420, 'refill', 'pad.svg', 8, 0, 120, 25]
];
const insProduct = db.prepare(`INSERT INTO products
  (sku, slug, name, tagline, price, compare_price, category, image, burn_hours, coverage_m2, stock, low_stock_at)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
for (const p of products) insProduct.run(...p);

/* --------------------------------------------------------------- variants -- */
/* sellable options — the server prices an order from these, not from the page.
   A markup keeps an option tied to its unit's price, so repricing the unit
   moves the bundle with it. A NULL markup means the option stands alone.
   CREATE TABLE IF NOT EXISTS cannot add a column to an existing table, so an
   older store.sqlite needs the column added by hand. */
const cols = db.prepare('PRAGMA table_info(product_variants)').all().map(c => c.name);
if (!cols.includes('markup')) db.exec('ALTER TABLE product_variants ADD COLUMN markup INTEGER');
if (!cols.includes('bundle_ref')) db.exec('ALTER TABLE product_variants ADD COLUMN bundle_ref TEXT');
if (!cols.includes('bundle_qty')) db.exec('ALTER TABLE product_variants ADD COLUMN bundle_qty INTEGER');
const insVariant = db.prepare(`INSERT INTO product_variants
  (product_id, sku, label, price, markup, bundle_ref, bundle_qty, stock) VALUES (?,?,?,?,?,?,?,?)`);
// products[] rows are [sku, slug, name, tagline, price, compare_price,
// category, image, burn_hours, coverage_m2, stock, low_stock_at]
// and are inserted in order, so the row index is the database id.
const productPrice = Object.fromEntries(products.map((p, i) => [i + 1, p[4]]));
const PADS_SKU = 'BG-RFL-10';
const variants = [
  // [product_id, sku, label, price, markup, bundle_ref, bundle_qty, stock]
  // Every option shares its unit's price unless it genuinely adds something,
  // so repricing a unit always moves its bundles with it. The pad bundles
  // track the refill product instead of a fixed amount, so whatever you set
  // "Refill Pads · 10 pads" to is exactly what they add.
  [1, 'BG-CLS-SGE', 'Unit only', 1299, 0, null, null, 43],
  [1, 'BG-CLS-SGE-K10', 'Unit + 10 pads', 1648, null, PADS_SKU, 1, 20],
  [1, 'BG-CLS-SGE-K20', 'Unit + 20 pads', 1997, null, PADS_SKU, 2, 12],
  [2, 'BG-TWN-SGE', 'Unit only', 1899, 0, null, null, 26],
  [2, 'BG-TWN-SGE-K10', 'Unit + 10 pads', 2248, null, PADS_SKU, 1, 14],
  [3, 'BG-MIN-SGE', 'Unit only', 899, 0, null, null, 8],
  [4, 'BG-DCK-SGE', 'Unit only', 2199, 0, null, null, 17],
  [5, 'BG-KIT-2X', 'Two units + 20 pads', 2499, 0, null, null, 5],
  [6, 'BG-RFL-10', '10 pads', 349, 0, null, null, 120]
];
const padPrice = productPrice[6];
for (const v of variants) {
  // keep the stored price consistent with the rule, so nothing reads a
  // stale absolute number
  const price = v[5]
    ? Math.max(0, productPrice[v[0]] + padPrice * v[6])
    : (v[4] != null ? Math.max(0, productPrice[v[0]] + v[4]) : v[3]);
  insVariant.run(v[0], v[1], v[2], price, v[4], v[5], v[6], v[7]);
}

/* --------------------------------------------------------------- coupons -- */
const insCoupon = db.prepare('INSERT INTO coupons (code, kind, value, label, expires_at) VALUES (?,?,?,?,?)');
insCoupon.run('BREEZE10', 'pct', 10, '10% off', null);
insCoupon.run('BREEZE50', 'flat', 50, '₱50 off', null);

/* -------------------------------------------------------------- settings -- */
const insSetting = db.prepare('INSERT INTO settings (key, value) VALUES (?,?)');
for (const [k, v] of [
  ['store_name', 'Breezeguard'],
  ['free_shipping_threshold', '1500'],
  ['shipping_metro', '59'],
  ['shipping_provincial', '129'],
  ['currency', 'PHP']
]) insSetting.run(k, v);

/* ------------------------------------------------- demo orders (30 days) -- */
const names = [
  ['Mara L.', 'mara@email.com', '09171234567', '88 Katipunan Ave', 'Quezon City', '1108'],
  ['Jomar R.', 'jomar@email.com', '09181234567', '21 Colon St', 'Cebu City', '6000'],
  ['Alyssa P.', 'allyssa@email.com', '09191112233', '7 Acacia St', 'Davao City', '8000'],
  ['Rhea T.', 'rhea@email.com', '09221234567', '3 Rizal Blvd', 'Iloilo City', '5000'],
  ['Kyla D.', 'kyla@email.com', '09171239999', '12 Katipunan Ave', 'Cagayan de Oro City', '9000'],
  ['Paolo G.', 'paolo@email.com', '09281234567', '55 Mabini St', 'Davao City', '8000'],
  ['Grace M.', 'grace@email.com', '09165556666', '9火烧 St', 'Cagayan de Oro City', '9000'],
  ['Carlo B.', 'carlo@email.com', '09371234567', '18 Bugkos St', 'Baguio City', '2600']
];
names[6][3] = '9火烧 St'.replace('火烧', 'Mabini');           // keep ASCII
const customers = new Map();
const insCustomer = db.prepare('INSERT INTO customers (name,email,phone,city) VALUES (?,?,?,?)');

const productsByKey = new Map(products.map((p, i) => [p[1], { id: i + 1, price: p[4], name: p[2] }]));
const pick = (arr, r) => arr[Math.floor(r * arr.length)];
const rand = (seedRef) => { seedRef.s = (seedRef.s * 1103515245 + 12345) % 2147483648; return seedRef.s / 2147483648; };
const rng = { s: 20261006 };

const insOrder = db.prepare(`INSERT INTO orders
  (order_no, customer_id, customer_name, email, phone, address, city, zip,
   payment_method, shipping_method, subtotal, discount, shipping_fee, total,
   coupon_code, status, created_at)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
const insItem = db.prepare(`INSERT INTO order_items (order_id, product_id, product_name, variant, unit_price, qty, line_total) VALUES (?,?,?,?,?,?,?)`);
const insEvent = db.prepare('INSERT INTO order_events (order_id, status, note, created_at) VALUES (?,?,?,?)');

const FLOW = { pending: 'Order placed', paid: 'Payment confirmed', packed: 'Packed at the workshop', shipped: 'Handed to courier', delivered: 'Delivered — thank you!' };
const carts = [
  [['breezeguard-classic', 'Sage Green · Unit only', 1]],
  [['breezeguard-classic', 'Sage Green · Unit + 10 pads', 1], ['refill-pads-10', 'Regular', 1]],
  [['breezeguard-twin-duo', 'Sage Green · Unit only', 1]],
  [['refill-pads-10', 'Regular', 2]],
  [['breezeguard-family-kit', 'Sage Green · 2 units + 20 pads', 1]],
  [['breezeguard-mini', 'Sage Green · Unit only', 2]],
  [['breezeguard-deck-guard', 'Sage Green · Unit only', 1]],
  [['breezeguard-classic', 'Sage Green · Unit + 20 pads', 1], ['breezeguard-mini', 'Sage Green · Unit only', 1]]
];

const orderNos = [];
for (let day = 29; day >= 0; day--) {
  const perDay = day < 7 ? 2 + Math.floor(rand(rng) * 2) : (rand(rng) > 0.45 ? 1 : 0);
  for (let k = 0; k < perDay; k++) {
    const who = pick(names, rand(rng));
    if (!customers.has(who[1])) { insCustomer.run(who[0], who[1], who[2], who[3 + 1]); customers.set(who[1], db.prepare('SELECT last_insert_rowid() id').get().id); }
    const cart = pick(carts, rand(rng));
    let subtotal = 0;
    const lines = cart.map(([slug, variant, qty]) => {
      const p = productsByKey.get(slug);
      const unit = p.price;
      subtotal += unit * qty;
      return { ...p, variant, qty, line: unit * qty };
    });
    const useCoupon = rand(rng) > 0.7;
    const discount = useCoupon ? Math.round(subtotal * 0.1) : 0;
    const shippingMethod = rand(rng) > 0.75 ? 'pickup' : (rand(rng) > 0.5 ? 'provincial' : 'metro');
    const base = shippingMethod === 'metro' ? 59 : shippingMethod === 'provincial' ? 129 : 0;
    const shipping_fee = (subtotal - discount) >= 1500 ? 0 : base;
    const total = subtotal - discount + shipping_fee;
    const payment = pick(['gcash', 'gcash', 'maya', 'cod', 'bank', 'card'], rand(rng));
    const status = day > 3 ? pick(['delivered', 'delivered', 'shipped', 'cancelled'], rand(rng))
      : day > 1 ? pick(['delivered', 'shipped', 'packed'], rand(rng))
        : pick(['pending', 'paid', 'packed', 'shipped'], rand(rng));
    const d = new Date(Date.now() - day * 864e5);
    d.setHours(8 + Math.floor(rand(rng) * 12), Math.floor(rand(rng) * 60), 0, 0);
    const stamp = d.toISOString().slice(0, 19).replace('T', ' ');
    const order_no = 'BG-' + (100000 + Math.floor(rand(rng) * 899999)).toString(36).toUpperCase().slice(-6);
    orderNos.push({ order_no, status, total });

    const res = insOrder.run(order_no, customers.get(who[1]), who[0], who[1], who[2], who[3], who[4], who[5],
      payment, shippingMethod, subtotal, discount, shipping_fee, total, useCoupon ? 'BREEZE10' : null, status, stamp);
    const orderId = res.lastInsertRowid;
    for (const l of lines) insItem.run(orderId, l.id, l.name, l.variant, l.price, l.qty, l.line);

    // event trail
    const chain = ['pending', 'paid', 'packed', 'shipped', 'delivered'];
    const upto = chain.indexOf(status);
    if (upto >= 0) for (let s = 0; s <= upto; s++) {
      const e = new Date(d.getTime() + s * 36e5);
      insEvent.run(orderId, chain[s], FLOW[chain[s]], e.toISOString().slice(0, 19).replace('T', ' '));
    } else {
      insEvent.run(orderId, 'cancelled', 'Customer cancelled', stamp);
    }
    // keep stock consistent: only an order that actually progressed past
    // "pending" consumes stock. A cancelled order gives it straight back, so
    // subtracting from it here would quietly drain the catalogue on every reseed.
    if (upto >= 0) {
      for (const l of lines) db.prepare('UPDATE products SET stock = MAX(0, stock - ?) WHERE id = ?').run(l.qty, l.id);
    }
  }
}

/* ------------------------------------------------- messages & subscribers -- */
const insMsg = db.prepare('INSERT INTO contact_messages (name,email,topic,message,is_read,created_at) VALUES (?,?,?,?,?,?)');
const msgs = [
  ['Kyla D.', 'kyla@email.com', 'Bulk or reseller order', 'Hi! My boarding house in CDO wants 12 units. Do you have a reseller price?', 0, 0],
  ['Rhea T.', 'rhea@email.com', 'Order status', 'Order BG-4KQ9 — has it left the workshop already? Thanks!', 0, 1],
  ['Paolo G.', 'paolo@email.com', 'Product suggestion', 'Any chance of a 3-pack bundle for medium bedrooms?', 1, 3],
  ['Grace M.', 'grace@email.com', 'Return or refund request', 'The lid arrived loose. Can I get a replacement?', 0, 5]
];
for (const [n, e, t, m, read, d] of msgs) {
  const dt = new Date(Date.now() - d * 864e5).toISOString().slice(0, 19).replace('T', ' ');
  insMsg.run(n, e, t, m, read, dt);
}
// one message already has a reply, so the thread UI has something to show
const withReply = db.prepare("SELECT id FROM contact_messages WHERE name = 'Grace M.'").get();
if (withReply) {
  const at = new Date(Date.now() - 4 * 864e5).toISOString().slice(0, 19).replace('T', ' ');
  db.prepare('INSERT INTO message_replies (message_id, body, author, created_at) VALUES (?,?,?,?)')
    .run(withReply.id,
      'Hi Grace! Sorry about the loose lid — that should not have happened. We can send a replacement free of charge. Could you confirm the delivery address and your preferred courier? We will dispatch it within the day.',
      'Breezeguard', at);
}
const insSub = db.prepare('INSERT OR IGNORE INTO subscribers (email, source, created_at) VALUES (?,?,?)');
[['juan@student.com', 'homepage'], ['maria@student.com', 'homepage'], ['kim@email.com', 'checkout'], ['pat@email.com', 'homepage']]
  .forEach(([e, s], i) => insSub.run(e, s, new Date(Date.now() - i * 3 * 864e5).toISOString().slice(0, 19).replace('T', ' ')));

/* ---------------------------------------------------------------- report -- */
const n = (sql) => db.prepare(sql).get();
console.log('Breezeguard database seeded');
console.log('  products      ', n('SELECT COUNT(*) c FROM products').c);
console.log('  variants      ', n('SELECT COUNT(*) c FROM product_variants').c);
console.log('  orders        ', n('SELECT COUNT(*) c FROM orders').c);
console.log('  order items   ', n('SELECT COUNT(*) c FROM order_items').c);
console.log('  customers     ', n('SELECT COUNT(*) c FROM customers').c);
console.log('  messages      ', n('SELECT COUNT(*) c FROM contact_messages').c);
console.log('  replies       ', n('SELECT COUNT(*) c FROM message_replies').c);
console.log('  subscribers   ', n('SELECT COUNT(*) c FROM subscribers').c);
console.log('  revenue       ₱' + n('SELECT COALESCE(SUM(total),0) c FROM orders').c.toLocaleString('en-PH'));
console.log('  file          store.sqlite');
db.close();