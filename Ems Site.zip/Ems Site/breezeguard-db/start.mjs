/* ============================================================================
   Breezeguard launcher
   Checks the machine can run the store, frees the port, starts the server and
   opens the storefront. Run it with:  node breezeguard-db/start.mjs
   (start-breezeguard.cmd in the project root just calls this file)
   ========================================================================== */
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const SITE = join(HERE, '..', 'breezeguard');
const DB_FILE = join(HERE, 'store.sqlite');
const PORT = Number(process.env.PORT || 3000);

const fail = (msg) => {
  console.log('\n  Cannot start: ' + msg + '\n');
  process.exit(1);
};

// 1. node:sqlite is only stable from Node 24. Older versions die on import,
//    which looks like a broken database rather than an old Node.
const major = Number(process.versions.node.split('.')[0]);
if (major < 24) {
  fail('this needs Node 24 or newer (you have ' + process.versions.node +
    ').\n  Install Node 24 LTS from https://nodejs.org and try again.');
}

// 2. the two things the server needs
if (!existsSync(DB_FILE)) {
  fail('no database at breezeguard-db\\store.sqlite\n' +
    '  To make a fresh one:  cd breezeguard-db && node seed.mjs');
}
if (!existsSync(join(SITE, 'index.html'))) {
  fail('no site folder at breezeguard\\index.html\n' +
    '  Keep breezeguard\\ and breezeguard-db\\ as sibling folders.');
}

// 3. if an older copy is still holding the port, close it. Otherwise the new
//    server dies with EADDRINUSE and it looks like the database is broken.
const inUse = await new Promise((done) => {
  const ps = spawn('netstat', ['-ano'], { windowsHide: true });
  let out = '';
  ps.stdout.on('data', (d) => { out += d; });
  ps.on('close', () => {
    const rows = out.split(/\r?\n/).filter((l) =>
      l.includes(':' + PORT) && /LISTENING/i.test(l));
    done(rows.map((l) => l.trim().split(/\s+/).pop()));
  });
  ps.on('error', () => done([]));
});

for (const pid of new Set(inUse)) {
  console.log('  Port ' + PORT + ' was busy - closing the older server (pid ' + pid + ')');
  await new Promise((done) => {
    const k = spawn('taskkill', ['/f', '/pid', pid], { windowsHide: true });
    k.on('close', done);
    k.on('error', done);
  });
}
if (inUse.length) await new Promise((r) => setTimeout(r, 900));

// 4. open the storefront once the server is actually listening, not before
const url = 'http://localhost:' + PORT + '/';
const server = spawn(process.execPath, [join(HERE, 'server.mjs')], {
  cwd: HERE, stdio: 'inherit', windowsHide: false,
});
server.on('exit', (code) => process.exit(code ?? 0));

const openWhenReady = async () => {
  for (let i = 0; i < 60; i++) {
    await new Promise((r) => setTimeout(r, 250));
    try {
      const res = await fetch('http://localhost:' + PORT + '/api/health');
      if (res.ok) {
        const { spawn: sp } = await import('node:child_process');
        // start "" is cmd's way of opening a URL with the default browser
        sp('cmd', ['/c', 'start', '""', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
        console.log('  Opened ' + url + '\n');
        return;
      }
    } catch { /* not up yet */ }
  }
  console.log('  The server took longer than expected - open ' + url + ' yourself.\n');
};
openWhenReady();

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => { server.kill(); process.exit(0); });
}