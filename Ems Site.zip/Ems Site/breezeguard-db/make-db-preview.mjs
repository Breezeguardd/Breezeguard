/* Builds a static HTML page that displays the contents of store.sqlite, so the
   database can be shown to someone without them needing a SQLite tool.
     node make-db-preview.mjs
   Writes breezeguard-database/index.html  (self-contained, no dependencies) */
import { DatabaseSync } from 'node:sqlite';
import { statSync, writeFileSync, mkdirSync, copyFileSync } from 'node:fs';

const HERE = 'C:/Users/chris/OneDrive/Documents/Default Project/breezeguard-db/';
const OUT = 'C:/Users/chris/OneDrive/Documents/Default Project/breezeguard-database/';

const db = new DatabaseSync(HERE + 'store.sqlite');

/* ---------- read ---------- */
const tables = db.prepare(`SELECT name FROM sqlite_master
                            WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
                            ORDER BY name`).all().map(r => r.name);
const views = db.prepare(`SELECT name, sql FROM sqlite_master WHERE type = 'view' ORDER BY name`).all();
const ddl = db.prepare(`SELECT name, sql FROM sqlite_master
                         WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
                         ORDER BY name`).all();

const rowsOf = t => {
  try { return db.prepare(`SELECT * FROM "${t}"`).all(); } catch { return []; }
};
const colsOf = t => {
  try { return db.prepare(`PRAGMA table_info("${t}")`).all(); } catch { return []; }
};
const countOf = t => {
  try { return db.prepare(`SELECT COUNT(*) c FROM "${t}"`).get().c; } catch { return 0; }
};

/* ---------- escape ---------- */
const e = (v) => {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
};
const peso = n => '₱' + Number(n || 0).toLocaleString('en-PH');
const bytes = n => n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.round(n / 1024) + ' KB';

/* headline numbers */
const kpi = db.prepare('SELECT * FROM v_kpis').get() || {};
const daily = db.prepare('SELECT * FROM v_daily_revenue ORDER BY day DESC LIMIT 14').all().reverse();
const top = db.prepare('SELECT * FROM v_top_products ORDER BY units_sold DESC').all();
const revSum = db.prepare("SELECT COALESCE(SUM(total),0) v FROM orders WHERE status <> 'cancelled'").get().v;

/* ---------- build ---------- */
let html = `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Breezeguard — Database</title>
<style>
  :root{
    --bg:#04120d; --panel:#0c1f18; --panel2:#12291f; --line:rgba(255,255,255,.11);
    --tx:#e9f5ee; --tx2:#a3bfae; --tx3:#6f8b7c;
    --brand:#3fd68c; --brand2:#8cf0b6; --amber:#f5b342; --rose:#ff7a6b; --cyan:#6fd6f0;
    --mono:ui-monospace,'SF Mono',Menlo,Consolas,monospace;
  }
  *{box-sizing:border-box}
  body{margin:0;background:
      radial-gradient(90% 60% at 12% -8%,rgba(63,214,140,.16),transparent 62%),var(--bg);
    color:var(--tx);font:15px/1.55 system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;
    -webkit-font-smoothing:antialiased;padding:0 0 70px}
  .wrap{max-width:1180px;margin:0 auto;padding:0 24px}
  header{padding:56px 0 34px;border-bottom:1px solid var(--line)}
  .kicker{display:inline-flex;align-items:center;gap:9px;font-size:.7rem;letter-spacing:.2em;
    text-transform:uppercase;color:var(--brand);border:1px solid rgba(63,214,140,.34);
    background:rgba(63,214,140,.09);padding:7px 14px;border-radius:99px}
  h1{font-size:clamp(2.1rem,5vw,3.1rem);margin:20px 0 8px;letter-spacing:-.025em;line-height:1.05}
  h1 em{font-style:italic;color:var(--brand2)}
  .lede{color:var(--tx2);max-width:60ch;margin:0}
  .meta{display:flex;flex-wrap:wrap;gap:10px;margin-top:22px}
  .pill{font-size:.76rem;color:var(--tx3);border:1px solid var(--line);border-radius:99px;padding:5px 12px}
  .pill b{color:var(--tx2);font-weight:600}

  h2{font-size:1.05rem;letter-spacing:.14em;text-transform:uppercase;color:var(--tx3);
     margin:52px 0 16px;font-weight:700}
  h2 span{color:var(--brand)}

  .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:13px}
  .card{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:17px 19px;position:relative;overflow:hidden}
  .card::before{content:"";position:absolute;inset:-45% -10% auto;height:125%;
    background:radial-gradient(58% 58% at 50% 0%,rgba(63,214,140,.2),transparent 70%);opacity:.55;pointer-events:none}
  .card b{display:block;font-size:1.85rem;font-weight:700;letter-spacing:-.03em;line-height:1;position:relative}
  .card span{display:block;font-size:.76rem;color:var(--tx2);margin-top:7px;position:relative}
  .card small{display:block;font-size:.7rem;color:var(--tx3);margin-top:3px;position:relative}

  .panel{background:var(--panel);border:1px solid var(--line);border-radius:18px;overflow:hidden;margin-bottom:14px}
  .panel-head{display:flex;align-items:center;gap:12px;flex-wrap:wrap;
    padding:15px 19px;border-bottom:1px solid var(--line)}
  .panel-head h3{margin:0;font-size:1rem;display:flex;align-items:center;gap:10px}
  .panel-head code{font-family:var(--mono);font-size:.76rem;color:var(--tx3)}
  .tag{font-size:.68rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
    padding:3px 9px;border-radius:99px;border:1px solid}
  .tag.green{color:var(--brand);border-color:rgba(63,214,140,.4);background:rgba(63,214,140,.1)}
  .tag.cyan{color:var(--cyan);border-color:rgba(111,214,240,.4);background:rgba(111,214,240,.1)}
  .tag.amber{color:var(--amber);border-color:rgba(245,179,66,.4);background:rgba(245,179,66,.1)}
  .tag.grey{color:var(--tx3);border-color:var(--line);background:rgba(255,255,255,.03)}
  .scroll{overflow:auto;max-height:430px}

  table{border-collapse:collapse;width:100%;font-size:.83rem}
  th,td{padding:9px 13px;text-align:left;white-space:nowrap;border-bottom:1px solid rgba(255,255,255,.055)}
  th{position:sticky;top:0;background:var(--panel2);color:var(--tx3);font-size:.7rem;
    letter-spacing:.09em;text-transform:uppercase;font-weight:700;z-index:1}
  td{color:var(--tx2)}
  td.id,td.num{font-family:var(--mono);font-size:.78rem;color:var(--tx3)}
  tbody tr:hover td{background:rgba(63,214,140,.05)}
  .null{color:var(--tx3);font-style:italic}
  .key{color:var(--brand2)}

  pre{background:#06150f;border:1px solid var(--line);border-radius:14px;padding:16px 18px;
    overflow:auto;font-family:var(--mono);font-size:.78rem;line-height:1.6;color:var(--tx2);margin:0}
  pre .kw{color:var(--brand2)} pre .ty{color:var(--cyan)} pre .cm{color:var(--tx3)}

  .cols{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px}
  .col{font-family:var(--mono);font-size:.72rem;color:var(--tx3);
    border:1px solid var(--line);border-radius:8px;padding:4px 9px;background:rgba(255,255,255,.02)}

  .bars{display:grid;gap:9px}
  .bar{display:grid;grid-template-columns:118px 1fr 96px;align-items:center;gap:13px;font-size:.82rem}
  .bar i{display:block;height:9px;border-radius:99px;background:var(--panel2);overflow:hidden}
  .bar i b{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--brand),var(--brand2))}
  .bar em{font-style:normal;text-align:right;color:var(--tx3);font-size:.78rem}

  .dl{display:flex;flex-wrap:wrap;gap:12px;margin-top:22px}
  .dl a{display:inline-flex;align-items:center;gap:9px;text-decoration:none;
    border:1px solid var(--line);background:var(--panel);border-radius:13px;padding:12px 17px;
    color:var(--tx);font-size:.88rem;font-weight:600;transition:.25s}
  .dl a:hover{border-color:rgba(63,214,140,.5);transform:translateY(-2px)}
  .dl a small{display:block;font-weight:400;color:var(--tx3);font-size:.72rem}
  footer{margin-top:46px;padding-top:22px;border-top:1px solid var(--line);color:var(--tx3);font-size:.8rem}
  .note{background:rgba(245,179,66,.08);border:1px solid rgba(245,179,66,.3);
    border-radius:13px;padding:14px 17px;color:var(--tx2);font-size:.85rem;margin-top:16px}
  @media(max-width:620px){.wrap{padding:0 16px}.bar{grid-template-columns:92px 1fr 72px}}
</style></head><body><div class="wrap">

<header>
  <span class="kicker"><span style="width:7px;height:7px;border-radius:99px;background:#3fd68c"></span>Database</span>
  <h1>Breezeguard <em>store database</em></h1>
  <p class="lede">Everything the shop remembers: the catalogue, every order and the customer who placed it,
     contact messages, newsletter sign-ups, discount codes and customer reviews.</p>
  <div class="meta">
    <span class="pill">Engine <b>SQLite</b></span>
    <span class="pill">File <b>store.sqlite</b></span>
    <span class="pill">Size <b>${bytes(statSync(HERE + 'store.sqlite').size)}</b></span>
    <span class="pill">Tables <b>${tables.length}</b></span>
    <span class="pill">Rows <b>${tables.reduce((n, t) => n + countOf(t), 0)}</b></span>
    <span class="pill">Generated <b>${new Date().toISOString().slice(0, 10)}</b></span>
  </div>
</header>

<h2>At a glance</h2>
<div class="cards">
  <div class="card"><b>${peso(revSum)}</b><span>Revenue booked</span><small>cancelled orders excluded</small></div>
  <div class="card"><b>${kpi.orders_total ?? 0}</b><span>Orders</span><small>${kpi.open_orders ?? 0} still open</small></div>
  <div class="card"><b>${kpi.customers_total ?? 0}</b><span>Customers</span><small>with at least one order</small></div>
  <div class="card"><b>${kpi.products_active ?? 0}</b><span>Products</span><small>${kpi.low_stock ?? 0} low on stock</small></div>
  <div class="card"><b>${countOf('product_reviews')}</b><span>Reviews</span><small>star ratings from buyers</small></div>
  <div class="card"><b>${kpi.unread_messages ?? 0}</b><span>Unread messages</span><small>${countOf('contact_messages')} in total</small></div>
</div>

<h2>Revenue, last 14 days</h2>
<div class="panel"><div class="scroll"><table><thead><tr><th>Day</th><th>Orders</th><th>Revenue</th><th style="width:46%">Share</th></tr></thead><tbody>
${(() => {
  const max = Math.max(1, ...daily.map(d => d.revenue));
  return daily.map(d => `<tr><td>${e(d.day)}</td><td class="num">${d.orders}</td><td class="num">${peso(d.revenue)}</td>
    <td><i style="display:block;height:9px;border-radius:99px;background:var(--panel2);overflow:hidden">
      <b style="display:block;height:100%;width:${Math.round(d.revenue / max * 100)}%;border-radius:99px;background:linear-gradient(90deg,var(--brand),var(--brand2))"></b></i></td></tr>`).join('')
    || '<tr><td colspan="4" class="null">No orders in this window.</td></tr>';
})()}
</tbody></table></div></div>

<h2>Best sellers</h2>
<div class="panel"><div class="scroll"><table><thead><tr><th>Product</th><th>SKU</th><th>Units sold</th><th>Revenue</th><th>Stock</th></tr></thead><tbody>
${top.map(p => `<tr><td>${e(p.name)}</td><td class="id">${e(p.sku)}</td><td class="num">${p.units_sold}</td>
  <td class="num">${peso(p.revenue)}</td><td class="num">${p.stock}</td></tr>`).join('')}
</tbody></table></div></div>

<h2>Data tables</h2>
${tables.map(t => {
  const cols = colsOf(t);
  const rows = rowsOf(t);
  const label = { products: 'green', orders: 'green', order_items: 'cyan', customers: 'cyan',
                  product_reviews: 'amber', contact_messages: 'amber', message_replies: 'amber' }[t] || 'grey';
  return `<div class="panel">
  <div class="panel-head">
    <h3>${e(t)} <span class="tag ${label}">${rows.length} row${rows.length === 1 ? '' : 's'}</span></h3>
    <code>${cols.length} column${cols.length === 1 ? '' : 's'}</code>
  </div>
  ${rows.length ? `<div class="scroll"><table><thead><tr>${cols.map(c => `<th>${e(c.name)}</th>`).join('')}</tr></thead>
  <tbody>${rows.map(r => `<tr>${cols.map(c => {
    const v = r[c.name];
    const isNull = v === null || v === undefined;
    const pk = c.pk ? ' key' : '';
    return `<td class="${c.type && /INT|REAL|NUM/i.test(c.type) ? 'num' : ''}${pk}">${isNull ? '<span class="null">null</span>' : e(v)}</td>`;
  }).join('')}</tr>`).join('')}</tbody></table></div>`
    : `<div style="padding:18px 19px" class="null">No rows yet.</div>`}
  <div class="cols">${cols.map(c => `<span class="col">${e(c.name)} <span style="opacity:.6">${e((c.type || '').toLowerCase())}</span></span>`).join('')}</div>
</div>`;
}).join('')}

<h2>Table definitions</h2>
${ddl.map(t => `<div style="margin-bottom:14px"><div style="font-size:.82rem;color:var(--tx2);margin:0 0 8px">${e(t.name)}</div>
<pre>${e((t.sql || '').replace(/\s+/g, ' ').trim())}</pre></div>`).join('')}

${views.length ? `<h2>Saved views</h2>
${views.map(v => `<div style="margin-bottom:14px"><div style="font-size:.82rem;color:var(--tx2);margin:0 0 8px">${e(v.name)}</div>
<pre>${e((v.sql || '').replace(/\s+/g, ' ').trim())}</pre></div>`).join('')}` : ''}

<h2>Download the raw file</h2>
<p class="lede" style="margin-bottom:4px">The same data as a single SQLite file, if you want to open it in any
   database tool or import it elsewhere.</p>
<div class="dl">
  <a href="store.sqlite" download>⬇ store.sqlite<small>${bytes(statSync(HERE + 'store.sqlite').size)} — SQLite database</small></a>
  <a href="schema.sql" download>⬇ schema.sql<small>${bytes(statSync(HERE + 'schema.sql').size)} — table definitions</small></a>
</div>

<div class="note">This page is a static snapshot. The live shop reads and writes the same tables at runtime —
   orders, stock and reviews all update as people use the site.</div>

<footer>Breezeguard · DIY mosquito repellent · generated from store.sqlite</footer>
</div></body></html>`;

/* ---------- write ---------- */
mkdirSync(OUT, { recursive: true });
writeFileSync(OUT + 'index.html', html, 'utf8');
copyFileSync(HERE + 'store.sqlite', OUT + 'store.sqlite');
copyFileSync(HERE + 'schema.sql', OUT + 'schema.sql');

const totalRows = tables.reduce((n, t) => n + countOf(t), 0);
console.log('wrote breezeguard-database/');
console.log('  index.html    ' + bytes(Buffer.byteLength(html)) + '   ' + tables.length + ' tables, ' + totalRows + ' rows');
console.log('  store.sqlite  ' + bytes(statSync(OUT + 'store.sqlite').size));
console.log('  schema.sql    ' + bytes(statSync(OUT + 'schema.sql').size));