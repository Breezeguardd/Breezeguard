-- ============================================================================
-- BREEZEGUARD STORE — database schema
-- Engine: SQLite (node:sqlite)  ·  File: store.sqlite
-- Design notes:
--   * money is stored as INTEGER peso (never float — avoids rounding drift)
--   * order_items snapshot name/variant/unit_price so past orders stay true
--     even after the catalogue or prices change
--   * every table has created_at; soft deletes use is_active / status
-- ============================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------- catalogue --
CREATE TABLE IF NOT EXISTS products (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  sku           TEXT    NOT NULL UNIQUE,          -- e.g. BG-CLS-SGE
  slug          TEXT    NOT NULL UNIQUE,          -- e.g. breezeguard-classic
  name          TEXT    NOT NULL,
  tagline       TEXT,
  description   TEXT    NOT NULL DEFAULT '',
  price         INTEGER NOT NULL CHECK (price >= 0),        -- peso, integer
  compare_price INTEGER          CHECK (compare_price IS NULL OR compare_price >= price),
  category      TEXT    NOT NULL DEFAULT 'holder',
  image         TEXT    NOT NULL DEFAULT 'breezeguard-device.svg',
  burn_hours    INTEGER,
  coverage_m2   INTEGER,
  stock         INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  low_stock_at  INTEGER NOT NULL DEFAULT 10,
  is_active     INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category, is_active);

-- sellable options of a product (e.g. "Classic + 10 coils").
-- Each option is its own SKU with its own price, so the server can price an
-- order from the catalogue alone and never trust a number from the browser.
-- When `markup` is set the option sells for "parent product price + markup",
-- so repricing the unit moves its bundles with it. `bundle_ref` + `bundle_qty`
-- is the stronger form: "unit price + N × the current price of that product",
-- so "+10 pads" tracks whatever the refill product is priced at. A NULL for
-- both means the option uses its own `price`.
CREATE TABLE IF NOT EXISTS product_variants (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  sku         TEXT    NOT NULL UNIQUE,
  label       TEXT    NOT NULL,
  price       INTEGER NOT NULL CHECK (price >= 0),
  markup      INTEGER          CHECK (markup IS NULL OR markup >= 0),
  bundle_ref  TEXT,
  bundle_qty  INTEGER          CHECK (bundle_qty IS NULL OR bundle_qty >= 0),
  stock       INTEGER,
  is_active   INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_variants_product ON product_variants(product_id, is_active);
CREATE INDEX IF NOT EXISTS idx_variants_sku     ON product_variants(sku);

-- ------------------------------------------------------------------ people --
CREATE TABLE IF NOT EXISTS customers (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  email         TEXT    NOT NULL,
  phone         TEXT,
  city          TEXT,
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_customers_email ON customers(email);

-- ------------------------------------------------------------------ orders --
CREATE TABLE IF NOT EXISTS orders (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  order_no        TEXT    NOT NULL UNIQUE,        -- e.g. BG-7QK4M2
  customer_id     INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  customer_name   TEXT    NOT NULL,
  email           TEXT    NOT NULL,
  phone           TEXT,
  address         TEXT,
  city            TEXT,
  zip             TEXT,
  notes           TEXT,
  payment_method  TEXT    NOT NULL,              -- gcash|maya|bank|card|cod
  shipping_method TEXT    NOT NULL,              -- metro|provincial|pickup
  subtotal        INTEGER NOT NULL CHECK (subtotal >= 0),
  discount        INTEGER NOT NULL DEFAULT 0 CHECK (discount >= 0),
  shipping_fee    INTEGER NOT NULL DEFAULT 0 CHECK (shipping_fee >= 0),
  total           INTEGER NOT NULL CHECK (total >= 0),
  coupon_code     TEXT,
  status          TEXT    NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','paid','packed','shipped','delivered','cancelled')),
  created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_orders_status  ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_email   ON orders(email);

CREATE TABLE IF NOT EXISTS order_items (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id     INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id   INTEGER          REFERENCES products(id) ON DELETE SET NULL,
  variant_id   INTEGER          REFERENCES product_variants(id) ON DELETE SET NULL,
  product_name TEXT    NOT NULL,                 -- snapshot
  variant      TEXT    NOT NULL DEFAULT '',
  unit_price   INTEGER NOT NULL CHECK (unit_price >= 0),
  qty          INTEGER NOT NULL CHECK (qty > 0),
  line_total   INTEGER NOT NULL CHECK (line_total >= 0)
);
CREATE INDEX IF NOT EXISTS idx_items_order   ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_items_product ON order_items(product_id);

-- status history, so the dashboard can draw an order timeline
CREATE TABLE IF NOT EXISTS order_events (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status     TEXT    NOT NULL,
  note       TEXT,
  created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_events_order ON order_events(order_id, created_at);

-- ----------------------------------------------------------------- helpers --
CREATE TABLE IF NOT EXISTS coupons (
  code        TEXT PRIMARY KEY,
  kind        TEXT    NOT NULL CHECK (kind IN ('pct','flat')),
  value       INTEGER NOT NULL CHECK (value > 0),
  label       TEXT    NOT NULL,
  is_active   INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  expires_at  TEXT,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS contact_messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT    NOT NULL,
  email      TEXT    NOT NULL,
  topic      TEXT    NOT NULL DEFAULT 'General',
  message    TEXT    NOT NULL,
  is_read    INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0,1)),
  created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_messages_read ON contact_messages(is_read, created_at DESC);

-- replies the shop sends back from the dashboard
CREATE TABLE IF NOT EXISTS message_replies (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id INTEGER NOT NULL REFERENCES contact_messages(id) ON DELETE CASCADE,
  body       TEXT    NOT NULL,
  author     TEXT    NOT NULL DEFAULT 'Breezeguard',
  created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_replies_message ON message_replies(message_id, created_at);

CREATE TABLE IF NOT EXISTS subscribers (
  email      TEXT PRIMARY KEY,
  source     TEXT    NOT NULL DEFAULT 'homepage',
  created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ----------------------------------------------------------------- reviews --
-- Customer comments and star ratings, one per product.
-- product_id is a TEXT slug (classic|twin|mini|deck|kit|refill) so the storefront
-- can post a review without knowing the integer catalogue id.
-- One review per email per product, enforced by the UNIQUE index below.
CREATE TABLE IF NOT EXISTS product_reviews (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id TEXT    NOT NULL,
  author     TEXT    NOT NULL,
  email      TEXT    NOT NULL DEFAULT '',
  rating     INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title      TEXT    NOT NULL DEFAULT '',
  body       TEXT    NOT NULL DEFAULT '',
  is_verified INTEGER NOT NULL DEFAULT 0 CHECK (is_verified IN (0,1)),
  is_published INTEGER NOT NULL DEFAULT 1 CHECK (is_published IN (0,1)),
  created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON product_reviews(product_id, is_published, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_reviews_one_per_email ON product_reviews(product_id, email)
  WHERE email <> '';

-- rating summary per product, for the "4.8 / 2,317 reviews" line under the title
CREATE VIEW IF NOT EXISTS v_review_summary AS
SELECT product_id,
       COUNT(*)              AS count,
       ROUND(AVG(rating), 2) AS average,
       SUM(rating = 5)       AS five,
       SUM(rating = 4)       AS four,
       SUM(rating = 3)       AS three,
       SUM(rating = 2)       AS two,
       SUM(rating = 1)       AS one
FROM product_reviews
WHERE is_published = 1
GROUP BY product_id;

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- ------------------------------------------------------------------- views --
-- headline numbers for the dashboard
CREATE VIEW IF NOT EXISTS v_kpis AS
SELECT
  (SELECT COUNT(*) FROM orders WHERE status <> 'cancelled')                        AS orders_total,
  (SELECT COUNT(*) FROM orders WHERE status IN ('pending','paid','packed'))         AS open_orders,
  (SELECT COALESCE(SUM(total),0) FROM orders WHERE status <> 'cancelled')          AS revenue_total,
  (SELECT COUNT(*) FROM customers)                                                 AS customers_total,
  (SELECT COUNT(*) FROM products WHERE is_active = 1)                              AS products_active,
  (SELECT COUNT(*) FROM products WHERE stock <= low_stock_at AND is_active = 1)     AS low_stock,
  (SELECT COUNT(*) FROM contact_messages WHERE is_read = 0)                        AS unread_messages;

-- revenue per day for the dashboard chart (last 30 days)
CREATE VIEW IF NOT EXISTS v_daily_revenue AS
SELECT date(created_at) AS day,
       COUNT(*)        AS orders,
       SUM(total)      AS revenue
FROM orders
WHERE status <> 'cancelled'
GROUP BY day
ORDER BY day;

-- best sellers
CREATE VIEW IF NOT EXISTS v_top_products AS
SELECT p.id, p.name, p.price, p.stock,
       (SELECT COUNT(*) FROM product_variants v WHERE v.product_id = p.id AND v.is_active = 1) AS option_count,
       SUM(i.qty)             AS units_sold,
       SUM(i.line_total)      AS revenue
FROM order_items i
JOIN products p ON p.id = i.product_id
GROUP BY p.id
ORDER BY units_sold DESC;