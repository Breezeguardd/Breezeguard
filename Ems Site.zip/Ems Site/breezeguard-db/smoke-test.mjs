/* Smoke test for the Breezeguard API.  Run the server first, then:
      node smoke-test.mjs
   Exits non-zero if anything fails.                                     */
const BASE = process.env.BASE || 'http://localhost:3000';
let pass = 0, fail = 0;

const call = async (method, path, body) => {
  const res = await fetch(BASE + path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
};
const ok = (name, cond, detail = '') => {
  if (cond) { pass++; console.log('  \u2713 ' + name); }
  else { fail++; console.log('  \u2717 ' + name + (detail ? '  → ' + JSON.stringify(detail).slice(0, 120) : '')); }
};
const section = (t) => console.log('\n' + t);
const throws = async (fn) => { try { await fn(); return false; } catch { return true; } };

/* ------------------------------------------------------------------ run -- */
section('health + settings');
{
  const h = await call('GET', '/api/health');
  ok('health responds', h.data.ok === true, h.data);
  const s = await call('GET', '/api/settings');
  ok('free shipping threshold is 1500', s.data.free_shipping_threshold === 1500, s.data.free_shipping_threshold);
  await call('PATCH', '/api/settings', { free_shipping_threshold: 2000, announcement: 'QA' });
  const s2 = await call('GET', '/api/settings');
  ok('settings update persists', s2.data.free_shipping_threshold === 2000, s2.data.free_shipping_threshold);
  await call('PATCH', '/api/settings', { free_shipping_threshold: 1500, announcement: '' });
  await call('PATCH', '/api/settings', { evil_key: 'x' });
  const s3 = await call('GET', '/api/settings');
  ok('unknown setting key ignored', !('evil_key' in s3.data));
}

section('products CRUD');
let testProductId;
{
  const c = await call('POST', '/api/products', { name: 'QA Test Fan', sku: 'BG-QA-001', price: 499, stock: 12, low_stock_at: 5, category: 'accessory' });
  ok('create product', c.data.name === 'QA Test Fan', c.data);
  ok('slug auto-generated', c.data.slug === 'qa-test-fan', c.data.slug);
  testProductId = c.data.id;
  ok('duplicate SKU rejected', (await call('POST', '/api/products', { name: 'x', sku: 'BG-QA-001' })).status === 409);
  ok('update price', (await call('PATCH', `/api/products/${testProductId}`, { price: 549 })).data.price === 549);
  ok('update stock', (await call('PATCH', `/api/products/${testProductId}`, { stock: 3 })).data.stock === 3);
  ok('adjust +25', (await call('POST', `/api/products/${testProductId}/adjust`, { delta: 25 })).data.stock === 28);
  ok('adjust never goes below 0', (await call('POST', `/api/products/${testProductId}/adjust`, { delta: -999 })).data.stock === 0);
  ok('archive', (await call('DELETE', `/api/products/${testProductId}`)).data.is_active === 0);
  ok('archive hides it from active list', !(await call('GET', '/api/products?active=1')).data.some(p => p.id === testProductId));
  ok('archive keeps it in the archived list', (await call('GET', '/api/products?active=0')).data.some(p => p.id === testProductId));
  ok('restore', (await call('POST', `/api/products/${testProductId}/restore`)).data.is_active === 1);
  await call('DELETE', `/api/products/${testProductId}/purge`);
  ok('purge removes the row', (await call('GET', `/api/products/${testProductId}`)).status === 404);
  ok('product search works', (await call('GET', '/api/products?search=classic')).data.length === 1);
}

section('orders — totals recomputed on the server');
const classic = (await call('GET', '/api/products')).data.find(p => p.sku === 'BG-CLS-SGE');
const refill = (await call('GET', '/api/products')).data.find(p => p.sku === 'BG-RFL-10');
{
  const stockBefore = classic.stock;
  const o = await call('POST', '/api/orders', {
    customer: { name: 'QA Tester', email: 'qa@test.com', phone: '09181234567', address: '1 Test St', city: 'Cagayan de Oro City', zip: '9000' },
    items: [{ sku: 'BG-CLS-SGE', unit_price: 1, variant: 'Sage Green · Unit only', qty: 2 }],
    payment_method: 'gcash', shipping_method: 'metro', coupon_code: 'BREEZE10', notes: 'QA order'
  });
  ok('order is created', /^BG-/.test(o.data.order_no), o.data);
  ok('client price is ignored (uses catalogue)', o.data.subtotal === 2598, o.data.subtotal);
  ok('10% coupon applied', o.data.discount === 260, o.data.discount);
  ok('free shipping over the threshold', o.data.shipping_fee === 0, o.data.shipping_fee);
  ok('total = subtotal − discount + shipping', o.data.total === 2338, o.data.total);
  ok('line snapshot stores catalogue price', o.data.items[0].unit_price === 1299, o.data.items[0]);
  ok('new order is pending', o.data.status === 'pending');
  ok('event trail created', o.data.events.length >= 1);
  ok('stock decremented by qty', (await call('GET', `/api/products/${classic.id}`)).data.stock === stockBefore - 2);
  await call('DELETE', `/api/orders/${o.data.id}`);
  ok('stock returned after delete', (await call('GET', `/api/products/${classic.id}`)).data.stock === stockBefore);
}
{
  const bad = await call('POST', '/api/orders', {
    customer: { name: 'Bad Coupon', email: 'bad@test.com' },
    items: [{ sku: 'BG-RFL-10', unit_price: 349, qty: 1 }], shipping_method: 'provincial', coupon_code: 'NOTREAL'
  });
  ok('unknown coupon is ignored', bad.data.discount === 0, bad.data.discount);
  ok('provincial fee charged under threshold', bad.data.shipping_fee === 129, bad.data.shipping_fee);
  const stockMid = (await call('GET', `/api/products/${refill.id}`)).data.stock;   // read AFTER the order was created
  const upd = await call('PATCH', `/api/orders/${bad.data.id}`, { status: 'shipped', city: 'Iligan City' });
  ok('status change saved', upd.data.status === 'shipped');
  ok('details editable', upd.data.city === 'Iligan City');
  ok('status event appended', upd.data.events.length >= 2);
  await call('PATCH', `/api/orders/${bad.data.id}`, { status: 'cancelled' });
  ok('cancelling returns stock', (await call('GET', `/api/products/${refill.id}`)).data.stock === stockMid + 1,
    { stockMid, now: (await call('GET', `/api/products/${refill.id}`)).data.stock });
  await call('DELETE', `/api/orders/${bad.data.id}`);
  ok('order deleted', (await call('GET', `/api/orders/${bad.data.id}`)).status === 404);
}
{
  const pick = await call('POST', '/api/orders', {
    customer: { name: 'Pickup Test', email: 'pick@test.com' },
    items: [{ sku: 'BG-RFL-10', unit_price: 349, qty: 1 }], shipping_method: 'pickup'
  });
  ok('pickup is always free', pick.data.shipping_fee === 0 && pick.data.total === 349, pick.data);
  await call('DELETE', `/api/orders/${pick.data.id}`);
}

section('coupons');
{
  const c = await call('POST', '/api/coupons', { code: 'qa-test', kind: 'flat', value: 25 });
  ok('code keeps its dash', c.data.code === 'QA-TEST', c.data.code);
  ok('update value', (await call('PATCH', '/api/coupons/QA-TEST', { value: 40 })).data.value === 40);
  await call('PATCH', '/api/coupons/QA-TEST', { is_active: false });
  const o = await call('POST', '/api/orders', {
    customer: { name: 'Dead Coupon', email: 'dead@test.com' },
    items: [{ sku: 'BG-RFL-10', unit_price: 349, qty: 1 }], coupon_code: 'QA-TEST'
  });
  ok('inactive coupon is not applied', o.data.discount === 0, o.data.discount);
  await call('DELETE', `/api/orders/${o.data.id}`);
  ok('duplicate code rejected', (await call('POST', '/api/coupons', { code: 'BREEZE10' })).status === 409);
  await call('DELETE', '/api/coupons/QA-TEST');
  ok('coupon deleted', !(await call('GET', '/api/coupons')).data.some(x => x.code === 'QA-TEST'));
}

section('subscribers');
{
  await call('POST', '/api/subscribers', { email: 'qa@sub.com', source: 'qa' });
  const list = await call('GET', '/api/subscribers');
  ok('subscribe', list.data.filter(x => x.email === 'qa@sub.com').length === 1);
  await call('POST', '/api/subscribers', { email: 'qa@sub.com' });
  ok('duplicate subscribe ignored', (await call('GET', '/api/subscribers')).data.filter(x => x.email === 'qa@sub.com').length === 1);
  ok('invalid email rejected', (await call('POST', '/api/subscribers', { email: 'nope' })).status === 400);
  await call('DELETE', '/api/subscribers/qa@sub.com');
  ok('unsubscribe', !(await call('GET', '/api/subscribers')).data.some(x => x.email === 'qa@sub.com'));
}

section('customers + messages');
{
  const list = (await call('GET', '/api/customers')).data;
  const c = list[0];
  const original = c.city;
  ok('customer update', (await call('PATCH', `/api/customers/${c.id}`, { city: 'Cagayan de Oro City' })).data.city === 'Cagayan de Oro City');
  await call('PATCH', `/api/customers/${c.id}`, { city: original });
  // build our own message, so this does not depend on the demo data's read/unread state
  const made = await call('POST', '/api/contact', {
    name: 'QA Tester', email: 'qa@msg.com', topic: 'General', message: 'smoke-test message'
  });
  ok('contact form stores a message', made.data.received === true && made.data.id > 0, made.data);
  const id = made.data.id;
  ok('new message starts unread', (await call('GET', '/api/messages')).data.find(m => m.id === id)?.is_read === 0);
  ok('mark as read', (await call('PATCH', `/api/messages/${id}`, { is_read: true })).data.is_read === 1);
  ok('mark as unread', (await call('PATCH', `/api/messages/${id}`, { is_read: false })).data.is_read === 0);
  ok('message can be deleted', (await call('DELETE', `/api/messages/${id}`)).data.deleted === true);
  ok('deleted message is gone', !(await call('GET', '/api/messages')).data.some(m => m.id === id));
  ok('contact form rejects a bad email', (await call('POST', '/api/contact', { name: 'X', email: 'nope' })).status === 400);
}

section('message replies');
{
  const msgs = (await call('GET', '/api/messages')).data;
  ok('reply count on the message list', msgs.every(m => typeof m.reply_count === 'number'));

  // build our own message rather than depending on whatever demo data exists
  const made = await call('POST', '/api/contact', { name: 'Reply Tester', email: 'reply@test.com', topic: 'General', message: 'for the reply tests' });
  const target = { id: made.data.id };
  ok('reply test message created', target.id > 0, made.data);
  const before = (await call('GET', `/api/messages/${target.id}/replies`)).data.length;

  const sent = await call('POST', `/api/messages/${target.id}/replies`, { body: 'Smoke-test reply — thanks for reaching out!' });
  ok('reply is stored', sent.data.sent === true && sent.data.reply?.body.includes('Smoke-test reply'), sent.data);
  ok('reply is counted', (await call('GET', `/api/messages/${target.id}/replies`)).data.length === before + 1);
  ok('replying marks the message read', (await call('GET', '/api/messages')).data.find(m => m.id === target.id).is_read === 1);

  const replyId = sent.data.reply?.id;
  ok('reply can be deleted', (await call('DELETE', `/api/replies/${replyId}`)).data.deleted === true);
  ok('reply is gone', (await call('GET', `/api/messages/${target.id}/replies`)).data.length === before);

  ok('empty reply rejected', (await call('POST', `/api/messages/${target.id}/replies`, { body: '   ' })).status === 400);
  ok('reply to unknown message → 404', (await call('POST', '/api/messages/999999/replies', { body: 'hi' })).status === 404);

  // deleting a message must take its replies with it
  const tmp = await call('POST', '/api/contact', { name: 'QA', email: 'qa@msg.com', topic: 'General', message: 'temporary message for cascade test' });
  const tmpId = tmp.data.id;
  await call('POST', `/api/messages/${tmpId}/replies`, { body: 'this reply should cascade away' });
  ok('temp reply stored', (await call('GET', `/api/messages/${tmpId}/replies`)).data.length === 1);
  await call('DELETE', `/api/messages/${tmpId}`);
  ok('reply removed with its message', (await call('GET', `/api/messages/${tmpId}/replies`)).data.length === 0);

  // clean up the message this section made
  await call('DELETE', `/api/messages/${target.id}`);
}

section('order priced from a bundle option (variant_sku)');
{
  // "+10 pads" is unit price + one refill product, read live from the
  // catalogue so repricing either product moves it
  const cat = (await call('GET', '/api/catalogue')).data;
  const unit = cat.products.find(p => p.sku === 'BG-CLS-SGE').price;
  const pads = cat.products.find(p => p.sku === 'BG-RFL-10').price;
  const bundleUnit = cat.variants.find(v => v.sku === 'BG-CLS-SGE-K10').price;
  const before = (await call('GET', '/api/products')).data.find(p => p.sku === 'BG-CLS-SGE').stock;
  const o = await call('POST', '/api/orders', {
    customer: { name: 'Bundle Buyer', email: 'bundle@test.com' },
    // the browser says ₱1 — the catalogue price for this option must win
    items: [{ variant_sku: 'BG-CLS-SGE-K10', unit_price: 1, variant: 'Sage Green', qty: 2 }],
    shipping_method: 'metro'
  });
  ok('bundle = unit + one refill product', bundleUnit === unit + pads, { bundleUnit, unit, pads });
  ok('bundle subtotal from the catalogue', o.data.subtotal === bundleUnit * 2, o.data.subtotal);
  ok('bundle unit price matches the catalogue', o.data.items[0]?.unit_price === bundleUnit, o.data.items[0]);
  ok('bundle label stored alongside the colour', o.data.items[0]?.variant === 'Sage Green · Unit + 10 pads', o.data.items[0]?.variant);
  const dup = await call('POST', '/api/orders', {
    customer: { name: 'Bundle Buyer 2', email: 'bundle2@test.com' },
    items: [{ variant_sku: 'BG-CLS-SGE-K10', variant: 'Sage Green · Unit + 10 pads', qty: 1 }]
  });
  ok('label is not duplicated', dup.data.items[0]?.variant === 'Sage Green · Unit + 10 pads', dup.data.items[0]?.variant);
  await call('DELETE', `/api/orders/${dup.data.id}`);
  ok('bundle order total correct (free shipping over ₱1,500)', o.data.total === bundleUnit * 2, o.data.total);
  const fb = await call('POST', '/api/orders', {
    customer: { name: 'Fallback', email: 'fb@test.com' },
    items: [{ variant_sku: 'NOPE-123', unit_price: 349, qty: 1 }]
  });
  ok('unknown option falls back to product price', fb.data.subtotal === 349, fb.data.subtotal);
  await call('DELETE', `/api/orders/${fb.data.id}`);
  await call('DELETE', `/api/orders/${o.data.id}`);
  ok('stock restored', (await call('GET', '/api/products')).data.find(p => p.sku === 'BG-CLS-SGE').stock === before);
}

section('validation');
{
  ok('empty cart rejected', (await call('POST', '/api/orders', { customer: { name: 'X', email: 'x@x.co' } })).status === 400);
  ok('missing customer rejected', (await call('POST', '/api/orders', { items: [{ qty: 1 }] })).status === 400);
  ok('unknown order → 404', (await call('GET', '/api/orders/999999')).status === 404);
  ok('unknown route → 404', (await call('GET', '/api/nope')).status === 404);
  ok('unknown product → 404', (await call('GET', '/api/products/999999')).status === 404);
  const st = (await call('GET', '/api/stats')).data;
  ok('30-day revenue series', st.series.length === 30, st.series.length);
  ok('top products present', st.top.length >= 3);
  ok('status breakdown present', st.byStatus.length >= 1);
}

section('static hosting');
{
  const home = await fetch(BASE + '/');
  ok('storefront served at /', home.status === 200);
  const pretty = await fetch(BASE + '/products');
  ok('extensionless route /products works', pretty.status === 200);
  const admin = await fetch(BASE + '/admin');
  ok('dashboard served at /admin', admin.status === 200);
  const asset = await fetch(BASE + '/assets/css/styles.css');
  ok('site assets still served', asset.status === 200);
}

section('cleanup');
{
  // orders are deleted as each section finishes, but the customers they created
  // are not - without this the demo data collects "QA Tester" and friends on
  // every run
  const before = (await call('GET', '/api/customers')).data.length;
  const leftovers = (await call('GET', '/api/customers')).data.filter(c => /test/i.test(c.email));
  for (const c of leftovers) await call('DELETE', `/api/customers/${c.id}`);
  const after = (await call('GET', '/api/customers')).data.length;
  ok('test customers removed', after === before - leftovers.length, { before, after, removed: leftovers.length });
}

console.log(`\n  ${pass} passed, ${fail} failed\n`);
process.exit(fail ? 1 : 0);