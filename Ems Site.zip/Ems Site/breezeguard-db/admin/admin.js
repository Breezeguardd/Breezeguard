/* ============================================================================
   BREEZEGUARD store dashboard
   Talks to the zero-dependency API in ../server.mjs (node:sqlite).
   Add / edit / delete everywhere, all settings live, orders arrive live.
   ========================================================================== */
(() => {
  'use strict';

  /* ------------------------------------------------------------ helpers -- */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const on = (el, ev, fn) => el && el.addEventListener(ev, fn);
  const peso = (n) => '₱' + Number(n || 0).toLocaleString('en-PH', { maximumFractionDigits: 0 });
  const peso2 = (n) => '₱' + Number(n || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const when = (iso) => {
    if (!iso) return '—';
    const d = new Date(iso.replace(' ', 'T'));
    const mins = Math.round((Date.now() - d) / 6e4);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + 'm ago';
    if (mins < 1440) return Math.round(mins / 60) + 'h ago';
    if (mins < 10080) return Math.round(mins / 1440) + 'd ago';
    return d.toLocaleDateString('en-PH', { month: 'short', day: 'numeric' });
  };
  const clock = (iso) => new Date(iso.replace(' ', 'T')).toLocaleString('en-PH', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  const IMG = (f) => '/assets/img/' + (f || 'product-classic.png');
  // pick the product picture that matches what the customer actually bought
  const PRODUCT_IMG = (name) => {
    const n = String(name || '').toLowerCase();
    if (n.includes('refill') || n.includes('pad')) return 'pad.svg';
    if (n.includes('twin')) return 'product-twin.png';
    if (n.includes('mini')) return 'product-mini.png';
    if (n.includes('deck')) return 'product-deck.png';
    if (n.includes('family') || n.includes('kit')) return 'product-kit.png';
    return 'product-classic.png';
  };

  const STATUSES = ['pending', 'paid', 'packed', 'shipped', 'delivered', 'cancelled'];
  const STATUS_COLOR = { pending: '#ffc24b', paid: '#67e8f9', packed: '#a78bfa', shipped: '#8cf0b6', delivered: '#3fd68c', cancelled: '#ff6b81' };

  /* ------------------------------------------------ offline / online --- */
  let online = true;
  function setOffline(isOffline, reason = 'network') {
    if (isOffline === !online && document.querySelector('.offline-bar')) return;
    online = !isOffline;
    let bar = document.querySelector('.offline-bar');
    if (isOffline && !bar) {
      bar = document.createElement('div');
      bar.className = 'offline-bar';
      document.body.appendChild(bar);
    }
    if (!bar) return;
    bar.innerHTML = location.protocol === 'file:'
      ? `<b>Opened as a file.</b> The dashboard needs the database server — open
         <code>http://localhost:3000/admin</code> after running <code>node server.mjs</code> in the
         <code>breezeguard-db</code> folder.`
      : `<b>Cannot reach the database server.</b> Start it with <code>node server.mjs</code> in the
         <code>breezeguard-db</code> folder, then keep this page open — it reconnects by itself.
         ${document.querySelectorAll('.toast').length ? '' : ''}`;
    if (isOffline && reason === 'noapi') {
      bar.innerHTML = `<b>No database API found.</b> This page must be served by the Breezeguard server
        rather than opened as a folder. Run <code>node server.mjs</code> in
        <code>breezeguard-db</code> and use <code>http://localhost:3000/admin</code>.`;
    }
    if (!isOffline) { bar.remove(); toast('Database server connected'); load(current); }
    else ensureReconnect();
    document.body.dataset.offline = String(isOffline);
  }

  /* keep trying until the server answers again (covers both "was down at
     page load" and "died while I was looking at it") */
  let reconnectTimer = null;
  function ensureReconnect() {
    if (reconnectTimer) return;
    reconnectTimer = setInterval(async () => {
      try {
        const h = await api('/api/health');
        if (h?.ok) {
          clearInterval(reconnectTimer);
          reconnectTimer = null;
          setOffline(false);
        }
      } catch { /* still down — try again in 4s */ }
    }, 4000);
  }

  async function api(path, opts = {}) {
    let res;
    try {
      res = await fetch(path, {
        method: opts.method || 'GET',
        headers: opts.body ? { 'Content-Type': 'application/json' } : {},
        body: opts.body ? JSON.stringify(opts.body) : undefined
      });
    } catch {
      setOffline(true, 'network');
      throw new Error('Database server unreachable');
    }
    // a 404 under /api means this page is not being served by the database server
    if (res.status === 404 && path.startsWith('/api/')) setOffline(true, 'noapi');
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || (res.status === 404 ? 'Database API not found' : res.statusText));
    return data;
  }

  /* -------------------------------------------------------------- toast -- */
  const toastBox = $('#toasts');
  window.toast = (msg, kind = 'ok') => {
    const t = document.createElement('div');
    t.className = 'toast ' + (kind === 'ok' ? '' : kind);
    const ico = kind === 'err' ? '✕' : kind === 'warn' ? '!' : '✓';
    t.innerHTML = `<span class="t-ico">${ico}</span><span>${esc(msg)}</span>`;
    toastBox.appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 400); }, 3400);
  };

  /* ------------------------------------------------------------ confirm -- */
  let confirmFn = null;
  function askConfirm(title, text, fn, label = 'Delete') {
    $('#cTitle').textContent = title;
    $('#cText').textContent = text;
    $('#cYes').textContent = label;
    $('#confirm').hidden = false;
    confirmFn = fn;
  }
  on($('#cYes'), 'click', async () => {
    $('#confirm').hidden = true;
    if (confirmFn) { const f = confirmFn; confirmFn = null; await f(); }
  });
  $$('[data-confirm-no]').forEach(b => on(b, 'click', () => { $('#confirm').hidden = true; confirmFn = null; }));

  /* -------------------------------------------------------------- modal -- */
  let modalSubmit = null;
  function openModal(title, fields, values, onSave, saveLabel = 'Save', onOpen) {
    $('#modalTitle').textContent = title;
    $('#modalSave').textContent = saveLabel;
    const body = $('#modalBody');
    body.innerHTML = fields.map(f => {
      const v = values?.[f.name] ?? f.value ?? '';
      if (f.type === 'switch') {
        return `<label class="switch"><input type="checkbox" name="${f.name}" ${values?.[f.name] ? 'checked' : ''}><i></i>${esc(f.label)}</label>`;
      }
      if (f.type === 'select') {
        return `<div class="field"><label>${esc(f.label)}</label><select class="select" name="${f.name}">${
          f.options.map(o => `<option value="${esc(o.v)}" ${String(v) === String(o.v) ? 'selected' : ''}>${esc(o.t)}</option>`).join('')
        }</select>${f.hint ? `<span class="hint">${esc(f.hint)}</span>` : ''}</div>`;
      }
      if (f.type === 'pair') {
        const sv = values?.[f.second] ?? '';
        return `<div class="field"><label>${esc(f.label)}</label>
          <div class="pair-row">
            <input class="input" name="${f.name}" type="number" min="${f.min ?? 0}" step="${f.step ?? 1}" value="${esc(v)}" placeholder="1299">
            <span class="pair-dash" aria-hidden="true">—</span>
            <input class="input" name="${f.second}" type="number" min="${f.min ?? 0}" step="${f.step ?? 1}" value="${esc(sv)}" placeholder="1599">
          </div>
          ${f.hint ? `<span class="hint">${esc(f.hint)}</span>` : ''}</div>`;
      }
      if (f.type === 'textarea') {
        return `<div class="field"><label>${esc(f.label)}</label><textarea class="input" name="${f.name}" rows="${f.rows || 3}">${esc(v)}</textarea>${f.hint ? `<span class="hint">${esc(f.hint)}</span>` : ''}</div>`;
      }
      return `<div class="field"><label>${esc(f.label)}</label><input class="input" name="${f.name}" type="${f.type || 'text'}" value="${esc(v)}" ${f.step ? `step="${f.step}"` : ''} ${f.min != null ? `min="${f.min}"` : ''} placeholder="${esc(f.placeholder || '')}">${f.hint ? `<span class="hint">${esc(f.hint)}</span>` : ''}</div>`;
    }).join('');
    $('#modal').hidden = false;
    resetSaveBtn(saveLabel);
    if (typeof onOpen === 'function') onOpen();
    modalSubmit = async (form) => {
      const data = {};
      for (const el of $$('#modalBody [name]')) {
        data[el.name] = el.type === 'checkbox' ? el.checked : el.value;
      }
      await onSave(data);
    };
    const first = $('#modalBody input, #modalBody select, #modalBody textarea');
    if (first) setTimeout(() => first.focus(), 80);
  }
  /* the save button is disabled while a save runs; it must be handed back
     usable every time, or the next modal opens with a dead button */
  let saveLabel = 'Save';
  function resetSaveBtn(label) {
    saveLabel = label || 'Save';
    const btn = $('#modalSave');
    btn.disabled = false;
    btn.textContent = saveLabel;
  }
  function closeModal() { $('#modal').hidden = true; modalSubmit = null; resetSaveBtn(); }
  $$('[data-close-modal]').forEach(b => on(b, 'click', closeModal));
  on($('#modalForm'), 'submit', async (e) => {
    e.preventDefault();
    if (!modalSubmit) return;
    const btn = $('#modalSave');
    btn.disabled = true; btn.textContent = 'Saving…';
    try { await modalSubmit(e.target); closeModal(); }
    catch (err) { toast(err.message, 'err'); resetSaveBtn(); }
  });

  /* ------------------------------------------------------------- router -- */
  const TITLES = {
    dashboard: ['Dashboard', 'Good day, seller'],
    orders: ['Orders', 'Every order, in one place'],
    products: ['Products', 'Add, edit, restock, archive'],
    customers: ['Customers', 'Who buys from you'],
    messages: ['Messages', 'Inquiries from the website'],
    reviews: ['Reviews', 'What customers say'],
    subscribers: ['Subscribers', 'Newsletter audience'],
    coupons: ['Coupons', 'Discount codes'],
    settings: ['Settings', 'Store, delivery and pricing']
  };
  let current = 'dashboard';

  function go(view) {
    current = view;
    document.body.dataset.view = view;
    $$('.view').forEach(v => v.hidden = v.dataset.view !== view);
    $$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.go === view));
    const [t, h] = TITLES[view] || ['', ''];
    $('#viewTitle').textContent = t;
    $('#viewHeading').textContent = h;
    history.replaceState(null, '', '#' + view);
    load(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  $$('#nav button').forEach(b => on(b, 'click', () => go(b.dataset.go)));
  $$('[data-go]').forEach(b => { if (!b.closest('#nav')) on(b, 'click', () => go(b.dataset.go)); });

  /* -------------------------------------------------------------- theme -- */
  const root = document.documentElement;
  const sun = '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.4v2.2M12 19.4v2.2M4.2 12H2M22 12h-2.2M5.6 5.6 4 4M20 20l-1.6-1.6M18.4 5.6 20 4M4 20l1.6-1.6"/></svg>';
  const moon = '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.2A8.4 8.4 0 0 1 9.8 4a8.4 8.4 0 1 0 10.2 10.2Z"/></svg>';
  const setTheme = (t) => {
    root.dataset.theme = t;
    localStorage.setItem('bg_admin_theme', t);
    $('#themeBtn').innerHTML = t === 'night' ? sun : moon;
  };
  setTheme(localStorage.getItem('bg_admin_theme') || 'night');
  on($('#themeBtn'), 'click', () => setTheme(root.dataset.theme === 'night' ? 'day' : 'night'));

  /* -------------------------------------------------------------- clock -- */
  const tickClock = () => {
    const d = new Date();
    $('#clockTime').textContent = d.toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit' });
    $('#clockDate').textContent = d.toLocaleDateString('en-PH', { weekday: 'short', day: 'numeric', month: 'short' });
  };
  tickClock(); setInterval(tickClock, 15000);

  /* ---------------------------------------------------------- count-up -- */
  function countTo(el, end, { prefix = '', decimals = 0, dur = 1200 } = {}) {
    const t0 = performance.now();
    const step = (t) => {
      const p = Math.min((t - t0) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      const v = end * eased;
      el.textContent = prefix + (decimals ? v.toLocaleString('en-PH', { minimumFractionDigits: decimals, maximumFractionDigits: decimals }) : Math.round(v).toLocaleString('en-PH'));
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  /* --------------------------------------------------------- 3D tilt --- */
  function tilt(el, max = 9) {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const parent = el.closest('.kpis') || el.parentElement;
    parent.style.perspective = '1200px';
    on(el, 'pointermove', (e) => {
      const r = el.getBoundingClientRect();
      const dx = (e.clientX - r.left) / r.width - .5, dy = (e.clientY - r.top) / r.height - .5;
      el.style.transform = `rotateY(${dx * max * 2}deg) rotateX(${-dy * max}deg) translateY(-4px) scale(1.02)`;
    });
    on(el, 'pointerleave', () => { el.style.transform = ''; });
  }

  /* ------------------------------------------------------ stacked chart -- */
  const STACK_ORDER = ['delivered', 'shipped', 'packed', 'paid', 'pending'];
  const STACK_LABEL = { delivered: 'Delivered', shipped: 'Shipped', packed: 'Packed', paid: 'Paid', pending: 'Pending' };

  function drawStacked(canvas, series, { animate = true } = {}) {
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth, h = canvas.clientHeight;
    canvas.width = w * dpr; canvas.height = h * dpr;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    if (!series.length) return;

    const padT = 18, padB = 26, padL = 46, padR = 12;
    const totals = series.map(s => STACK_ORDER.reduce((n, k) => n + (s.parts?.[k] || 0), 0));
    const max = Math.max(...totals, 1) * 1.15;
    const plotW = w - padL - padR, plotH = h - padT - padB;
    const x = (i) => padL + (i * plotW) / Math.max(1, series.length - 1);
    const y = (v) => h - padB - (v / max) * plotH;
    const css = (name, fallback) => getComputedStyle(canvas).getPropertyValue(name).trim() || fallback;

    // grid + axis labels — redrawn every frame, because the frame clears the canvas
    const kfmt = (v) => (v >= 1000 ? Math.round(v / 100) / 10 + 'k' : Math.round(v));
    const drawAxes = () => {
      ctx.font = '11px "JetBrains Mono", monospace';
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      for (let g = 0; g <= 4; g++) {
        const gy = padT + (g * plotH) / 4;
        ctx.strokeStyle = css('--line', 'rgba(255,255,255,.1)');
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(padL, gy); ctx.lineTo(w - padR, gy); ctx.stroke();
        ctx.fillStyle = css('--tx-3', '#6f8b7c');
        ctx.fillText(kfmt(max - (g * max) / 4), padL - 8, gy);
      }
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      const every = Math.ceil(series.length / 7);
      series.forEach((s, i) => {
        if (series.length > 10 && i % every !== 0 && i !== series.length - 1) return;
        ctx.fillText(s.day.slice(5).replace('-', '/'), x(i), h - padB + 8);
      });
    };

    const t0 = performance.now(), dur = animate ? 1000 : 0;
    const frame = (t) => {
      const p = dur ? Math.min((t - t0) / dur, 1) : 1;
      const e = 1 - Math.pow(1 - p, 3);
      ctx.clearRect(0, 0, w, h);
      drawAxes();

      // One shared reveal clip for everything below. It must be set up ONCE around the
      // loops — building a clip path calls beginPath(), which would wipe the band path.
      ctx.save();
      ctx.beginPath();
      ctx.rect(padL, padT, Math.max(0, plotW * e), plotH);
      ctx.clip();

      // stacked bands, bottom-up
      const base = new Array(series.length).fill(0);
      for (const key of STACK_ORDER) {
        ctx.beginPath();
        for (let i = 0; i < series.length; i++) {
          const v = series[i].parts?.[key] || 0;
          const yTop = y(base[i] + v);
          if (i === 0) ctx.moveTo(x(i), y(base[i]));
          ctx.lineTo(x(i), yTop);
        }
        for (let i = series.length - 1; i >= 0; i--) ctx.lineTo(x(i), y(base[i]));
        ctx.closePath();
        ctx.fillStyle = STATUS_COLOR[key] + 'cc';
        ctx.fill();
        for (let i = 0; i < series.length; i++) base[i] += series[i].parts?.[key] || 0;
      }

      // glowing line along the top of the stack
      ctx.beginPath();
      totals.forEach((v, i) => (i ? ctx.lineTo : ctx.moveTo).call(ctx, x(i), y(v)));
      ctx.strokeStyle = '#d6f7e4';
      ctx.lineWidth = 2;
      ctx.lineJoin = 'round';
      ctx.shadowColor = 'rgba(63,214,140,.55)'; ctx.shadowBlur = 10;
      ctx.stroke();
      ctx.shadowBlur = 0;
      const last = totals.length - 1;
      ctx.beginPath(); ctx.arc(x(last), y(totals[last]), 4, 0, 7);
      ctx.fillStyle = '#d6f7e4'; ctx.fill();
      ctx.restore();

      if (p < 1) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
  }

  /* legend for the stacked bands */
  function stackLegend(el) {
    const totals = {};
    (statsCache?.series || []).forEach(d => {
      for (const k of STACK_ORDER) totals[k] = (totals[k] || 0) + (d.parts?.[k] || 0);
    });
    el.innerHTML = STACK_ORDER.map(k => `<span class="sl-item"><i style="background:${STATUS_COLOR[k]}"></i>${STACK_LABEL[k]}</span>`).join('');
  }

  /* sparklines were removed from the KPI cards — they read as noise behind the numbers */
  void 0;   // (chart helpers above are hand-rolled so there is no chart library)

  /* =========================================================== DASHBOARD */
  let chartGeom = null, chartRange = 30, statsCache = null;

  async function loadStats() {
    const s = await api('/api/stats');
    statsCache = s;
    $('#lastSync').textContent = new Date().toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit' });

    const k = s.kpis;
    const prev = s.series.slice(0, 15).reduce((n, d) => n + d.revenue, 0);
    const now = s.series.slice(15).reduce((n, d) => n + d.revenue, 0);
    const delta = prev ? Math.round(((now - prev) / prev) * 100) : 0;

    const cards = [
      { label: 'Revenue · 30 days', val: k.revenue_30d, money: true, sub: peso(k.revenue_today) + ' today', delta, tint: 'color-mix(in srgb, var(--brand) 30%, transparent)', spark: s.series.map(d => d.revenue), ico: pesoIcon },
      { label: 'Orders · 30 days', val: k.orders_30d, sub: k.orders_today + ' today · ' + k.orders_total + ' all time', delta, tint: 'color-mix(in srgb, var(--cyan) 26%, transparent)', spark: s.series.map(d => d.orders), ico: boxIcon },
      { label: 'Open orders', val: k.open_orders, sub: k.orders_total + ' orders in total', tint: 'color-mix(in srgb, var(--amber) 26%, transparent)', spark: s.byStatus.map(d => d.c), ico: clockIcon },
      { label: 'Low stock', val: k.low_stock, sub: peso(s.inventory_value) + ' stock value', warn: k.low_stock > 0, tint: k.low_stock ? 'color-mix(in srgb, var(--ember) 30%, transparent)' : 'color-mix(in srgb, var(--violet) 24%, transparent)', spark: s.top.map(t => t.units_sold), ico: warnIcon }
    ];

    const box = $('#kpis');
    if (box.children.length !== cards.length) {
      box.innerHTML = cards.map(() => `<article class="kpi">
        <div class="k-top"><span class="k-label"></span><span class="k-ico"></span></div>
        <div class="k-val">0</div><div class="k-sub"></div></article>`).join('');
      $$('.kpi', box).forEach((el, i) => setTimeout(() => tilt(el), i * 60));
    }
    cards.forEach((c, i) => {
      const el = box.children[i];
      el.style.setProperty('--tint', c.tint);
      $('.k-label', el).textContent = c.label;
      $('.k-ico', el).innerHTML = c.ico;
      $('.k-sub', el).innerHTML = (c.delta != null && !isNaN(c.delta)
        ? `<span class="k-delta ${c.delta >= 0 ? 'up' : 'down'}">${c.delta >= 0 ? '▲' : '▼'} ${Math.abs(c.delta)}%</span> vs prev 15d · `
        : '') + esc(c.sub);
      countTo($('.k-val', el), c.val, { prefix: c.money ? '₱' : '' });
      el.classList.toggle('delta-flash', c.warn);
    });

    // sidebar counters
    $('[data-count="orders"]').textContent = k.open_orders;
    $('[data-count="messages"]').textContent = k.unread_messages;
    // /api/stats has no top-level "subscribers" key, so this used to blank the
    // badge every time the dashboard loaded. Count them from their own endpoint.
    api('/api/subscribers').then(subs => {
      const n = Array.isArray(subs) ? subs.length : (subs?.total ?? '');
      $('[data-count="subscribers"]').textContent = n;
    }).catch(() => {});

    drawStacked($('#revChart'), s.series.slice(-chartRange));
    chartGeom = { series: s.series.slice(-chartRange) };
    stackLegend($('#stackLegend'));
    const best = s.series.reduce((a, b) => (b.revenue > (a?.revenue ?? -1) ? b : a), null);
    const avg = Math.round(s.series.reduce((n, d) => n + d.revenue, 0) / s.series.length);
    $('#chartFoot').innerHTML = `
      <span>Best day <b>${best ? peso(best.revenue) : '—'}</b></span>
      <span>Daily average <b>${peso(avg)}</b></span>
      <span>Total <b>${peso(k.revenue_30d)}</b></span>
      <span>Top payment <b>${esc(s.methods[0]?.m || '—')}</b></span>`;

    // text-only status breakdown — click a row to filter the orders table
    const statusTotal = s.byStatus.reduce((n, r) => n + r.c, 0) || 1;
    $('#statusList').innerHTML = s.byStatus.map(r => `<button class="sl-row" data-status="${r.status}">
      <i style="background:${STATUS_COLOR[r.status]}"></i>
      <span class="sl-name">${r.status}</span>
      <span class="sl-pct">${Math.round((r.c / statusTotal) * 100)}%</span>
      <b class="sl-count">${r.c}</b>
    </button>`).join('');
    $$('#statusList .sl-row').forEach(b => on(b, 'click', () => {
      go('orders');
      setTimeout(() => $(`#orderFilter [data-status="${b.dataset.status}"]`)?.click(), 80);
    }));

    $('#topProducts').innerHTML = s.top.map((t, i) => `
      <div class="top-row" style="animation-delay:${i * 60}ms">
        <span class="t-thumb"><img src="${IMG(PRODUCT_IMG(t.name))}" alt=""></span>
        <span class="t-meta"><b>${esc(t.name)}</b><small>${peso(t.revenue)} revenue</small></span>
        <span class="t-units">${t.units_sold}<small style="display:block;color:var(--tx-3);font-size:.68rem">sold</small></span>
      </div>`).join('') || '<p class="sub">No sales yet.</p>';

    $('#recentOrders').innerHTML = s.recent.map((o, i) => `
      <div class="feed-row" data-order="${o.id}" style="animation-delay:${i * 50}ms">
        <span class="fr-no">${esc(o.order_no)}</span>
        <span class="fr-name">${esc(o.customer_name)}</span>
        <span class="status ${o.status}">${o.status}</span>
        <span class="fr-amt">${peso(o.total)}</span>
      </div>`).join('') || '<p class="sub">No orders yet.</p>';
    $$('#recentOrders .feed-row').forEach(r => on(r, 'click', () => openOrder(r.dataset.order)));

    const alerts = [];
    for (const p of s.lowStock) alerts.push({ ico: '📦', title: `${p.name} is running low`, sub: `${p.stock} left (${p.sku})`, kind: 'warn' });
    if (k.unread_messages) alerts.push({ ico: '✉', title: k.unread_messages + ' unread message' + (k.unread_messages > 1 ? 's' : ''), sub: 'From the contact form', kind: 'rose', view: 'messages' });
    if (!alerts.length) alerts.push({ ico: '✓', title: 'Everything looks healthy', sub: 'Stock and messages are under control', kind: '' });
    $('#alerts').innerHTML = alerts.slice(0, 6).map((a, i) => `
      <div class="alert ${a.kind}" data-go-alert="${a.view || ''}" style="animation-delay:${i * 60}ms">
        <span class="a-ico">${a.ico}</span><span><b>${esc(a.title)}</b><small>${esc(a.sub)}</small></span>
      </div>`).join('');
    $$('#alerts [data-go-alert]').forEach(a => on(a, 'click', () => a.dataset.goAlert && go(a.dataset.goAlert)));
  }

  /* chart hover tooltip — shows the day's total and its stacked breakdown */
  on($('#revChart'), 'mousemove', (e) => {
    if (!chartGeom?.series?.length) return;
    const canvas = $('#revChart'), tip = $('#chartTip');
    const rect = canvas.getBoundingClientRect();
    const padL = 46, padR = 12;
    const i = Math.round(((e.clientX - rect.left - padL) / (rect.width - padL - padR)) * (chartGeom.series.length - 1));
    if (i < 0 || i >= chartGeom.series.length) { tip.hidden = true; return; }
    const d = chartGeom.series[i];
    const total = STACK_ORDER.reduce((n, k) => n + (d.parts?.[k] || 0), 0);
    tip.hidden = false;
    tip.innerHTML = `<b>${d.day}</b> · ${peso(total)} · ${d.orders} order${d.orders === 1 ? '' : 's'}<br>`
      + STACK_ORDER.filter(k => d.parts?.[k])
        .map(k => `<span style="color:${STATUS_COLOR[k]}">●</span> ${STACK_LABEL[k]} ${peso(d.parts[k])}`).join('<br>');
    tip.style.left = padL + (i * (rect.width - padL - padR)) / Math.max(1, chartGeom.series.length - 1) + 'px';
    tip.style.top = '40px';
  });
  on($('#revChart'), 'mouseleave', () => { $('#chartTip').hidden = true; });
  $$('#rangeSeg button').forEach(b => on(b, 'click', () => {
    $$('#rangeSeg button').forEach(x => x.classList.remove('on'));
    b.classList.add('on');
    chartRange = Number(b.dataset.range);
    if (statsCache) { drawStacked($('#revChart'), statsCache.series.slice(-chartRange)); chartGeom = { series: statsCache.series.slice(-chartRange) }; }
  }));

  /* ---- status control: a real menu instead of a native <select>, whose option
        list renders unreadable on dark backgrounds and cannot be clicked.

        The menu lives in a single shared popover attached to <body>, positioned with
        position:fixed. It used to live inside the table row, but the table scrolls
        (overflow-x:auto), and a popup inside a scroll container gets clipped by its
        edges — which is why flipping it upward could hide the top options. Rendering
        it on <body> means no ancestor can ever clip it. ---- */
  const statusMenu = (id, current, extra = '') => `<div class="status-menu" data-menu="${id}">
      <button class="status-trigger status ${current}" data-status-toggle data-current="${current}"
        aria-haspopup="listbox" aria-expanded="false">
        ${current}<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
      </button>
    </div>${extra}`;

  let statusPop = null;                       // the one shared popover element
  function ensureStatusPop() {
    if (statusPop) return statusPop;
    statusPop = document.createElement('div');
    statusPop.className = 'status-pop';
    statusPop.setAttribute('role', 'listbox');
    statusPop.setAttribute('aria-label', 'Change order status');
    statusPop.hidden = true;
    document.body.appendChild(statusPop);
    return statusPop;
  }
  function closeStatusMenus() {
    if (statusPop) { statusPop.hidden = true; statusPop.classList.remove('open', 'up'); }
    $$('.status-menu.open').forEach(m => {
      m.classList.remove('open');
      m.closest('tr')?.classList.remove('status-open');
      $('[data-status-toggle]', m)?.setAttribute('aria-expanded', 'false');
    });
  }
  function openStatusMenu(menu) {
    const trigger = $('[data-status-toggle]', menu);
    const id = menu.dataset.menu;
    const current = trigger?.dataset.current || '';
    const pop = ensureStatusPop();
    pop.innerHTML = STATUSES.map(s => `<button role="option" aria-selected="${s === current}"
        class="status-option status ${s}${s === current ? ' on' : ''}" data-set-status="${s}" data-order="${id}">${s}</button>`).join('');

    menu.classList.add('open');
    menu.closest('tr')?.classList.add('status-open');
    trigger?.setAttribute('aria-expanded', 'true');
    pop.hidden = false;

    // measure, then place: prefer below the trigger, flip up only if it will not fit
    const t = trigger.getBoundingClientRect();
    const ph = pop.offsetHeight, pw = pop.offsetWidth;
    const GAP = 6, EDGE = 8;
    const below = t.bottom + GAP;
    const fitsBelow = below + ph <= window.innerHeight - EDGE;
    const up = !fitsBelow && t.top - GAP - ph >= EDGE;
    pop.classList.toggle('up', up);
    pop.style.top = (up ? t.top - GAP - ph : below) + 'px';
    // keep it on screen horizontally
    const left = Math.min(Math.max(EDGE, t.left), window.innerWidth - pw - EDGE);
    pop.style.left = left + 'px';
  }
  async function changeStatus(id, status) {
    try {
      await api(`/api/orders/${id}`, { method: 'PATCH', body: { status } });
      toast(`Order moved to “${status}”`);
      closeStatusMenus();
      if (current === 'orders') loadOrders();
      if (current === 'dashboard') loadStats();
      refreshCounts();
      if ($('#drawer').classList.contains('open')) openOrder(id);
    } catch (err) { toast(err.message, 'err'); }
  }
  document.addEventListener('click', (e) => {
    const toggle = e.target.closest('[data-status-toggle]');
    if (toggle) {
      e.stopPropagation();
      const menu = toggle.closest('.status-menu');
      const wasOpen = menu.classList.contains('open');
      closeStatusMenus();
      if (!wasOpen) openStatusMenu(menu);
      return;
    }
    const opt = e.target.closest('[data-set-status]');
    if (opt) { e.stopPropagation(); changeStatus(opt.dataset.order, opt.dataset.setStatus); return; }
    closeStatusMenus();
  });

  /* ============================================================== ORDERS */
  let orderStatus = 'all', orderSearch = '';
  async function loadOrders() {
    const rows = await api(`/api/orders?status=${orderStatus}&search=${encodeURIComponent(orderSearch)}&limit=200`);
    $('#ordersCount').textContent = rows.length;
    const t = $('#ordersTable');
    if (!rows.length) { t.innerHTML = `<tbody><tr><td colspan="7"><div class="empty"><p>No orders match this filter.</p></div></td></tr></tbody>`; return; }
    t.innerHTML = `<thead><tr>
        <th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th>Placed</th>
      </tr></thead><tbody>${rows.map((o, i) => `
      <tr class="clickable" data-order="${o.id}" style="animation-delay:${Math.min(i, 12) * 40}ms">
        <td class="num strong">${esc(o.order_no)}</td>
        <td><span class="strong">${esc(o.customer_name)}</span><br><span class="muted">${esc(o.email)}</span></td>
        <td class="muted">${o.line_count} line${o.line_count === 1 ? '' : 's'}</td>
        <td class="num strong">${peso(o.total)}</td>
        <td class="muted" style="text-transform:capitalize">${esc(o.payment_method)}</td>
        <td>${statusMenu(o.id, o.status)}</td>
        <td class="muted">${when(o.created_at)}</td>
      </tr>`).join('')}</tbody>`;
    $$('#ordersTable tr.clickable').forEach(tr => on(tr, 'click', (e) => { if (!e.target.closest('button,select,.status-menu')) openOrder(tr.dataset.order); }));
  }

  $$('#orderFilter .chip').forEach(c => on(c, 'click', () => {
    $$('#orderFilter .chip').forEach(x => x.classList.remove('on'));
    c.classList.add('on');
    orderStatus = c.dataset.status;
    loadOrders();
  }));

  async function openOrder(id) {
    const o = await api('/api/orders/' + id);
    $('#dOrderNo').textContent = o.order_no;
    $('#dDate').textContent = clock(o.created_at) + ' · ' + o.customer_name;
    const stepIndex = STATUSES.indexOf(o.status);
    $('#drawerBody').innerHTML = `
      <div class="d-block">
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <span class="status ${o.status}">${o.status}</span>
          <span class="sub">paid by <b style="text-transform:capitalize">${esc(o.payment_method)}</b></span>
        </div>
      </div>
      <div class="d-block">
        <h3>Items</h3>
        <div class="d-items">${o.items.map(i => `
          <div class="d-item">
            <span class="d-thumb"><img src="${IMG(PRODUCT_IMG(i.product_name))}" alt=""></span>
            <span><b>${esc(i.product_name)}</b><small>${esc(i.variant || 'Standard')} · ${i.qty} × ${peso(i.unit_price)}</small></span>
            <b class="num">${peso(i.line_total)}</b>
          </div>`).join('')}</div>
      </div>
      <div class="d-block">
        <h3>Totals</h3>
        <div class="totals">
          <div><span>Subtotal</span><span>${peso(o.subtotal)}</span></div>
          ${o.discount ? `<div style="color:var(--brand)"><span>Discount ${o.coupon_code ? '· ' + esc(o.coupon_code) : ''}</span><span>−${peso(o.discount)}</span></div>` : ''}
          <div><span>Delivery${o.shipping_fee ? '' : ' <small style="color:var(--brand)">(free)</small>'}</span><span>${o.shipping_fee ? peso(o.shipping_fee) : 'FREE'}</span></div>
          <div class="g"><span>Total</span><span>${peso(o.total)}</span></div>
        </div>
      </div>
      <div class="d-block">
        <h3>Deliver to</h3>
        <dl class="kv">
          <dt>Name</dt><dd>${esc(o.customer_name)}</dd>
          <dt>Email</dt><dd>${esc(o.email)}</dd>
          <dt>Phone</dt><dd>${esc(o.phone || '—')}</dd>
          <dt>Address</dt><dd>${esc(o.address || '—')}, ${esc(o.city || '')} ${esc(o.zip || '')}</dd>
          <dt>Method</dt><dd style="text-transform:capitalize">${esc(o.shipping_method)}</dd>
          ${o.notes ? `<dt>Notes</dt><dd>${esc(o.notes)}</dd>` : ''}
        </dl>
      </div>
      <div class="d-block">
        <h3>Timeline</h3>
        <div class="timeline">${STATUSES.slice(0, 5).map((s, i) => {
          const ev = o.events.find(e => e.status === s);
          return `<div class="tl ${i <= stepIndex ? 'done' : ''}"><i>${i <= stepIndex ? '✓' : i + 1}</i>
            <span><b style="text-transform:capitalize">${s}</b><small>${ev ? esc(ev.note) + ' · ' + when(ev.created_at) : 'not yet'}</small></span></div>`;
        }).join('')}</div>
      </div>`;
    $('#drawerFoot').innerHTML = `
      ${statusMenu(o.id, o.status)}
      <button class="btn ghost" data-edit-order="${o.id}">Edit details</button>
      <button class="btn danger" data-del-order="${o.id}">Delete order</button>`;
    $$('#drawerFoot [data-edit-order]').forEach(b => on(b, 'click', () => { closeDrawer(); editOrder(b.dataset.editOrder); }));
    $$('#drawerFoot [data-del-order]').forEach(b => on(b, 'click', () => {
      closeDrawer();
      askConfirm('Delete this order?', `${o.order_no} will be removed and its stock returned.`, async () => {
        await api('/api/orders/' + o.id, { method: 'DELETE' }); toast('Order deleted', 'warn');
        loadOrders(); refreshCounts(); if (current === 'dashboard') loadStats();
      }, 'Delete');
    }));
    openDrawer();
  }

  function editOrder(id) {
    api('/api/orders/' + id).then((o) => {
      openModal('Edit order ' + o.order_no, [
        { name: 'customer_name', label: 'Customer name' },
        { name: 'email', label: 'Email', type: 'email' },
        { name: 'phone', label: 'Phone', type: 'tel' },
        { name: 'address', label: 'Address' },
        { name: 'city', label: 'City' },
        { name: 'zip', label: 'ZIP' },
        { name: 'payment_method', label: 'Payment method', type: 'select', options: ['gcash', 'maya', 'bank', 'card', 'cod'].map(v => ({ v, t: v })) },
        { name: 'status', label: 'Status', type: 'select', options: STATUSES.map(v => ({ v, t: v })) },
        { name: 'notes', label: 'Notes', type: 'textarea' }
      ], o, async (data) => {
        await api('/api/orders/' + id, { method: 'PATCH', body: data });
        toast('Order updated');
        loadOrders(); if (current === 'dashboard') loadStats();
      });
    });
  }

  /* ============================================================ PRODUCTS */
  let catFilter = '';
  async function loadProducts() {
    const active = catFilter === 'archived' ? '0' : '1';
    const rows = await api(`/api/products?active=${active}${catFilter && catFilter !== 'archived' ? '&category=' + catFilter : ''}`);
    $('#productsCount').textContent = rows.length;
    const grid = $('#productsGrid');
    if (!rows.length) { grid.innerHTML = `<div class="empty"><p>No products here yet.</p><button class="btn primary" onclick="document.getElementById('addProduct').click()">+ Add product</button></div>`; return; }
    grid.innerHTML = rows.map((p, i) => {
      const pct = Math.min(100, Math.round((p.stock / Math.max(1, p.low_stock_at * 6)) * 100));
      const low = p.stock <= p.low_stock_at;
      return `<article class="prod ${p.is_active ? '' : 'off'}" style="animation-delay:${Math.min(i, 10) * 55}ms">
        <div class="p-media">
          <div class="p-badges">
            <span class="badge cat">${esc(p.category)}</span>
            ${p.is_active ? '' : '<span class="badge off">archived</span>'}
          </div>
          <img src="${IMG(p.image)}" alt="${esc(p.name)}">
        </div>
        <div class="p-body">
          <h3>${esc(p.name)}</h3>
          <span class="p-sku">${esc(p.sku)}</span>
          <div class="p-price">${peso(p.price)}${p.compare_price ? `<s>${peso(p.compare_price)}</s>` : ''}</div>
          <div class="stock-bar ${low ? 'low' : ''}"><i data-w="${pct}"></i></div>
          <div style="display:flex;justify-content:space-between;font-size:.76rem;color:var(--tx-3)">
            <span>${p.stock} in stock</span><span>${p.units_sold ?? 0} sold</span>
          </div>
          <div class="p-foot">
            <button class="btn tiny ghost" data-edit-product="${p.id}">Edit</button>
            <button class="btn tiny ghost" data-stock="${p.id}" data-delta="10">+10 stock</button>
            <button class="btn tiny ghost" data-stock="${p.id}" data-delta="-1">−1</button>
            ${p.is_active
        ? `<button class="btn tiny ghost" data-archive="${p.id}">Archive</button>`
        : `<button class="btn tiny ghost" data-restore="${p.id}">Restore</button>`}
            <button class="btn tiny danger" data-purge="${p.id}">Delete</button>
          </div>
        </div>
      </article>`;
    }).join('');
    // animate the stock bars
    requestAnimationFrame(() => $$('.stock-bar i').forEach(b => b.style.width = b.dataset.w + '%'));

    $$('[data-edit-product]').forEach(b => on(b, 'click', () => editProduct(b.dataset.editProduct)));
    $$('[data-stock]').forEach(b => on(b, 'click', async () => {
      try { const r = await api(`/api/products/${b.dataset.stock}/adjust`, { method: 'POST', body: { delta: Number(b.dataset.delta) } }); toast(`Stock is now ${r.stock}`); loadProducts(); }
      catch (e) { toast(e.message, 'err'); }
    }));
    $$('[data-archive]').forEach(b => on(b, 'click', async () => {
      await api('/api/products/' + b.dataset.archive, { method: 'DELETE' });
      toast('Product archived', 'warn'); loadProducts();
    }));
    $$('[data-restore]').forEach(b => on(b, 'click', async () => {
      await api('/api/products/' + b.dataset.restore + '/restore', { method: 'POST' });
      toast('Product restored'); loadProducts();
    }));
    $$('[data-purge]').forEach(b => on(b, 'click', async () => {
      const p = rows.find(x => x.id === Number(b.dataset.purge));
      askConfirm('Delete permanently?', `${p.name} will be removed from the products table. Past orders keep their saved copy of the name and price.`,
        async () => { await api(`/api/products/${p.id}/purge`, { method: 'DELETE' }); toast('Product deleted', 'warn'); loadProducts(); }, 'Delete forever');
    }));
  }

  const PRODUCT_FIELDS = [
    { name: 'name', label: 'Product name' },
    { name: 'sku', label: 'SKU', placeholder: 'BG-XXX-000' },
    { name: 'tagline', label: 'Tagline' },
    { name: 'price', second: 'compare_price', label: 'Price — Original price', type: 'pair', min: 0, step: 1,
      secondLabel: 'Original price', hint: 'Leave the original price empty to hide the strikethrough. It must be higher than the price.' },
    { name: 'category', label: 'Category', type: 'select', options: [{ v: 'holder', t: 'Holder' }, { v: 'refill', t: 'Refill' }, { v: 'bundle', t: 'Bundle' }, { v: 'accessory', t: 'Accessory' }] },
    { name: 'stock', label: 'Stock on hand', type: 'number', min: 0, step: 1 },
    { name: 'low_stock_at', label: 'Low-stock alert at', type: 'number', min: 0, step: 1 },
    { name: 'image', label: 'Image file', type: 'select', options: ['product-classic.png', 'product-twin.png', 'product-mini.png', 'product-deck.png', 'product-kit.png', 'pad.svg', 'mark.svg', 'logo.svg'].map(v => ({ v, t: v })) },
    { name: 'description', label: 'Description', type: 'textarea' },
    { name: 'is_active', label: 'Visible on the storefront', type: 'switch' }
  ];
  on($('#addProduct'), 'click', () => openModal('Add product', PRODUCT_FIELDS,
    { category: 'holder', stock: 0, low_stock_at: 10, image: 'product-classic.png', is_active: true },
    async (data) => { await api('/api/products', { method: 'POST', body: data }); toast('Product added'); loadProducts(); }, 'Add product'));
  function editProduct(id) {
    api('/api/products/' + id).then((p) => openModal('Edit ' + p.name, PRODUCT_FIELDS, p,
      async (data) => { await api('/api/products/' + id, { method: 'PATCH', body: data }); toast('Product saved'); loadProducts(); }));
  }
  $$('#catFilter .chip').forEach(c => on(c, 'click', () => {
    $$('#catFilter .chip').forEach(x => x.classList.remove('on'));
    c.classList.add('on'); catFilter = c.dataset.cat; loadProducts();
  }));

  /* =========================================================== CUSTOMERS */
  async function loadCustomers() {
    const rows = await api('/api/customers');
    $('#customersCount').textContent = rows.length;
    $('#customersTable').innerHTML = `<thead><tr><th>Customer</th><th>Contact</th><th>City</th><th>Orders</th><th>Spent</th><th>Last order</th><th></th></tr></thead>
      <tbody>${rows.map((c, i) => `<tr style="animation-delay:${Math.min(i, 12) * 40}ms">
        <td class="strong">${esc(c.name)}</td>
        <td class="muted">${esc(c.email)}<br>${esc(c.phone || '')}</td>
        <td class="muted">${esc(c.city || '—')}</td>
        <td class="num">${c.order_count}</td>
        <td class="num strong">${peso(c.spent)}</td>
        <td class="muted">${c.last_order ? when(c.last_order) : '—'}</td>
        <td class="row-actions">
          <button class="btn tiny ghost" data-edit-cust="${c.id}">Edit</button>
          <button class="btn tiny danger" data-del-cust="${c.id}">✕</button>
        </td></tr>`).join('')}</tbody>`;
    $$('[data-edit-cust]').forEach(b => on(b, 'click', () => {
      const c = rows.find(x => x.id === Number(b.dataset.editCust));
      openModal('Edit ' + c.name, [
        { name: 'name', label: 'Name' }, { name: 'email', label: 'Email', type: 'email' },
        { name: 'phone', label: 'Phone' }, { name: 'city', label: 'City' }
      ], c, async (data) => { await api('/api/customers/' + c.id, { method: 'PATCH', body: data }); toast('Customer saved'); loadCustomers(); });
    }));
    $$('[data-del-cust]').forEach(b => on(b, 'click', () => {
      const c = rows.find(x => x.id === Number(b.dataset.delCust));
      askConfirm('Delete customer?', `${c.name} will be removed. Their past orders stay in the database.`,
        async () => { await api('/api/customers/' + c.id, { method: 'DELETE' }); toast('Customer deleted', 'warn'); loadCustomers(); }, 'Delete');
    }));
  }

  /* ============================================================ MESSAGES */
  let openThreads = new Set();          // message ids whose reply box is expanded

  async function loadMessages() {
    const rows = await api('/api/messages');
    const replies = {};
    await Promise.all(rows.map(async (m) => { replies[m.id] = await api(`/api/messages/${m.id}/replies`); }));
    $('#messagesCount').textContent = rows.length;
    $('#msgList').innerHTML = rows.length ? rows.map((m, i) => {
      const thread = replies[m.id] || [];
      const isOpen = openThreads.has(m.id);
      return `
      <article class="msg ${m.is_read ? '' : 'unread'} ${isOpen ? 'open' : ''}" data-msg="${m.id}" style="animation-delay:${Math.min(i, 10) * 50}ms">
        <div class="msg-head">
          <b>${esc(m.name)}</b>
          <span class="m-topic">${esc(m.topic)}</span>
          <a class="sub" href="mailto:${esc(m.email)}">${esc(m.email)}</a>
          <time>${when(m.created_at)}</time>
        </div>
        <p>${esc(m.message)}</p>

        ${thread.length ? `<div class="thread">
          ${thread.map(r => `<div class="bubble">
            <div class="bubble-head"><b>${esc(r.author)}</b><time>${when(r.created_at)}</time>
              <button class="bubble-x" data-del-reply="${r.id}" title="Delete reply" aria-label="Delete reply">✕</button>
            </div>
            <p>${esc(r.body)}</p>
          </div>`).join('')}
        </div>` : ''}

        ${isOpen ? `<form class="reply-box" data-reply-for="${m.id}">
          <textarea name="body" rows="3" placeholder="Write your reply to ${esc(m.name)}…" maxlength="4000" required></textarea>
          <div class="reply-foot">
            <span class="reply-hint">Saved to the database as the reply thread${m.reply_count ? ` · ${m.reply_count} sent` : ''}</span>
            <button class="btn ghost sm" type="button" data-cancel-reply="${m.id}">Cancel</button>
            <button class="btn primary sm" type="submit">Send reply</button>
          </div>
        </form>` : ''}

        <div class="m-actions">
          <button class="btn tiny ghost" data-read="${m.id}" data-state="${m.is_read ? 0 : 1}">${m.is_read ? 'Mark unread' : 'Mark read'}</button>
          <button class="btn tiny ${isOpen ? 'primary' : 'ghost'}" data-toggle-reply="${m.id}">${thread.length ? `Reply · ${thread.length}` : 'Reply'}</button>
          <button class="btn tiny danger" data-del-msg="${m.id}">Delete</button>
        </div>
      </article>`;
    }).join('') : `<div class="empty"><p>No messages yet. Submissions from the contact form land here.</p></div>`;

    $$('[data-read]').forEach(b => on(b, 'click', async () => {
      await api('/api/messages/' + b.dataset.read, { method: 'PATCH', body: { is_read: !!Number(b.dataset.state) } });
      loadMessages(); refreshCounts();
    }));
    $$('[data-del-msg]').forEach(b => on(b, 'click', () => askConfirm('Delete message?', 'This cannot be undone.',
      async () => { await api('/api/messages/' + b.dataset.delMsg, { method: 'DELETE' }); toast('Message deleted', 'warn'); loadMessages(); refreshCounts(); }, 'Delete')));

    // reply thread
    $$('[data-toggle-reply]').forEach(b => on(b, 'click', () => {
      const id = Number(b.dataset.toggleReply);
      openThreads.has(id) ? openThreads.delete(id) : openThreads.add(id);
      loadMessages().then(() => {
        const box = $(`[data-reply-for="${id}"] textarea`);
        if (box) { box.focus(); }
      });
    }));
    $$('[data-cancel-reply]').forEach(b => on(b, 'click', () => { openThreads.delete(Number(b.dataset.cancelReply)); loadMessages(); }));
    $$('[data-del-reply]').forEach(b => on(b, 'click', () => askConfirm('Delete this reply?', 'The reply will be removed from the thread.',
      async () => { await api('/api/replies/' + b.dataset.delReply, { method: 'DELETE' }); toast('Reply deleted', 'warn'); loadMessages(); }, 'Delete')));
    $$('[data-reply-for]').forEach(form => on(form, 'submit', async (e) => {
      e.preventDefault();
      const id = Number(form.dataset.replyFor);
      const field = $('textarea', form);
      const body = field.value.trim();
      if (!body) { field.focus(); return; }
      const btn = $('button[type="submit"]', form);
      btn.disabled = true; btn.textContent = 'Sending…';
      try {
        await api(`/api/messages/${id}/replies`, { method: 'POST', body: { body } });
        field.value = '';
        toast('Reply sent');
        openThreads.delete(id);               // sent: collapse the box, thread stays visible
        await Promise.all([loadMessages(), refreshCounts()]);
      } catch (err) {
        btn.disabled = false; btn.textContent = 'Send reply';
        toast(err.message, 'err');
      }
    }));
  }
  on($('#markAllRead'), 'click', async () => {
    const rows = await api('/api/messages');
    for (const m of rows.filter(m => !m.is_read)) await api('/api/messages/' + m.id, { method: 'PATCH', body: { is_read: 1 } });
    toast('All messages marked as read'); loadMessages(); refreshCounts();
  });

  /* ============================================================ REVIEWS */
  const PRODUCT_NAMES = { classic: 'Breezeguard Classic', twin: 'Breezeguard Twin Duo', mini: 'Breezeguard Mini', deck: 'Deck Guard', kit: 'Family Kit', refill: 'Refill Pads' };
  const starRow = (n) => {
    const full = Math.max(0, Math.min(5, Math.round(Number(n) || 0)));
    return `<span class="stars-inline" title="${full} out of 5"><b>${'★'.repeat(full)}</b><i>${'★'.repeat(5 - full)}</i><em>${full}.0</em></span>`;
  };

  /* An editable 1-5 star control for each review. Real radio inputs, so it is
     keyboard operable and screen-reader friendly for free; the stars are laid
     out 5->1 in the DOM and reversed in CSS, which lets the "~" selector light
     every star from the chosen one downwards on hover. */
  const starEditor = (r) => {
    const cur = Math.max(1, Math.min(5, Math.round(Number(r.rating) || 1)));
    return `<span class="rate-set" role="radiogroup" aria-label="Rating for the review by ${esc(r.author)}"
              data-rev-rate="${r.id}" data-current="${cur}">
      ${[5, 4, 3, 2, 1].map(n => `
        <label class="rate-star">
          <input type="radio" name="rev-rate-${r.id}" value="${n}"${n === cur ? ' checked' : ''}>
          <span aria-hidden="true">★</span>
          <span class="sr-only">${n} star${n === 1 ? '' : 's'}</span>
        </label>`).join('')}
      <b class="rate-out" aria-hidden="true">${cur}</b>
    </span>`;
  };

  async function loadReviews() {
    const data = await api('/api/reviews/all');
    if (!data) throw new Error('Could not load reviews');
    const rows = data.reviews || [];

    $('#reviewsCount').textContent = data.total;
    $('[data-count="reviews"]').textContent = data.total;

    // headline cards
    const five = rows.filter(r => r.rating === 5).length;
    const low = rows.filter(r => r.rating <= 3).length;
    const verified = rows.filter(r => r.is_verified).length;
    const hidden = rows.filter(r => !r.is_published).length;
    $('#revStats').innerHTML = [
      ['Average rating', data.average != null ? data.average.toFixed(2) : '—', 'across every product'],
      ['Total reviews', String(data.total), 'posted from the product page'],
      ['5-star reviews', String(five), five && Math.round(five / rows.length * 100) + '% of all reviews'],
      ['3 stars or lower', String(low), low ? 'worth reading closely' : 'none to worry about'],
      ['Verified buyers', String(verified), 'email matched a real order'],
      ['Hidden from the site', String(hidden), hidden ? 'not shown to customers' : 'nothing hidden']
    ].map(([label, value, sub], i) => `
      <div class="mini-card" style="animation-delay:${i * 50}ms">
        <b>${esc(value)}</b><span>${esc(label)}</span><small>${esc(sub)}</small>
      </div>`).join('');

    // the list
    $('#revList').innerHTML = rows.length ? rows.map((r, i) => `
      <div class="rev-row${r.is_published ? '' : ' is-hidden'}" style="animation-delay:${Math.min(i, 14) * 40}ms">
        <span class="rev-pic"><img src="${IMG(PRODUCT_IMG(r.product_id))}" alt=""></span>
        <div class="rev-body">
          <div class="rev-top">
            <b>${esc(r.author)}</b>
            ${starEditor(r)}
            ${r.is_verified ? '<span class="chip-ok">Verified buyer</span>' : ''}
            ${r.is_published ? '' : '<span class="chip-warn">Hidden</span>'}
            <time>${when(r.created_at)}</time>
          </div>
          <p>${esc(r.body)}</p>
          <small class="rev-meta">${esc(PRODUCT_NAMES[r.product_id] || r.product_id)}${r.email ? ' · ' + esc(r.email) : ' · no email given'}</small>
        </div>
        <div class="row-actions">
          <button class="btn tiny" data-rev-toggle="${r.id}" data-published="${r.is_published}">${r.is_published ? 'Hide' : 'Show'}</button>
          <button class="btn tiny danger" data-rev-del="${r.id}" data-author="${esc(r.author)}">Delete</button>
        </div>
      </div>`).join('') : '<p class="sub" style="padding:22px">No reviews yet. They will appear here as customers post them on the product page.</p>';

    $$('[data-rev-del]').forEach(b => on(b, 'click', () => {
      askConfirm('Delete this review?',
        `The review by ${b.dataset.author} will be removed for good and the product's average will change.`,
        async () => {
          await api('/api/reviews/' + b.dataset.revDel, { method: 'DELETE' });
          toast('Review deleted', 'warn');
          loadReviews(); refreshCounts();
        });
    }));

    $$('[data-rev-toggle]').forEach(b => on(b, 'click', async () => {
      const next = b.dataset.published !== '1';
      await api('/api/reviews/' + b.dataset.revToggle, { method: 'PATCH', body: { is_published: next } });
      toast(next ? 'Review is live again' : 'Review hidden from the site');
      loadReviews();
    }));

    /* Wire the 1-5 star pickers. This must live inside loadReviews, because it
       re-runs every time the list is rebuilt - binding it once at load time would
       attach to nothing, since #revList is still empty at that point. */
    $$('.rate-set').forEach(set => {
      // keep the little number next to the stars in step while you hover
      const out = $('.rate-out', set);
      const paint = (n) => { if (out) out.textContent = String(n); };
      $$('.rate-star', set).forEach(label => {
        const n = Number($('input', label).value);
        on(label, 'mouseenter', () => paint(n));
        on(label, 'focus', () => paint(n));
      });
      on(set, 'mouseleave', () => paint(set.dataset.current));
      on(set, 'blur', () => paint(set.dataset.current));

      $$('input', set).forEach(input => on(input, 'change', async () => {
        const rating = Number(input.value);
        set.dataset.current = String(rating);
        paint(rating);
        // freeze the whole group until the server confirms, so a double click
        // cannot queue two conflicting saves
        $$('input', set).forEach(i => { i.disabled = true; });
        try {
          await api('/api/reviews/' + set.dataset.revRate, { method: 'PATCH', body: { rating } });
          toast('Rating saved: ' + rating + (rating === 1 ? ' star' : ' stars'));
          await loadReviews();
          refreshCounts();
        } catch (e) {
          toast(e.message || 'Could not save that rating', 'err');
          await loadReviews();
        } finally {
          $$('input', set).forEach(i => { i.disabled = false; });
        }
      }));
    });
  }

    on($('#revRefresh'), 'click', () => { loadReviews().catch(e => toast(e.message, 'err')); toast('Refreshed'); });

  /* ========================================================== SUBSCRIBERS */
  async function loadSubscribers() {
    const rows = await api('/api/subscribers');
    $('#subsCount').textContent = rows.length;
    $('#subsTable').innerHTML = `<thead><tr><th>Email</th><th>Source</th><th>Joined</th><th></th></tr></thead>
      <tbody>${rows.map((s, i) => `<tr style="animation-delay:${Math.min(i, 12) * 40}ms">
        <td class="strong">${esc(s.email)}</td>
        <td class="muted">${esc(s.source)}</td>
        <td class="muted">${when(s.created_at)}</td>
        <td class="row-actions"><button class="btn tiny danger" data-unsub="${esc(s.email)}">Remove</button></td>
      </tr>`).join('')}</tbody>`;
    $$('[data-unsub]').forEach(b => on(b, 'click', async () => {
      await api('/api/subscribers/' + encodeURIComponent(b.dataset.unsub), { method: 'DELETE' });
      toast('Subscriber removed', 'warn'); loadSubscribers(); refreshCounts();
    }));
  }
  on($('#subsRefresh'), 'click', async () => {
    const b = $('#subsRefresh');
    if (b) { b.disabled = true; b.textContent = 'Refreshing…'; }
    try { await loadSubscribers(); toast('Subscribers up to date'); }
    catch (e) { toast(e.message || 'Could not refresh', 'err'); }
    finally { if (b) { b.disabled = false; b.textContent = 'Refresh'; } }
  });
  on($('#exportSubs'), 'click', async () => {
    const rows = await api('/api/subscribers');
    const csv = 'email,source,joined\n' + rows.map(r => `${r.email},${r.source},${r.created_at}`).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = 'breezeguard-subscribers.csv';
    a.click();
    URL.revokeObjectURL(a.href);
    toast('CSV downloaded');
  });

  /* ============================================================== COUPONS */
  async function loadCoupons() {
    const rows = await api('/api/coupons');
    $('#couponsCount').textContent = rows.length;
    $('#couponGrid').innerHTML = rows.length ? rows.map((c, i) => `
      <article class="coupon" style="animation-delay:${Math.min(i, 8) * 60}ms">
        <div style="display:flex;align-items:center;gap:10px">
          <span class="c-code">${esc(c.code)}</span>
          <span class="badge ${c.is_active ? 'ok' : 'off'}">${c.is_active ? 'active' : 'off'}</span>
        </div>
        <div style="font-size:1.5rem;font-family:var(--font-d)">${esc(c.label)}</div>
        <div class="c-meta"><span>${c.kind === 'pct' ? c.value + '% off' : peso(c.value) + ' off'}</span><span>used ${c.uses}×</span><span>${c.expires_at ? 'ends ' + when(c.expires_at) : 'no expiry'}</span></div>
        <div class="c-foot">
          <button class="btn tiny ghost" data-edit-coupon="${esc(c.code)}">Edit</button>
          <button class="btn tiny ${c.is_active ? 'ghost' : 'primary'}" data-toggle-coupon="${esc(c.code)}" data-state="${c.is_active}">${c.is_active ? 'Deactivate' : 'Activate'}</button>
          <button class="btn tiny danger" data-del-coupon="${esc(c.code)}">Delete</button>
        </div>
      </article>`).join('') : `<div class="empty"><p>No coupons yet.</p></div>`;
    $$('[data-edit-coupon]').forEach(b => on(b, 'click', () => {
      const c = rows.find(x => x.code === b.dataset.editCoupon);
      openModal('Edit ' + c.code, COUPON_FIELDS, c,
        async (data) => { await api('/api/coupons/' + c.code, { method: 'PATCH', body: data }); toast('Coupon saved'); loadCoupons(); },
        'Save', wireAutoLabel);
    }));
    $$('[data-toggle-coupon]').forEach(b => on(b, 'click', async () => {
      await api('/api/coupons/' + b.dataset.toggleCoupon, { method: 'PATCH', body: { is_active: Number(b.dataset.state) ? 0 : 1 } });
      loadCoupons();
    }));
    $$('[data-del-coupon]').forEach(b => on(b, 'click', () => askConfirm('Delete coupon?', `${b.dataset.delCoupon} will stop working at checkout.`,
      async () => { await api('/api/coupons/' + b.dataset.delCoupon, { method: 'DELETE' }); toast('Coupon deleted', 'warn'); loadCoupons(); }, 'Delete')));
  }
  const COUPON_FIELDS = [
    { name: 'code', label: 'Code' },
    { name: 'kind', label: 'Type', type: 'select', options: [{ v: 'pct', t: 'Percentage' }, { v: 'flat', t: 'Flat peso' }] },
    { name: 'value', label: 'Value', type: 'number', min: 1, step: 1, hint: 'A percentage for "Percentage", a peso amount for "Flat peso"' },
    { name: 'label', label: 'Label', hint: 'Filled in for you - edit it if you want different wording' },
    { name: 'expires_at', label: 'Expires (optional)', type: 'date' },
    { name: 'is_active', label: 'Active', type: 'switch' }
  ];
  /* "10% off" / "₱50 off" - the same wording the storefront shows at checkout */
  function couponLabel(kind, value) {
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return '';
    return kind === 'flat' ? `₱${n.toLocaleString('en-PH')} off` : `${n}% off`;
  }
  function wireAutoLabel() {
    const f = $('#modalBody');
    if (!f) return;
    const label = f.querySelector('[name="label"]');
    let lastAuto = '';
    let custom = false;          // has the seller written their own wording?

    const generate = (force) => {
      if (!label) return;
      if (custom && !force) return;
      const kind = f.querySelector('[name="kind"]')?.value;
      const value = f.querySelector('[name="value"]')?.value;
      const next = couponLabel(kind, value);
      if (!next) return;
      label.value = next;
      lastAuto = next;
    };

    generate(true);   // fill it in the moment the dialog opens
    f.querySelector('[name="kind"]')?.addEventListener('change', () => generate(false));
    f.querySelector('[name="value"]')?.addEventListener('input', () => generate(false));
    label?.addEventListener('input', () => {
      // anything the seller typed that we did not generate counts as custom
      if (label.value !== lastAuto) custom = true;
    });
    label?.addEventListener('blur', () => {
      // an emptied label hands control back to the generated wording
      if (label && !label.value.trim()) { custom = false; generate(true); }
    });
  }

  on($('#addCoupon'), 'click', () => openModal('New coupon', COUPON_FIELDS,
    { kind: 'pct', value: 10, label: '10% off', is_active: true },
    async (data) => { await api('/api/coupons', { method: 'POST', body: data }); toast('Coupon created'); loadCoupons(); }, 'Create',
    wireAutoLabel));

  /* ============================================================= SETTINGS */
  async function loadSettings() {
    const s = await api('/api/settings');
    $('#s_store').value = s.store_name ?? '';
    $('#s_hero').value = s.hero_headline ?? '';
    $('#s_sub').value = s.hero_subtext ?? '';
    $('#s_ann').value = s.announcement ?? '';
    $('#s_email').value = s.support_email ?? '';
    $('#s_phone').value = s.support_phone ?? '';
    $('#s_free').value = s.free_shipping_threshold ?? 1500;
    $('#s_metro').value = s.shipping_metro ?? 59;
    $('#s_prov').value = s.shipping_provincial ?? 129;
    $('#s_cur').value = s.currency ?? 'PHP';
  }
  const saveSettings = (form) => async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    await api('/api/settings', { method: 'PATCH', body: data });
    toast('Settings saved — the storefront picks these up on its next load');
  };
  on($('#settingsForm'), 'submit', saveSettings($('#settingsForm')));
  on($('#shipForm'), 'submit', saveSettings($('#shipForm')));

  async function reseed() {
    askConfirm('Restore demo data?', 'The catalogue, orders, customers and messages go back to the seeded sample set. Anything you added will be lost.',
      async () => {
        const res = await fetch('/api/admin/reseed', { method: 'POST' });
        if (!res.ok) { toast('Use: node seed.mjs in the breezeguard-db folder', 'warn', 6000); return; }
        toast('Demo data restored'); await refreshCounts(); load(current);
      }, 'Restore');
  }
  on($('#reseed'), 'click', reseed);
  on($('#reseed2'), 'click', reseed);

  /* --------------------------------------------------------- drawer/scrim */
  function openDrawer() { $('#drawer').classList.add('open'); $('#scrim').classList.add('show'); }
  function closeDrawer() { $('#drawer').classList.remove('open'); $('#scrim').classList.remove('show'); }
  on($('#scrim'), 'click', closeDrawer);
  $$('[data-close-drawer]').forEach(b => on(b, 'click', closeDrawer));
  on(document, 'keydown', (e) => {
    if (e.key !== 'Escape') return;
    if ($('.reply-box')) {                       // a reply box wins over the rest
      const id = Number($('.reply-box').dataset.replyFor);
      openThreads.delete(id);
      loadMessages();
      return;
    }
    closeDrawer(); closeModal(); $('#confirm').hidden = true;
  });

  /* ------------------------------------------------------- search + counts */
  let searchTimer;
  on($('#q'), 'input', (e) => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      const v = e.target.value.trim();
      if (current === 'orders') { orderSearch = v; loadOrders(); }
      else if (current === 'products') { /* filtered client-side below */ }
      else if (current === 'customers') { /* client-side */ }
    }, 260);
  });
  async function refreshCounts() {
    try {
      const s = await api('/api/stats');
      $('[data-count="orders"]').textContent = s.kpis.open_orders;
      $('[data-count="messages"]').textContent = s.kpis.unread_messages;
      const subs = await api('/api/subscribers');
      $('[data-count="subscribers"]').textContent = subs.length;
      const revs = await api('/api/reviews/all');
      $('[data-count="reviews"]').textContent = revs?.total ?? '';
    } catch { /* ignore */ }
  }

  /* ----------------------------------------------------------- live feed */
  let lastOrderId = null;
  let lastSubsAt = null;
  async function poll() {
    if (document.hidden) return;
    try {
      const rows = await api('/api/orders?limit=1');
      const newest = rows[0];
      if (newest) {
        if (lastOrderId === null) { lastOrderId = newest.id; }
        else if (newest.id !== lastOrderId) {
          lastOrderId = newest.id;
          const isNew = newest.status === 'pending';
          toast(`New order ${newest.order_no} · ${peso(newest.total)} · ${newest.customer_name}`, isNew ? 'new' : 'ok');
          if (current === 'dashboard') loadStats();
          if (current === 'orders') loadOrders();
          refreshCounts();
          const pill = $('[data-count="orders"]');
          pill.classList.remove('bump'); void pill.offsetWidth; pill.classList.add('bump');
        }
      }
    } catch { /* server asleep */ }

    /* Newsletter sign-ups used to go unnoticed: this loop only watched orders,
       so a new subscriber sat in the database until the page was reloaded.
       Watch the list itself and refresh whatever the operator is looking at. */
    try {
      const subs = await api('/api/subscribers');
      if (!Array.isArray(subs)) return;
      const newestAt = subs.length ? subs[0].created_at : null;
      if (lastSubsAt === null) { lastSubsAt = newestAt; }
      else if (newestAt !== lastSubsAt) {
        const fresh = subs.find(s => s.created_at === newestAt) || subs[0];
        lastSubsAt = newestAt;
        toast('New subscriber · ' + fresh.email, 'ok');
        if (current === 'subscribers') loadSubscribers();
        if (current === 'dashboard') loadStats();
        const pill = $('[data-count="subscribers"]');
        if (pill) { pill.classList.remove('bump'); void pill.offsetWidth; pill.classList.add('bump'); }
      }
      const badge = $('[data-count="subscribers"]');
      if (badge) badge.textContent = subs.length;
    } catch { /* server asleep */ }
  }

  /* ---- instant updates ----
     poll() above is only a safety net now. The server pushes an event the
     moment a row is written, so a new subscriber or order shows up immediately
     instead of after the polling interval. */
  const afterSubscriberChange = async () => {
    const subs = await api('/api/subscribers');
    if (!Array.isArray(subs)) return;
    const newestAt = subs.length ? subs[0].created_at : null;
    if (lastSubsAt !== null && newestAt !== lastSubsAt) {
      toast('New subscriber · ' + subs[0].email, 'ok');
      const pill = $('[data-count="subscribers"]');
      if (pill) { pill.classList.remove('bump'); void pill.offsetWidth; pill.classList.add('bump'); }
    }
    lastSubsAt = newestAt;
    const badge = $('[data-count="subscribers"]');
    if (badge) badge.textContent = subs.length;
    if (current === 'subscribers') loadSubscribers();
    if (current === 'dashboard') loadStats();
  };

  const afterOrderChange = async () => {
    const rows = await api('/api/orders?limit=1');
    const newest = rows && rows[0];
    if (newest && lastOrderId !== null && newest.id !== lastOrderId) {
      toast(`New order ${newest.order_no} · ${peso(newest.total)} · ${newest.customer_name}`,
        newest.status === 'pending' ? 'new' : 'ok');
      const pill = $('[data-count="orders"]');
      if (pill) { pill.classList.remove('bump'); void pill.offsetWidth; pill.classList.add('bump'); }
    }
    if (newest) lastOrderId = newest.id;
    if (current === 'dashboard') loadStats();
    if (current === 'orders') loadOrders();
    refreshCounts();
  };

  let liveStream = null;
  async function primeLive() {
    // Establish "what was already there" up front, otherwise the first sign-up
    // after the page loads has nothing to compare against and goes unannounced.
    try {
      const subs = await api('/api/subscribers');
      if (Array.isArray(subs)) lastSubsAt = subs.length ? subs[0].created_at : null;
      const rows = await api('/api/orders?limit=1');
      if (rows && rows[0]) lastOrderId = rows[0].id;
    } catch { /* server asleep */ }
  }
  function startLive() {
    if (typeof EventSource === 'undefined') return false;
    try { liveStream = new EventSource('/api/events'); }
    catch { return false; }
    liveStream.addEventListener('subscribers', () => { afterSubscriberChange().catch(() => {}); });
    liveStream.addEventListener('orders', () => { afterOrderChange().catch(() => {}); });
    liveStream.addEventListener('customers', () => {
      // a first-time buyer becomes a customer when their order is placed
      if (current === 'customers') loadCustomers();
      if (current === 'dashboard') loadStats();
      refreshCounts();
    });
    // EventSource reconnects on its own; poll() is the fallback if it cannot
    return true;
  }
  startLive();
  primeLive();
  setInterval(poll, 20000);        // backstop only, no longer the main path

  /* icons */
  const pesoIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M6 4h8M6 9h8M13 4c1.6 2.4 2 3.6 2 5.2 0 2.6-1.6 4.3-4 4.8"/><path d="M6 20h12"/></svg>';
  const boxIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8l9-5 9 5v8l-9 5-9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/></svg>';
  const clockIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.4 2"/></svg>';
  const warnIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4l9 16H3z"/><path d="M12 10v4M12 17h.01"/></svg>';

  /* --------------------------------------------------------------- boot -- */
  const LOADERS = {
    dashboard: loadStats,
    orders: loadOrders,
    products: loadProducts,
    customers: loadCustomers,
    messages: loadMessages,
    reviews: loadReviews,
    subscribers: loadSubscribers,
    coupons: loadCoupons,
    settings: loadSettings
  };
  function load(view) { (LOADERS[view] || loadStats)().catch(e => toast(e.message, 'err')); }

  const hash = location.hash.replace('#', '');
  go(TITLES[hash] ? hash : 'dashboard');
  poll();

  /* first contact with the server */
  api('/api/health').then(h => {
    if (!h?.ok) throw new Error('down');
    setOffline(false);
  }).catch(() => setOffline(true, 'network'));

  let rz;
  addEventListener('resize', () => { clearTimeout(rz); rz = setTimeout(() => { if (current === 'dashboard') loadStats(); }, 260); });
})();