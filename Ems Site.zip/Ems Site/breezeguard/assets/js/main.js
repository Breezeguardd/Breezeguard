/* ============================================================
   BREEZEGUARD — site behaviour
   1. helpers      2. theme + header      3. scroll motion
   4. cart engine  5. drawer + fly anim   6. checkout flow
   7. UI widgets   8. forms               9. boot
   ============================================================ */
(() => {
  'use strict';

  /* ---------- 1. HELPERS ---------- */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const on = (el, ev, fn, o) => el && el.addEventListener(ev, fn, o);
  const money = (n) => new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP', maximumFractionDigits: 2 }).format(n || 0);
  // Links written into the DOM by JS bypass the host's link rewriting (Netlify
  // turns products.html into /products in the HTML it serves), so build the
  // same clean URLs here. Opened straight from a folder, keep the .html files.
  const HOSTED = location.protocol !== 'file:';
  const BASE = HOSTED ? location.pathname.replace(/[^/]*$/, '') : '';
  const pageUrl = (file) => (HOSTED ? BASE + file.replace(/\.html$/, '') : file);
  const KEY = 'bg_cart_v2';
  /* Discount codes come from the database, so a coupon made in the dashboard
     works at checkout straight away. These two are only the fallback for when
     the shop is running without a database. */
  const OFFLINE_COUPONS = { BREEZE10: { type: 'pct', value: 10, label: '10% off' }, BREEZE50: { type: 'flat', value: 50, label: '₱50 off' } };
  const COUPONS = { ...OFFLINE_COUPONS };

  const couponLive = (c) => {
    if (!c || c.is_active === 0 || c.is_active === false) return false;
    if (!c.expires_at) return true;
    const until = new Date(String(c.expires_at).replace(' ', 'T') + (String(c.expires_at).length <= 10 ? 'T23:59:59' : ''));
    return !Number.isNaN(until.getTime()) && until.getTime() > Date.now();
  };

  async function loadCoupons() {
    if (!DB.online) return;
    const rows = await apiGet('/api/coupons');
    if (!Array.isArray(rows)) return;
    const live = {};
    for (const c of rows) {
      if (!couponLive(c)) continue;
      live[String(c.code).toUpperCase()] = {
        type: c.kind === 'flat' ? 'flat' : 'pct',
        value: Number(c.value) || 0,
        label: c.label || (c.kind === 'flat' ? `₱${c.value} off` : `${c.value}% off`)
      };
    }
    for (const k of Object.keys(COUPONS)) delete COUPONS[k];
    Object.assign(COUPONS, live);
    // a code that has since been switched off must stop applying
    if (coupNow && !COUPONS[coupNow]) { coupNow = null; store.set('bg_coupon', null); }
  }

  /* Everything the storefront shows used to be a one-off read when the page
     opened, so deleting a review or a customer in the dashboard left the shop
     showing the old numbers until a customer hit refresh. The server pushes an
     event on every write, and one stream now keeps all of it in step. */
  let liveStream = null;
  function watchCouponChanges() {
    if (typeof EventSource === 'undefined') return false;
    try { liveStream = new EventSource('/api/events'); }
    catch { return false; }

    liveStream.addEventListener('coupons', () => {
      loadCoupons().then(() => {
        // if the cart is on screen, the discount line and totals must follow
        if ($('[data-coupon-msg]')) { paint(); renderCartPage(); }
      }).catch(() => {});
    });

    // review count, average, verified tally and the stars on each product card
    liveStream.addEventListener('reviews', () => {
      // each step is isolated: one failing must not stop the others
      try { paintRealStats().catch(() => {}); } catch { }
      try { reloadReviewList(); } catch { }
      try { reloadTestimonials().catch(() => {}); } catch { }
    });
    // customers served, and the stock/price figures an order can move
    liveStream.addEventListener('customers', () => { try { paintRealStats().catch(() => {}); } catch { } });
    liveStream.addEventListener('orders', () => {
      try { paintRealStats().catch(() => {}); } catch { }
      try { reloadReviewList(); } catch { }
      try { reloadTestimonials().catch(() => {}); } catch { }
    });
    liveStream.addEventListener('subscribers', () => { try { paintRealStats().catch(() => {}); } catch { } });
    // phone, email and the shipping figures printed in the help text
    liveStream.addEventListener('settings', () => { try { refreshSettings().catch(() => {}); } catch { } });
    return true;
  }

  /* Re-read settings into the page. Shared by boot and by the live stream so
     the shipping rates and contact details follow the dashboard. */
  async function refreshSettings() {
    const s = await apiGet('/api/settings');
    if (!s) return;
    if (Number.isFinite(Number(s.free_shipping_threshold))) FREE_SHIP = Number(s.free_shipping_threshold);
    if (Number.isFinite(Number(s.shipping_metro))) SHIP_RATES.metro = Number(s.shipping_metro);
    if (Number.isFinite(Number(s.shipping_provincial))) SHIP_RATES.provincial = Number(s.shipping_provincial);
    const shipLive = { metro: SHIP_RATES.metro, provincial: SHIP_RATES.provincial, free: FREE_SHIP };
    $$('[data-live-ship]').forEach(el => {
      const v = shipLive[el.dataset.liveShip];
      if (Number.isFinite(Number(v))) el.textContent = money(Number(v));
    });
    const fill = (sel, value) => $$(sel).forEach(n => {
      if (n.children.length === 0) n.textContent = value;
    });
    if (s.support_email) fill('[data-live-email]', s.support_email);
    if (s.support_phone) fill('[data-live-phone]', s.support_phone);
    $$('[data-free-ship-note]').forEach(el => { el.textContent = `Free shipping automatically applies over ${money(FREE_SHIP)}.`; });
    if ($('[data-cart-summary], [data-drawer-foot]')) { paint(); renderCartPage(); }
  }  // the product page keeps its review list and star filter; re-read both
  function reloadReviewList() {
    if (typeof revInit !== 'function') return;
    try {
      // revInit returns a no-op on pages with no review panel, so wrap whatever
      // it gives us - calling .catch() on undefined would break the whole handler
      Promise.resolve(revInit()).catch(() => {});
    } catch { /* nothing to refresh on this page */ }
  }


  const FREE_SHIP_DEFAULT = 1500;
  let FREE_SHIP = FREE_SHIP_DEFAULT;
  let SHIP_RATES = { metro: 59, provincial: 129, pickup: 0 };
  const SHIP_LABEL = { metro: 'Metro Manila courier · 1–2 days', provincial: 'Provincial courier · 3–5 days', pickup: 'Pick up at our shop · Cagayan de Oro City' };

  /* ---- optional database link -------------------------------------------
     When the site is served by breezeguard-db/server.mjs the API answers and
     orders are saved for real. On a plain static host (Netlify) every call
     fails quietly and the shop keeps working from localStorage.            */
  const DB = { online: false };
  const apiPost = async (path, body) => {
    if (!DB.online) return null;
    try {
      const res = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      return res.ok ? await res.json() : null;
    } catch { return null; }
  };
  const apiGet = async (path) => {
    if (!DB.online) return null;
    try { const res = await fetch(path); return res.ok ? await res.json() : null; }
    catch { return null; }
  };
  // catalogue SKU for each add-to-cart button, so orders match real product rows
  const SKU = { classic: 'BG-CLS-SGE', twin: 'BG-TWN-SGE', mini: 'BG-MIN-SGE', deck: 'BG-DCK-SGE', kit: 'BG-KIT-2X', refill: 'BG-RFL-10' };
  // which product picture represents each cart line
  const CART_IMG = (id) => ({
    classic: 'product-classic.png', twin: 'product-twin.png', mini: 'product-mini.png',
    deck: 'product-deck.png', kit: 'product-kit.png', refill: 'pad.svg'
  })[id] || 'product-classic.png';

  const store = {
    get(k, f) { try { return JSON.parse(localStorage.getItem(k)) ?? f; } catch { return f; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } }
  };

  /* ---------- 2. THEME + HEADER ---------- */
  const root = document.documentElement;
  const setTheme = (t) => {
    root.dataset.theme = t;
    store.set('bg_theme', t);
    $$('[data-theme-toggle]').forEach(b => {
      b.setAttribute('aria-label', t === 'night' ? 'Switch to day mode' : 'Switch to night mode');
      b.innerHTML = t === 'night' ? sunIcon : moonIcon;
    });
  };
  const sunIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.4v2.2M12 19.4v2.2M4.2 12H2M22 12h-2.2M5.6 5.6 4 4M20 20l-1.6-1.6M18.4 5.6 20 4M4 20l1.6-1.6"/></svg>';
  const moonIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.2A8.4 8.4 0 0 1 9.8 4a8.4 8.4 0 1 0 10.2 10.2Z"/></svg>';
  setTheme(store.get('bg_theme', 'night'));
  $$('[data-theme-toggle]').forEach(b => on(b, 'click', () => setTheme(root.dataset.theme === 'night' ? 'day' : 'night')));

  // mobile menu
  const mm = $('.mobile-menu');
  const toggleMenu = (force) => {
    const open = force ?? !mm.classList.contains('open');
    mm.classList.toggle('open', open);
    document.body.classList.toggle('no-scroll', open);
    document.body.classList.toggle('menu-open', open);
    if (open) $$('a', mm).forEach((a, i) => a.style.transitionDelay = 120 + i * 70 + 'ms');
  };
  on($('.burger'), 'click', () => toggleMenu());
  $$('a', mm || document).forEach(a => on(a, 'click', () => toggleMenu(false)));
  on(document, 'keydown', e => e.key === 'Escape' && (toggleMenu(false), closeDrawer(), closeScrim()));

  // mark active nav link
  const page = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  $$('.menu a, .mobile-menu a, .foot-links a').forEach(a => {
    const href = (a.getAttribute('href') || '').toLowerCase();
    if (href === page || (page === '' && href === 'index.html')) a.classList.add('active');
  });

  /* ---------- 3. SCROLL MOTION ---------- */
  const head = $('.site-head'), bar = $('.progress'), toTop = $('.to-top');
  let ticking = false;
  const onScroll = () => {
    const y = scrollY;
    head?.classList.toggle('stuck', y > 24);
    toTop?.classList.toggle('show', y > 700);
    const max = document.documentElement.scrollHeight - innerHeight;
    if (bar) bar.style.width = (max > 0 ? (y / max) * 100 : 0) + '%';
    ticking = false;
  };
  addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
  onScroll();
  on(toTop, 'click', () => scrollTo({ top: 0, behavior: 'smooth' }));

  // reveal on scroll
  const revealer = 'IntersectionObserver' in window ? new IntersectionObserver((entries) => {
    entries.forEach(en => {
      if (!en.isIntersecting) return;
      en.target.classList.add('in');
      revealer.unobserve(en.target);
      if (en.target.dataset.count !== undefined) countUp(en.target);
    });
  }, { threshold: 0.16, rootMargin: '0px 0px -40px' }) : null;

  if (revealer) {
    $$('[data-reveal]').forEach(el => revealer.observe(el));
    // counters animate as soon as they scroll into view
    $$('[data-count]').forEach(el => revealer.observe(el));
  } else {
    // no observer support: show everything straight away
    $$('[data-reveal], [data-count]').forEach(el => {
      el.classList.add('in');
      if (el.dataset.count !== undefined) countUp(el);
    });
  }

  function countUp(el) {
    const end = parseFloat(el.dataset.count), dur = 1400, t0 = performance.now();
    const dec = (el.dataset.count.split('.')[1] || '').length;
    const step = (t) => {
      const p = Math.min((t - t0) / dur, 1), eased = 1 - Math.pow(1 - p, 3);
      el.textContent = (end * eased).toFixed(dec);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }


  /* ---------- product image gallery ----------
     The thumbnails used to be plain <span>s with no handler at all, so clicking
     one did nothing. They are real buttons now: swap the main picture, mark the
     pressed one, and keep the choice reachable by keyboard. */
  const mainShot = $('[data-device] img, .pdp-media .device-wrap img');
  const swatches = $$('.thumbs .thumb');
  if (mainShot && swatches.length) {
    swatches.forEach((btn, i) => on(btn, 'click', () => {
      const pic = $('img', btn);
      if (!pic) return;
      const next = pic.getAttribute('src');
      if (!next || next === mainShot.getAttribute('src')) return;

      const preload = new Image();
      preload.src = next;                       // swap only once it has decoded
      const show = () => {
        mainShot.src = next;
        mainShot.alt = pic.alt || mainShot.alt;
        swatches.forEach((b, k) => {
          b.classList.toggle('on', k === i);
          b.setAttribute('aria-pressed', k === i ? 'true' : 'false');
        });
        mainShot.classList.remove('shot-swap');
        void mainShot.offsetWidth;
        mainShot.classList.add('shot-swap');
      };
      preload.complete ? show() : preload.addEventListener('load', show, { once: true });
    }));

    // left/right arrows move between them, the usual gallery convention
    $('[data-device]')?.addEventListener('keydown', e => { /* images are not focusable; buttons handle keys */ });
    swatches.forEach((b, i) => on(b, 'keydown', e => {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      e.preventDefault();
      const nextIdx = (i + (e.key === 'ArrowRight' ? 1 : -1) + swatches.length) % swatches.length;
      swatches[nextIdx].focus();
      swatches[nextIdx].click();
    }));
  }

  // pointer glow + device tilt
  $$('.card').forEach(c => on(c, 'pointermove', e => {
    const r = c.getBoundingClientRect();
    c.style.setProperty('--mx', ((e.clientX - r.left) / r.width) * 100 + '%');
    c.style.setProperty('--my', ((e.clientY - r.top) / r.height) * 100 + '%');
  }));
  const tilt = $('.device-wrap[data-tilt]');
  if (tilt && matchMedia('(pointer:fine)').matches) {
    const stage = tilt.closest('.hero-stage, .pdp-media') || tilt.parentElement;
    on(stage, 'pointermove', e => {
      const r = stage.getBoundingClientRect();
      const dx = (e.clientX - r.left) / r.width - .5, dy = (e.clientY - r.top) / r.height - .5;
      tilt.style.transform = `perspective(900px) rotateY(${dx * 14}deg) rotateX(${-dy * 12}deg) translateY(-6px)`;
    });
    on(stage, 'pointerleave', () => { tilt.style.transform = ''; });
  }

  /* ---------- 4. CART ENGINE ---------- */
  let cart = store.get(KEY, []);
  let coupNow = store.get('bg_coupon', null);
  let shipMethod = store.get('bg_ship', 'metro');

  const save = () => { store.set(KEY, cart); store.set('bg_coupon', coupNow); store.set('bg_ship', shipMethod); paint(); };
  const cartCount = () => cart.reduce((n, i) => n + i.qty, 0);
  const subtotal = () => cart.reduce((n, i) => n + i.price * i.qty, 0);

  function discount() {
    if (!coupNow || !COUPONS[coupNow]) return 0;
    const c = COUPONS[coupNow];
    // rounded the same way the server rounds it, so the two totals always match
    return c.type === 'pct' ? Math.round(subtotal() * c.value / 100) : Math.min(c.value, subtotal());
  }
  const shipping = () => (cart.length === 0 || subtotal() - discount() >= FREE_SHIP) ? 0 : (SHIP_RATES[shipMethod] ?? 0);
  const total = () => Math.max(0, subtotal() - discount() + shipping());

  function addItem(item) {
    const key = item.id + '|' + (item.variant || '');
    const found = cart.find(i => i.key === key);
    if (found) found.qty += item.qty || 1;
    else cart.push({ ...item, key, qty: item.qty || 1 });
    save();
    bumpBadge();
  }
  function setQty(key, qty) {
    const it = cart.find(i => i.key === key);
    if (!it) return;
    it.qty = qty;
    if (it.qty <= 0) cart = cart.filter(i => i.key !== key);
    save();
  }

  function paint() {
    const n = cartCount();
    $$('[data-cart-count]').forEach(b => {
      b.textContent = n;
      b.classList.toggle('show', n > 0);
    });
    // keep every cart link's accessible name in step with the visible count
    // (match on the data attribute, not the href — hosts like Netlify rewrite
    //  cart.html to /cart in the HTML they serve, which breaks href selectors)
    $$('[data-open-cart], [data-cart-link]').forEach(a => a.setAttribute('aria-label', `Open cart, ${n} item${n === 1 ? '' : 's'}`));
    $$('[data-cart-total-mini]').forEach(el => el.textContent = money(total()));
    renderDrawer(); renderCartPage();
  }

  function lineItemHTML(i) {
    const minus = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M5 12h14"/></svg>';
    const plus = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>';
    return `<div class="line-item" data-key="${i.key}">
      <div class="thumb"><img src="assets/img/${CART_IMG(i.id)}" alt="" class="${i.img || ''}"></div>
      <div>
        <p class="line-name">${i.name}</p>
        <div class="meta">${i.variant || 'Standard'} · ${money(i.price)}</div>
        <div class="qty" style="margin-top:9px">
          <button data-dec aria-label="Decrease quantity of ${i.name}">${minus}</button><span>${i.qty}</span><button data-inc aria-label="Increase quantity of ${i.name}">${plus}</button>
        </div>
      </div>
      <div class="row-end">
        <b>${money(i.price * i.qty)}</b>
        <button class="link-x" data-remove>Remove</button>
      </div>
    </div>`;
  }

  function totalsHTML() {
    const d = discount();
    return `<div class="totals">
      <div><span>Subtotal (${cartCount()} item${cartCount() === 1 ? '' : 's'})</span><span>${money(subtotal())}</span></div>
      ${d ? `<div style="color:var(--brand)"><span>Discount · ${COUPONS[coupNow].label}</span><span>−${money(d)}</span></div>` : ''}
      <div><span>Delivery${shipping() === 0 && cart.length ? ' <small style="color:var(--brand)">(free)</small>' : ''}</span><span>${cart.length ? (shipping() === 0 ? 'FREE' : money(shipping())) : '—'}</span></div>
      <div class="grand"><span>Total</span><span>${money(total())}</span></div>
    </div>`;
  }

  function renderDrawer() {
    const body = $('[data-drawer-body]'); if (!body) return;
    body.innerHTML = cart.length
      ? cart.map(lineItemHTML).join('')
      : `<div class="drawer-empty"><svg viewBox="0 0 24 24" width="46" height="46" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>
         <p>Your cart is empty.<br>Night bites are coming.</p>
         <a class="btn btn-primary" href="${pageUrl('products.html')}">Shop the collection</a></div>`;
    const foot = $('[data-drawer-foot]');
    if (foot) foot.innerHTML = cart.length
      ? `${totalsHTML()}<a class="btn btn-primary btn-block btn-lg" href="${pageUrl('cart.html')}">Checkout · ${money(total())}</a><a class="btn btn-ghost btn-block btn-sm" href="${pageUrl('products.html')}">Keep shopping</a>`
      : '';
  }

  function renderCartPage() {
    const wrap = $('[data-cart-items]'); if (!wrap) return;
    if (!cart.length) {
      wrap.innerHTML = `<div class="card center" style="padding:60px 24px">
        <h2 style="font-size:1.3rem">Your cart is empty</h2><p class="mt-s">Add a Breezeguard and sleep without bites.</p>
        <a class="btn btn-primary mt-m" href="${pageUrl('products.html')}">Browse products</a></div>`;
    } else {
      wrap.innerHTML = `<div class="grid" style="gap:14px">${cart.map(lineItemHTML).join('')}</div>`;
    }
    const sum = $('[data-cart-summary]');
    if (sum) sum.innerHTML = totalsHTML();
    $$('[data-ship-option]').forEach(l => {
      const input = $('input', l);
      if (input) input.checked = l.dataset.shipOption === shipMethod;
    });
    // hide the checkout flow when there is nothing to check out
    const flow = $('.co-flow'), stepsNav = $('.steps-nav');
    if (flow) flow.hidden = !cart.length;
    if (stepsNav) stepsNav.hidden = !cart.length;
  }

  /* ---------- 5. DRAWER + FLY-TO-CART ---------- */
  const drawer = $('.drawer'), scrim = $('.scrim');
  const openDrawer = () => { drawer?.classList.add('open'); scrim?.classList.add('show'); document.body.classList.add('no-scroll'); };
  const closeDrawer = () => { drawer?.classList.remove('open'); scrim?.classList.remove('show'); document.body.classList.remove('no-scroll'); };
  const closeScrim = () => closeDrawer();
  $$('[data-open-cart]').forEach(b => on(b, 'click', e => { e.preventDefault(); openDrawer(); }));
  $$('[data-close-cart]').forEach(b => on(b, 'click', closeDrawer));
  on(scrim, 'click', closeDrawer);

  function bumpBadge() {
    $$('[data-cart-count]').forEach(b => { b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop'); });
  }

    function flyToCart(sourceEl) {
      const target = $('[data-open-cart]');
      if (!target || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      if (!sourceEl) sourceEl = target;   // always give the shopper the flight
      const from = sourceEl.getBoundingClientRect(), to = target.getBoundingClientRect();
      if (!from.width || !to.width) return;

      const x0 = from.left + from.width / 2, y0 = from.top + from.height / 2;
      const x1 = to.left + to.width / 2, y1 = to.top + to.height / 2;

      const ghost = document.createElement('div');
      ghost.className = 'fly-ghost';
      ghost.style.setProperty('--fs', Math.max(46, Math.min(104, Math.round(from.height * 0.5))) + 'px');

      // carry the product visual. Product shots are inline SVG on the cards,
      // so a photo is not always there to copy - clone the drawing instead.
      const pic = sourceEl.tagName === 'IMG' ? sourceEl : sourceEl.querySelector('img');
      if (pic && pic.getAttribute('src')) {
        const img = document.createElement('img');
        img.src = pic.currentSrc || pic.src;
        img.alt = '';
        ghost.appendChild(img);
      } else {
        const copy = sourceEl.cloneNode(true);
        copy.removeAttribute('data-tilt');
        copy.style.cssText = 'width:100%;height:100%;object-fit:contain;animation:none';
        ghost.appendChild(copy);
      }
      document.body.appendChild(ghost);

      // a control point above the midpoint is what gives the flight its lift
      const lift = Math.max(70, Math.min(230, Math.abs(x1 - x0) * 0.32 + 80));
      // clamp the apex so a tall page cannot fling the badge off the top
      const cx = (x0 + x1) / 2, cy = Math.max(64, Math.min(y0, y1) - lift);

      const canArc = window.CSS && CSS.supports && CSS.supports('offset-path', 'path("M 0 0 L 1 1")');
      if (canArc) {
        ghost.style.offsetPath = 'path("M ' + x0 + ' ' + y0 + ' Q ' + cx + ' ' + cy + ' ' + x1 + ' ' + y1 + '")';
        // two frames: one to commit offset-path, one to start the transition
        requestAnimationFrame(() => requestAnimationFrame(() => {
          ghost.style.offsetDistance = '100%';
          ghost.style.scale = '0.2';
          ghost.style.opacity = '0.12';
        }));
      } else {
        ghost.classList.add('fly-straight');
        ghost.style.setProperty('--dx', (x1 - x0) + 'px');
        ghost.style.setProperty('--dy', (y1 - y0) + 'px');
      }

      // pop the badge and ring the cart button as it lands
      setTimeout(() => {
        ghost.remove();
        $$('[data-cart-count]').forEach(b => {
          b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop');
        });
        target.classList.remove('landed'); void target.offsetWidth; target.classList.add('landed');
        const ring = document.createElement('span');
        ring.className = 'cart-land-ring';
        (target.parentElement || target).appendChild(ring);
        setTimeout(() => { ring.remove(); target.classList.remove('landed'); }, 540);
      }, 800);
    }

  // delegated cart clicks + add-to-cart
  document.addEventListener('click', (e) => {
    const add = e.target.closest('[data-add]');
    if (add) {
      e.preventDefault();
      // a sold-out item can never be added, however the click arrived
      if (STOCK.on && stockOf(add.dataset.id) === 0) {
        toast('That one is out of stock right now.', 'err');
        return;
      }
      // use the quantity stepper only if the button sits in the same block as one
      const scope = add.closest('.pdp, .p-card, .drawer, li, form') || document;
      const qty = parseInt($('[data-qty-value]', scope)?.textContent || '1', 10);
      addItem({
        id: add.dataset.id || add.dataset.add, name: add.dataset.name, price: parseFloat(add.dataset.price),
        variant: add.dataset.variant, img: add.dataset.img || '', url: add.dataset.url || pageUrl('products.html'),
        sku: SKU[add.dataset.id] || '', variantSku: add.dataset.variantSku || '', qty
      });
      // Find the product picture to fly. closest() returns the NEAREST match, so a
      // bare "div" in the list used to hand back a tight wrapper with no image in
      // it, the lookup came back null and the whole animation silently did nothing.
      const cardScope = add.closest('.p-card, .pdp, .p-quick, .feature, li, tr') || add.parentElement;
      const flyer = cardScope?.querySelector('.p-media img, .device-wrap, .thumb img, img')
        || add.closest('.p-card, .pdp, li, tr')?.querySelector('img')
        || add;
      flyToCart(flyer);
      toast(`${add.dataset.name} added to cart`);
      // deliberately no drawer: the item flies into the cart button instead, and
      // the cart opens only when that button is clicked.
      return;
    }
    const li = e.target.closest('.line-item');
    if (li) {
      const key = li.dataset.key;
      if (e.target.closest('[data-inc]')) setQty(key, (cart.find(i => i.key === key)?.qty || 0) + 1);
      if (e.target.closest('[data-dec]')) setQty(key, (cart.find(i => i.key === key)?.qty || 0) - 1);
      if (e.target.closest('[data-remove]')) { li.classList.add('removing'); setTimeout(() => setQty(key, 0), 300); }
    }
    const ship = e.target.closest('input[name="ship"]');
    if (ship) { shipMethod = ship.value; save(); }
  });
  document.addEventListener('change', (e) => {
    if (e.target.name === 'ship') { shipMethod = e.target.value; save(); }
  });

  /* ---------- 6. CHECKOUT FLOW ---------- */
  const panelIds = ['panel-delivery', 'panel-payment', 'panel-review'];
  let stepIdx = 0;

  function showStep(i) {
    stepIdx = Math.max(0, Math.min(i, panelIds.length));
    $$('.co-panel').forEach((p, k) => p.classList.toggle('on', k === stepIdx));
    $$('.step-pill').forEach((p, k) => {
      p.classList.toggle('on', k === stepIdx);
      p.classList.toggle('done', k < stepIdx);
      const i2 = $('i', p); if (i2) i2.innerHTML = k < stepIdx ? '✓' : (k + 1);
    });
    const top = $('.steps-nav')?.getBoundingClientRect().top ?? 0;
    if (stepIdx > 0) scrollTo({ top: scrollY + top - 120, behavior: 'smooth' });
  }

  const rules = {
    required: (v) => v.trim().length > 0,
    email: (v) => /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(v.trim()),
    phone: (v) => /^(\+?63|0)?9\d{9}$/.test(v.replace(/[\s-]/g, '')),
    zip: (v) => /^\d{4}$/.test(v.trim())
  };
  function validate(scope) {
    let ok = true, first = null;
    $$('[data-req]', scope).forEach(f => {
      const kind = f.dataset.req, val = f.value || '';
      const good = rules[kind] ? rules[kind](val) : rules.required(val);
      f.classList.toggle('err', !good);
      const msg = f.parentElement.querySelector('.err-msg');
      if (msg) msg.classList.toggle('show', !good);
      if (!good && !first) first = f;
      ok = ok && good;
    });
    if (first) { first.focus(); shake(first); }
    return ok;
  }
  const shake = (el) => { el.animate([{ transform: 'translateX(0)' }, { transform: 'translateX(-7px)' }, { transform: 'translateX(7px)' }, { transform: 'translateX(0)' }], { duration: 320 }); };
  $$('[data-req]').forEach(f => on(f, 'input', () => { if (f.classList.contains('err')) { f.classList.remove('err'); f.parentElement.querySelector('.err-msg')?.classList.remove('show'); } }));

  on($('[data-next]'), 'click', () => { if (validate($('#panel-delivery'))) showStep(stepIdx + 1); });
  on($('[data-back]'), 'click', () => showStep(stepIdx - 1));
  on($('[data-to-review]'), 'click', () => { if (validate($('#panel-payment'))) { buildReview(); showStep(2); } });

  function buildReview() {
    const box = $('[data-review]'); if (!box) return;
    const g = (id) => ($(`#${id}`)?.value || '').trim();
    const payName = $('input[name="payment"]:checked')?.dataset.label || '—';
    const shipName = SHIP_LABEL[shipMethod];
    box.innerHTML = `
      <h2 class="sr-only">Review your order</h2>
      <div class="card" style="margin-bottom:14px">
        <h3 style="font-size:1.05rem">Deliver to</h3>
        <p style="margin-top:8px">${g('co-name')} · ${g('co-phone')}<br>${g('co-email')}<br>${g('co-address')}, ${g('co-city')} ${g('co-zip')}</p>
      </div>
      <div class="grid g2" style="gap:14px">
        <div class="card"><h3 style="font-size:1.05rem">Payment</h3><p style="margin-top:8px">${payName}</p></div>
        <div class="card"><h3 style="font-size:1.05rem">Delivery</h3><p style="margin-top:8px">${shipName}</p></div>
      </div>
      <h3 style="margin:26px 0 12px">Order summary</h3>
      ${cart.map(i => `<div class="spec-row"><span>${i.qty} × ${i.name} <small>(${i.variant || 'Standard'})</small></span><b>${money(i.price * i.qty)}</b></div>`).join('')}
      ${totalsHTML()}`;
    const place = $('[data-place-order]');
    if (place) place.textContent = `Place order · ${money(total())}`;
  }

  on($('[data-place-order]'), 'click', async () => {
    const g = (id) => ($(`#${id}`)?.value || '').trim();
    const done = $('[data-order-done]');

    // 1) try the database first — the server recalculates every total itself
    let saved = null;
    if (DB.online && cart.length) {
      saved = await apiPost('/api/orders', {
        customer: {
          name: g('co-name'), email: g('co-email'), phone: g('co-phone'),
          address: g('co-address'), city: g('co-city'), zip: g('co-zip')
        },
        items: cart.map(i => ({ sku: i.sku, variant_sku: i.variantSku || '', name: i.name, variant: i.variant, unit_price: i.price, qty: i.qty })),
        payment_method: $('input[name="payment"]:checked')?.value || 'cod',
        shipping_method: shipMethod,
        coupon_code: coupNow,
        notes: g('co-notes')
      });
    }

    // 2) fall back to a local reference number when there is no database
    const id = saved?.order_no || 'BG-' + Date.now().toString(36).toUpperCase().slice(-6);
    const firstName = (g('co-name') || 'there').split(' ')[0];
    const payLabel = saved ? ($('input[name="payment"]:checked')?.dataset.label || '—') : ($('input[name="payment"]:checked')?.dataset.label || '—');
    const grandTotal = saved ? saved.total : total();

    if (done) {
      done.innerHTML = `<div class="order-done">
        <svg class="tick-big" viewBox="0 0 100 100"><circle cx="50" cy="50" r="44"/><path d="M32 52l13 13 24-26"/></svg>
        <h2>Order confirmed</h2>
        <p class="lead" style="margin-inline:auto">Salamat, ${firstName}! We emailed your receipt and we will text you the tracking link once your parcel leaves our shop.</p>
        <div class="order-id">${id}</div>
        <div class="grid g3" style="width:min(760px,100%);margin-top:10px">
          <div class="card"><h3 style="font-size:.98rem">Payment</h3><p>${payLabel}</p></div>
          <div class="card"><h3 style="font-size:.98rem">Delivery</h3><p>${SHIP_LABEL[shipMethod]}</p></div>
          <div class="card"><h3 style="font-size:.98rem">Total paid</h3><p>${money(grandTotal)}</p></div>
        </div>
        ${saved ? `<p class="hint" style="margin-top:6px">Saved to the Breezeguard database — it is already in your dashboard under Orders.</p>` : ''}
        <a class="btn btn-primary btn-lg" href="${pageUrl('products.html')}">Continue shopping</a>
      </div>`;
      done.style.display = 'block';
    }
    $('.co-flow')?.setAttribute('hidden', '');
    cart = []; coupNow = null; save();
    scrollTo({ top: 0, behavior: 'smooth' });
    confetti();
  });

  function confetti() {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const colors = ['#3fd68c', '#8cf0b6', '#ffc24b', '#ffffff'];
    for (let i = 0; i < 34; i++) {
      const p = document.createElement('i');
      const c = colors[i % colors.length];
      p.style.cssText = `position:fixed;z-index:220;top:-20px;left:${Math.random() * 100}vw;width:${6 + Math.random() * 7}px;height:${10 + Math.random() * 12}px;background:${c};border-radius:2px;pointer-events:none;transition:transform 1.6s cubic-bezier(.2,.7,.3,1),opacity 1.6s`;
      document.body.appendChild(p);
      requestAnimationFrame(() => {
        p.style.transform = `translate(${Math.random() * 200 - 100}px,${innerHeight + 120}px) rotate(${Math.random() * 720}deg)`;
        p.style.opacity = '0';
      });
      setTimeout(() => p.remove(), 1700);
    }
  }

  /* ---------- 7. UI WIDGETS ---------- */
  // coupon
  on($('[data-coupon]'), 'click', () => {
    const input = $('[data-coupon-input]');
    const code = (input?.value || '').trim().toUpperCase();
    const msg = $('[data-coupon-msg]');
    const known = Object.keys(COUPONS);
    coupNow = COUPONS[code] ? code : null;
    if (msg) {
      msg.textContent = coupNow
        ? `✓ ${code} applied — ${COUPONS[code].label}`
        : `That code is not valid${known.length ? '. Try ' + known.slice(0, 3).join(', ') + '.' : '.'}`;
      msg.style.color = coupNow ? 'var(--brand)' : 'var(--rose)';
      msg.classList.add('show');
    }
    if (coupNow) toast(`Coupon ${code} applied`);
    else if (code) toast('That code is not valid', 'err');
    save();
  });
  // Enter in the box should apply it too
  on($('[data-coupon-input]'), 'keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('[data-coupon]')?.click(); } });

  // tabs
  $$('.tab').forEach(t => on(t, 'click', () => {
    const group = t.closest('[data-tabs]') || document;
    $$('.tab', group).forEach(x => {
      x.classList.remove('on');
      if (x.hasAttribute('aria-selected')) x.setAttribute('aria-selected', 'false');
    });
    t.classList.add('on');
    t.setAttribute('aria-selected', 'true');
    $$('.tab-panel', group).forEach(p => p.hidden = p.dataset.panel !== t.dataset.tab);
  }));

  // testimonial carousel - the quotes come from the live review table, so this
  // rotates through what customers have actually written rather than three
  // hardcoded lines that never change
  const tstTrack = $('.tst-track'), tstDots = $('.dots');
  async function buildTestimonialSlides() {
    if (!tstTrack) return;
    // wait for boot to finish: DB.online is only set further down this file, and
    // apiGet refuses to call the API until then
    await new Promise(r => setTimeout(r, 0));
    try {
      const data = await apiGet('/api/reviews/all');
      const rows = data && Array.isArray(data.reviews)
        ? data.reviews.filter(r => r.is_published)
        : [];
      if (!rows.length) return;
      // local helpers: the ones in revInit are scoped inside that IIFE
      const mk = (tag, cls, text) => {
        const n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text != null) n.textContent = text;   // never innerHTML for user text
        return n;
      };
      const starStr = n => {
        const full = Math.max(0, Math.min(5, Math.round(Number(n) || 0)));
        return '★★★★★'.slice(0, full) + '☆☆☆☆☆'.slice(0, 5 - full);
      };
      tstTrack.textContent = '';
      for (const r of rows) {
        const slide = mk('div', 'tst');
        const who = mk('div', 'who');
        const meta = mk('div');
        meta.append(mk('b', null, r.author || 'Anonymous'));
        const sub = mk('small');
        sub.textContent = (r.is_verified ? 'verified buyer' : 'customer') + ' · ' + starStr(r.rating);
        meta.append(sub);
        who.append(mk('span', 'avatar', String(r.author || '?').trim().charAt(0).toUpperCase()), meta);
        slide.append(mk('blockquote', null, r.body), who);
        tstTrack.appendChild(slide);
      }
    } catch { /* keep whatever is already on screen */ }
  }
  const tstReady = buildTestimonialSlides();
  let slides = [], idx = 0, timer = null;
  const settle = () => { tstTrack.style.transform = `translateX(-${idx * 100}%)`; };
  const restart = () => { clearInterval(timer); timer = setInterval(() => go(idx + 1), 6500); };
  function go(i) {
    if (!slides.length) return;
    idx = (i + slides.length) % slides.length;
    settle();
    $$('button', tstDots).forEach((b, k) => b.classList.toggle('on', k === idx));
    restart();
  }
  function buildDots() {
    tstDots.textContent = '';
    slides.forEach((_, i) => {
      const b = document.createElement('button');
      b.setAttribute('aria-label', `Testimonial ${i + 1}`);
      if (!i) b.classList.add('on');
      on(b, 'click', () => go(i));
      tstDots.appendChild(b);
    });
  }
  function startCarousel() {
    slides = $$('.tst', tstTrack);
    if (!slides.length) return;
    buildDots();
    idx = 0;
    settle();
    restart();
  }
  // the review table changed in the dashboard, so the quotes must follow
  async function reloadTestimonials() {
    if (!tstTrack) return;
    await buildTestimonialSlides();
    startCarousel();
  }
  if (tstTrack && tstDots) {
    tstReady.then(startCarousel);

    /* Swipe with a mouse, a finger or a pen. Pointer events cover all three,
       so a trackpad drag and a phone flick both land on the same handler.
       Vertical movement is left alone so the page still scrolls normally. */
    let dragging = false, sx = 0, sy = 0, dx = 0, axis = null, t0 = 0;
    const width = () => tstTrack.getBoundingClientRect().width || 1;

    on(tstTrack, 'pointerdown', e => {
      if (e.button != null && e.button > 0) return;      // left button / finger / pen
      dragging = true; sx = e.clientX; sy = e.clientY; dx = 0; axis = null;
      t0 = performance.now();
      clearInterval(timer);
    });
    on(tstTrack, 'pointermove', e => {
      if (!dragging) return;
      dx = e.clientX - sx;
      const dy = e.clientY - sy;
      if (axis === null && (Math.abs(dx) > 6 || Math.abs(dy) > 6)) {
        axis = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y';
        if (axis === 'x') tstTrack.style.transition = 'none';   // follow the finger
      }
      if (axis !== 'x') return;
      // a light pull past the ends shows there is nothing more that way
      const limit = idx === 0 && dx > 0 ? 0.28 : idx === slides.length - 1 && dx < 0 ? 0.28 : 1;
      tstTrack.style.transform = `translateX(calc(-${idx * 100}% + ${dx * limit}px))`;
    });
    const release = () => {
      if (!dragging) return;
      dragging = false;
      tstTrack.style.transition = '';
      // far enough to count, or a quick short flick - a small slow nudge snaps back
      const wide = Math.abs(dx) > Math.max(45, width() * 0.15);
      const flick = Math.abs(dx) > 32 && (performance.now() - t0) < 320;
      if (axis === 'x' && (wide || flick)) go(idx + (dx < 0 ? 1 : -1));
      else { settle(); clearInterval(timer); timer = setInterval(() => go(idx + 1), 6500); }
      axis = null; dx = 0;
    };
    on(tstTrack, 'pointerup', release);
    on(tstTrack, 'pointercancel', release);
    on(tstTrack, 'pointerleave', release);
    // stop the drag from selecting the quote text
    on(tstTrack, 'dragstart', e => e.preventDefault());
  }

  /* "See how it works" drops the visitor straight onto the three numbered
     steps. A plain #hash jump teleports with no sense of where you went, so
     ease down to the section, then stagger the steps in one after another. */
  const howSteps = $$('#how .step, #how .steps > *');
  $$('a[href="#how"]').forEach(link => on(link, 'click', e => {
    e.preventDefault();
    const target = $('#how');
    if (!target) return;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const top = target.getBoundingClientRect().top + scrollY - 96;

    if (reduce) { scrollTo({ top, behavior: 'auto' }); }
    else {
      scrollTo({ top, behavior: 'smooth' });
      target.classList.add('steps-walked');
      setTimeout(() => target.classList.remove('steps-walked'), 1600);
    }
    if (howSteps.length) {
      howSteps.forEach((s, i) => {
        s.style.transitionDelay = (reduce ? 0 : 120 + i * 130) + 'ms';
        s.classList.remove('step-lit');
        void s.offsetWidth;                       // restart the animation
        s.classList.add('step-lit');
      });
    }
    // keep the URL shareable without the browser's instant jump
    history.replaceState(null, '', '#how');
  }));

  // countdown (48h rolling promo)
  const cd = $('[data-countdown]');
  if (cd) {
    let end = store.get('bg_promo_end', 0);
    if (!end || end < Date.now()) { end = Date.now() + 36 * 36e5; store.set('bg_promo_end', end); }
    const tick = () => {
      const left = Math.max(0, end - Date.now()), h = Math.floor(left / 36e5), m = Math.floor(left % 36e5 / 6e4), s = Math.floor(left % 6e4 / 1000);
      cd.innerHTML = `<span class="cd">${String(h).padStart(2, '0')}</span>:<span class="cd">${String(m).padStart(2, '0')}</span>:<span class="cd">${String(s).padStart(2, '0')}</span>`;
    };
    tick(); setInterval(tick, 1000);
  }

  /* ---------- bundle options on the product page ----------
     The device ships in a single colour (sage green), so there is no colour
     picker any more — only the "what's included" bundles to choose between. */
  const addBtn = $('.pdp [data-add]');
  const BUNDLE_HINT = {
    'Unit only': '1× Breezeguard Classic unit, USB-C cable, safety card.',
    'Unit + 10 pads': '1× Breezeguard Classic unit + 10 refill pads (about 3 months of nightly use).',
    'Unit + 20 pads': '1× Breezeguard Classic unit + 20 refill pads (about 6 months of nightly use).'
  };
  const pdpQty = () => {
    const n = parseInt($('[data-qty-value]')?.textContent || '1', 10);
    return Number.isFinite(n) && n > 0 ? n : 1;
  };
  /* set by the catalogue loader (section 8c) once prices arrive from the
     database; declared here so the assignment below is not a dead-zone error */
  let pdpSync = () => {};
  const pdp = addBtn ? {
    colour: addBtn.dataset.variant || 'Standard',
    note: 'Unit only',
    price: parseFloat(addBtn.dataset.price) || 0,
    sku: SKU[addBtn.dataset.id] || addBtn.dataset.sku || '',
    sync() {
      addBtn.dataset.price = this.price;
      // "Unit only" is just the base product, so it has to produce the same
      // cart line the product card does - otherwise buying from the card and
      // then from here puts the same item in the basket twice
      addBtn.dataset.variant = this.note === 'Unit only'
        ? this.colour
        : `${this.colour} · ${this.note}`;
      addBtn.dataset.sku = this.sku;
      addBtn.dataset.variantSku = this.sku;   // exact sellable option for the database
      const priceLabel = $('[data-price-label]', addBtn);
      // the button sells the whole quantity, so show the line total
      if (priceLabel) priceLabel.textContent = money(this.price * pdpQty());
      const bundleLabel = $('[data-bundle-label]');
      if (bundleLabel) bundleLabel.textContent = this.note;
      const hint = $('[data-bundle-hint]');
      if (hint) hint.textContent = BUNDLE_HINT[this.note] || BUNDLE_HINT['Unit only'];
    }
  } : null;

  // hand the catalogue a way to push a fresh price into this page
  pdpSync = (price) => {
    if (!pdp) return;
    if (price != null) pdp.price = price;
    pdp.sync();
  };

  // "What's included" bundles: Unit only / +10 pads / +20 pads
  $$('[data-option-group] [data-option]').forEach(btn => on(btn, 'click', () => {
    const group = btn.closest('[data-option-group]');
    $$('[data-option]', group).forEach(b => {
      b.classList.remove('is-on');
      b.setAttribute('aria-pressed', 'false');
    });
    btn.classList.add('is-on');
    btn.setAttribute('aria-pressed', 'true');
    if (pdp) {
      pdp.note = btn.dataset.note || btn.textContent.trim();
      pdp.price = parseFloat(btn.dataset.price) || pdp.price;
      pdp.sku = btn.dataset.sku || pdp.sku;
      pdp.sync();
    }
  }));

  // quantity steppers
  $$('[data-qty]').forEach(box => on(box, 'click', e => {
    const val = $('[data-qty-value]', box); if (!val) return;
    const step = e.target.closest('[data-step="up"]') ? 1 : e.target.closest('[data-step="down"]') ? -1 : 0;
    if (!step) return;
    let n = parseInt(val.textContent, 10) + step;
    n = Math.min(99, Math.max(1, n)); val.textContent = n;
    if (pdp) pdp.sync();   // the add-to-cart button sells the whole quantity
  }));

  // toasts
  const toastBox = $('.toasts');
  window.toast = (msg, kind) => {
    if (!toastBox) return;
    const err = kind === 'err';
    const t = document.createElement('div');
    t.className = 'toast' + (err ? ' err' : '');
    const icon = err
      ? '<path d="M12 8v5M12 16.5v.5"/><circle cx="12" cy="12" r="9"/>'
      : '<path d="m5 13 4 4L19 7"/>';
    t.innerHTML = `<span class="tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">${icon}</svg></span><span>${msg}</span>`;
    toastBox.appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 400); }, 3000);
  };

  /* ---------- 8. FORMS ----------
     Both the newsletter and the contact form write straight to the database.
     There is no "demo" path: the old code skipped the POST whenever the marker
     was absent and then showed the success message anyway, so a visitor could
     be told they were on the list while the address was thrown away. Now the
     POST always happens, and the success message only appears once the row is
     actually in the table. */
  $$('form[data-api], form[data-demo-form]').forEach(form => on(form, 'submit', async (e) => {
    e.preventDefault();
    if (!validate(form)) return;
    const btn = $('[type="submit"]', form);
    const html = btn.innerHTML;
    btn.disabled = true; btn.textContent = 'Saving…';
    const restore = () => { btn.disabled = false; btn.innerHTML = html; };
    const isContact = form.dataset.api === 'contact';
    const okMsg = form.dataset.saved || form.dataset.demoForm ||
      (isContact ? 'Thanks. We will reply within a working day.' : 'You are on the list.');

    const fields = Object.fromEntries(new FormData(form));
    let stored = false, failure = null, alreadyOnList = false;
    try {
      const res = await fetch(isContact ? '/api/contact' : '/api/subscribers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(isContact
          ? { name: fields.name, email: fields.email, topic: fields.topic || 'General', message: fields.message }
          : { email: fields.email, source: form.dataset.source || 'homepage' })
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        stored = true;
        // The address is in the table either way, but do not tell someone they
        // just signed up when they were already on the list and nothing was written.
        if (!isContact && data.already) alreadyOnList = true;
      }
      else failure = data.error || (isContact
        ? 'Could not send your message.'
        : 'Could not save your address.');
    } catch {
      failure = isContact
        ? 'Could not reach the server, so your message was not sent. Please email us directly.'
        : 'Could not reach the server, so your address was not saved.';
    }

    if (!stored) {
      // nothing was written, so do not pretend otherwise
      restore();
      toast(failure, 'err');
      return;
    }

    restore();
    form.reset();
    $$('[data-req]', form).forEach(f => f.classList.remove('err'));
    // a repeat signup is not a new signup - say so rather than claiming it was
    toast(alreadyOnList ? 'You were already on the list - nothing was duplicated.' : okMsg);
    $('[data-form-done]', form.parentElement)?.classList.add('show');
  }));

  /* ---------- 8b. REVIEWS / COMMENTS ---------- */

    /* Fill the headline figures from the database rather than leaving invented
       numbers in the markup. Anything we cannot actually measure is not shown
       at all - an invented "98% would recommend" is worse than no statistic. */
    async function paintRealStats() {
      const put = (sel, value) => $$(sel).forEach(n => { n.textContent = value; });
      try {
        const revs = await apiGet('/api/reviews/all');
        if (revs && typeof revs.total === 'number') {
          // count what a visitor can actually see - hiding a review in the
          // dashboard should drop the number on the page, not leave it stale
          const shown = revs.reviews.filter(r => r.is_published);
          put('[data-stat="reviews"]', String(shown.length));
          put('[data-stat="verified"]', String(shown.filter(r => r.is_verified).length));
          if (revs.average != null && Number.isFinite(Number(revs.average))) {
            const avg = Number(revs.average).toFixed(1);
            put('[data-stat="avg"]', avg);
            $('[data-stat-avg]').forEach(n => { n.textContent = avg; });
          } else {
            // no reviews yet, so there is no rating to quote
            put('[data-stat="avg"]', '—');
          }
          // per-product averages, so a card never claims a score it does not have
          const byProduct = {};
          for (const r of revs.reviews) {
            if (!r.is_published) continue;
            (byProduct[r.product_id] ||= []).push(Number(r.rating) || 0);
          }
          for (const [pid, list] of Object.entries(byProduct)) {
            const avg = list.reduce((n, x) => n + x, 0) / list.length;
            $$(`[data-stat-avg="${pid}"]`).forEach(n => { n.textContent = avg.toFixed(1); });
            // and the stars printed on each product card
            $$(`[data-card-stars="${pid}"]`).forEach(box => {
              const rounded = Math.max(0, Math.min(5, Math.round(avg)));
              const glyph = box.querySelector('[aria-hidden]');
              if (glyph) {
                glyph.textContent = '\u2605'.repeat(rounded) + '\u2606'.repeat(5 - rounded);
              }
              let sr = box.querySelector('.sr-only');
              if (sr) sr.textContent = `Rated ${avg.toFixed(1)} out of 5`;
              else {
                sr = document.createElement('span');
                sr.className = 'sr-only';
                sr.textContent = `Rated ${avg.toFixed(1)} out of 5`;
                box.appendChild(sr);
              }
            });
          }
        }
      } catch { /* leave the server-rendered fallback numbers alone */ }
      try {
        const st = await apiGet('/api/stats');
        if (st && st.kpis) put('[data-stat="customers"]', String(st.kpis.customers_total));
      } catch { /* ditto */ }

      /* Contact details are stored in settings, so the footer should read them
         from there rather than repeating a phone number in five HTML files.
         Only elements marked with data-live-phone/email are touched, and even
         then only when they hold nothing but text - the contact cards are
         anchors wrapping an icon and a heading, and overwriting those would
         erase the whole card. */
      try {
        const cfg = await apiGet('/api/settings');
        const fill = (sel, value) => $$(sel).forEach(n => {
          if (n.children.length === 0) n.textContent = value;
        });
        if (cfg && cfg.support_email) fill('[data-live-email]', cfg.support_email);
        if (cfg && cfg.support_phone) fill('[data-live-phone]', cfg.support_phone);
      } catch { /* keep the server-rendered contact details */ }
    }

    const revInit = (() => {
      const list = $('[data-rev-list]');
    const form = $('[data-rev-form]');
    if (!list && !form) return () => {};
    const msg = $('[data-rev-msg]');
    // this page is the Classic PDP, so reviews hang off the add-to-cart product id
    const PID = $('[data-add][data-id]')?.dataset.id || 'classic';

    const starsOf = n => {
      const full = Math.max(0, Math.min(5, Math.round(Number(n) || 0)));
      return '★★★★★'.slice(0, full) + '☆☆☆☆☆'.slice(0, 5 - full);
    };
    const when = iso => {
      const d = new Date(String(iso || '').replace(' ', 'T') + 'Z');
      const days = Math.floor((Date.now() - d.getTime()) / 864e5);
      if (!Number.isFinite(days)) return '';
      if (days <= 0) return 'today';
      if (days === 1) return 'yesterday';
      if (days < 30) return days + ' days ago';
      if (days < 365) { const m = Math.floor(days / 30); return m + ' month' + (m > 1 ? 's' : '') + ' ago'; }
      const y = Math.floor(days / 365); return y + ' year' + (y > 1 ? 's' : '') + ' ago';
    };
    const el = (tag, cls, text) => {
      const n = document.createElement(tag);
      if (cls) n.className = cls;
      if (text != null) n.textContent = text;   // never innerHTML for user text
      return n;
    };

    /* ---- star filter ----
       The breakdown bars double as the control: each row shows how many people
       gave that score AND filters the list to just those reviews. They are real
       <button> elements with aria-pressed rather than clickable divs, so they
       are reachable by keyboard and announced with their selected state. */
    let allReviews = [];
    let ratingFilter = 0;              // 0 means "show every rating"
    const filterNote = $('[data-rev-filter-note]');

    const setFilter = (stars) => {
      ratingFilter = ratingFilter === stars ? 0 : stars;   // clicking the active one clears it
      paintList();
      markActive();
    };

    function markActive() {
      $$('[data-stars]', $('[data-rev-bars]') || document).forEach(b => {
        const on = Number(b.dataset.stars) === ratingFilter;
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
    }

    function paintSummary(d) {
      const avg = d.average != null ? Number(d.average) : null;
      $$('[data-rev-average]').forEach(n => n.textContent = avg ? avg.toFixed(1) : '—');
      $$('[data-rev-count]').forEach(n => n.textContent = d.count);
      $$('[data-rev-plural]').forEach(n => n.textContent = d.count === 1 ? '' : 's');
      $$('[data-rev-stars]').forEach(n => { n.textContent = avg ? starsOf(avg) : ''; });

      const bars = $('[data-rev-bars]');
      if (!bars) return;
      bars.textContent = '';
      const b = d.breakdown || {};

      // "All ratings" reset row, so the filter is never a one-way door
      const all = el('button', 'rev-bar rev-bar-all');
      all.type = 'button';
      all.dataset.stars = '0';
      all.setAttribute('aria-pressed', ratingFilter === 0 ? 'true' : 'false');
      all.setAttribute('aria-label', 'All ratings, show all ' + (d.count || 0) +
        (d.count === 1 ? ' review' : ' reviews'));
      all.title = 'Clear the star filter';
      all.append(el('span', null, 'All'), el('em', 'rev-bar-track-all', ''),
        el('b', null, String(d.count || 0)));
      all.addEventListener('click', () => {
        ratingFilter = 0;
        paintList();
        markActive();
      });
      bars.append(all);

      [['five', '5 star', 5], ['four', '4 star', 4], ['three', '3 star', 3],
       ['two', '2 star', 2], ['one', '1 star', 1]].forEach(([k, label, stars]) => {
        const n = b[k] || 0;
        const row = el('button', 'rev-bar');
        row.type = 'button';
        row.dataset.stars = String(stars);
        row.setAttribute('aria-pressed', ratingFilter === stars ? 'true' : 'false');
        row.setAttribute('aria-label',
          stars + ' star, ' + n + (n === 1 ? ' review' : ' reviews'));
        const track = el('i');
        const fill = el('b');
        fill.style.width = (d.count ? Math.round(n / d.count * 100) : 0) + '%';
        track.append(fill);
        row.append(el('span', null, label), track, el('b', null, String(n)));
        row.addEventListener('click', () => setFilter(stars));
        bars.append(row);
      });
      markActive();
    }

    function paintList() {
      const reviews = ratingFilter
        ? allReviews.filter(r => Number(r.rating) === ratingFilter)
        : allReviews;

      if (filterNote) {
        filterNote.textContent = ratingFilter
          ? 'Showing ' + reviews.length + ' of ' + allReviews.length +
            ' review' + (allReviews.length === 1 ? '' : 's') + ' rated ' +
            ratingFilter + (ratingFilter === 1 ? ' star' : ' stars')
          : '';
      }

      list.textContent = '';
      if (!reviews.length) {
        list.append(el('p', 'rev-empty', ratingFilter
          ? 'No one has rated this ' + ratingFilter + (ratingFilter === 1 ? ' star' : ' stars') + ' yet.'
          : 'No reviews yet — be the first to write one.'));
        return;
      }
      reviews.forEach(r => {
        const art = el('article', 'review');
        const head = el('div', 'review-head');
        const stars = el('div', 'stars');
        const glyph = el('span', null, starsOf(r.rating));
        glyph.setAttribute('aria-hidden', 'true');
        stars.append(glyph, el('span', 'sr-only', `Rated ${r.rating} out of 5`));
        const who = el('div', 'review-who');
        who.append(el('b', null, r.author));
        if (r.is_verified) {
          const v = el('span', 'verified');
          v.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>Verified buyer';
          who.append(v);
        }
        head.append(stars, who, el('span', 'review-when', when(r.created_at)));
        art.append(head);
        if (r.title) art.append(el('h4', null, r.title));
        art.append(el('p', null, r.body));
        list.append(art);
      });
    }

    async function load() {
      const d = await apiGet(`/api/reviews?product=${encodeURIComponent(PID)}`);
      if (!d) {
        list.textContent = '';
        list.append(el('p', 'rev-empty', 'Reviews are unavailable right now. Please try again later.'));
        return;
      }
      paintSummary(d);
      allReviews = d.reviews || [];
      paintList();
    }

    form?.addEventListener('submit', async e => {
      e.preventDefault();
      const say = (text, kind) => {
        if (!msg) return;
        msg.textContent = text;
        msg.className = 'rev-msg mt-s' + (kind ? ' ' + kind : '');
      };
      const fd = new FormData(form);
      const payload = {
        product_id: PID,
        author: String(fd.get('author') || '').trim(),
        email: String(fd.get('email') || '').trim(),
        body: String(fd.get('body') || '').trim(),
        rating: Number(fd.get('rating') || 0)
      };
      const btn = $('button[type="submit"]', form);
      if (btn) { btn.disabled = true; btn.textContent = 'Posting…'; }
      try {
        const res = await fetch('/api/reviews', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => null);
        if (!res.ok) {
          say(data?.error || 'We could not post that review. Please try again.', 'err');
          return;
        }
        form.reset();
        $('input[name="rating"][value="5"]', form).checked = true;
        say(data.verified
          ? 'Thanks! Your review is live and marked as a verified purchase.'
          : 'Thanks! Your review is live.', 'ok');
        await load();
      } catch {
        say('Could not reach the server. Please try again.', 'err');
      } finally {
        if (btn) { btn.disabled = false; btn.textContent = 'Post review'; }
      }
    });

    return load;
  })();

  /* ---------- 8c. CATALOGUE PRICING ----------
     Prices live in the database. Everything on the page that shows a peso
     amount is repainted from /api/catalogue, so editing a price in the
     dashboard updates the shop instead of leaving the old number advertised. */
  const CATALOGUE = {};                       // storefront id -> product row
  const BY_SKU = {};                         // sku -> product row
  const VARIANTS = {};                        // variant sku  -> { label, price }
  const ID_BY_SKU = Object.fromEntries(Object.entries(SKU).map(([id, sku]) => [sku, id]));

  function paintPrices() {
    for (const el of $$('[data-price-for]')) {
      const p = CATALOGUE[el.dataset.priceFor];
      if (!p) continue;
      const now = $('b', el), was = $('s', el);
      if (now) now.textContent = money(p.price);
      if (was) {
        // a strikethrough only makes sense above the selling price
        const show = p.compare_price != null && p.compare_price > p.price;
        was.textContent = show ? money(p.compare_price) : '';
        was.hidden = !show;
      }
      // the little "Save ₱300" / "Save 19%" tag. Only badges explicitly marked
      // as saving tags are touched - "Outdoor" or "Travel" must survive.
      const badge = el.querySelector('[data-save-badge]') || el.parentElement?.querySelector('[data-save-badge]');
      if (badge) {
        const show = p.compare_price != null && p.compare_price > p.price;
        badge.hidden = !show;
        if (show) {
          const off = p.compare_price - p.price;
          badge.textContent = p.price < 1000 ? `Save ₱${off}` : `Save ${Math.round(off / p.compare_price * 100)}%`;
        }
      }
    }

    // add-to-cart buttons carry their own price, so the cart and the checkout
    // total stay in step with the database
    for (const btn of $$('[data-add][data-id]')) {
      const p = CATALOGUE[btn.dataset.id];
      if (p) btn.dataset.price = p.price;
    }
    // bundle options on the product page
    for (const chip of $$('[data-option][data-sku]')) {
      // the "Unit only" option shares its product's SKU, so the product price
      // is the one that counts there, not the stale copy in product_variants
      const own = BY_SKU[chip.dataset.sku];
      const v = VARIANTS[chip.dataset.sku];
      const price = own ? own.price : (v ? v.price : null);
      if (price == null) continue;
      chip.dataset.price = price;
      const span = $('span:last-of-type', chip);
      if (span && /^\D*₱[\d,]+/.test(span.textContent.trim())) span.textContent = money(price);
    }
    // the PDP keeps its own single source of truth
    const main = $('.pdp [data-add]');
    const p = main ? CATALOGUE[main.dataset.id] : null;
    if (p) pdpSync(p.price);
  }

  async function loadCatalogue() {
    const d = await apiGet('/api/catalogue');
    if (!d) return;
    absorbCatalogue(d);
  }
  function absorbCatalogue(d) {
    for (const p of d.products || []) {
      BY_SKU[p.sku] = p;
      const id = ID_BY_SKU[p.sku];
      if (id) CATALOGUE[id] = p;
    }
    for (const v of d.variants || []) VARIANTS[v.sku] = v;
    // the same payload carries stock, so sold-out state stays in step too
    STOCK.products = {};
    STOCK.options = {};
    for (const p of d.products || []) STOCK.products[p.sku] = p.stock;
    for (const v of d.variants || []) STOCK.options[v.sku] = v.stock;
    STOCK.on = true;
  }

  /* ---------- 8d. LIVE STOCK ----------
     Whatever the seller sets in the database wins: a product (or a bundle
     option) at zero stock is greyed out and cannot be added to the cart.     */
  const STOCK = { products: {}, options: {}, on: false };
  const stockOf = (idOrSku) => {
    const sku = SKU[idOrSku] || idOrSku;
    if (sku in STOCK.products) return STOCK.products[sku];
    if (sku in STOCK.options) return STOCK.options[sku];
    return null;              // unknown sku - leave the button alone
  };

  /* applyStock is reversible: it first undoes whatever the previous pass
     changed, so a product coming back into stock restores itself on its own. */
  function resetStock() {
    $$('.oos-tag, .stock-note, .oos-note').forEach(n => n.remove());
    $$('.is-oos').forEach(n => n.classList.remove('is-oos'));
    $$('[data-add]').forEach(btn => {
      btn.disabled = false;
      const label = $('[data-add-label]', btn);
      const orig = btn.dataset.origLabel;
      if (orig !== undefined) {
        if (label) label.textContent = orig;
        else btn.textContent = orig;
      }
      const price = $('[data-add-price]', btn);
      if (price) price.hidden = false;
    });
    $$('[data-qty] button').forEach(b => { b.disabled = false; });
    $$('[data-option]').forEach(c => { c.disabled = false; });
  }

  function applyStock() {
    if (!STOCK.on) return;
    resetStock();

    // product cards and any other add-to-cart button carrying a product id
    $$('[data-add][data-id]').forEach(btn => {
      const left = stockOf(btn.dataset.id);
      if (left === null || left > 0) return;
      btn.disabled = true;
      btn.classList.add('is-oos');
      const label = $('[data-add-label]', btn);
      if (btn.dataset.origLabel === undefined) {
        btn.dataset.origLabel = label ? label.textContent : btn.textContent;
      }
      if (label) label.textContent = 'Out of stock';
      else btn.textContent = 'Out of stock';
      const price = $('[data-add-price]', btn);
      if (price) price.hidden = true;
      const card = btn.closest('.p-card, .line-item, li');
      card?.classList.add('is-oos');
      const media = card?.querySelector('.p-media');
      if (media) {
        const tag = document.createElement('span');
        tag.className = 'oos-tag';
        tag.textContent = 'Out of stock';
        media.append(tag);
      }
    });

    // the product page: the whole unit, then each bundle option separately
    const main = $('.pdp [data-add]');
    if (main) {
      const left = stockOf(main.dataset.id);
      const oos = left !== null && left === 0;
      if (oos) {
        main.disabled = true;
        main.classList.add('is-oos');
        const label = $('[data-add-label]', main);
        if (main.dataset.origLabel === undefined) {
          main.dataset.origLabel = label ? label.textContent : main.textContent;
        }
        if (label) label.textContent = 'Out of stock';
        else main.textContent = 'Out of stock';
        const price = $('[data-add-price]', main);
        if (price) price.hidden = true;
        $('[data-qty]')?.querySelectorAll('button').forEach(b => { b.disabled = true; });
        const hint = $('[data-bundle-hint]');
        if (hint) {
          const note = document.createElement('p');
          note.className = 'stock-note';
          note.textContent = 'Currently out of stock. Message us and we will tell you when it is back.';
          hint.after(note);
        }
      }
      // bundle options that have no stock of their own
      $$('[data-option-group] [data-option]').forEach(chip => {
        const n = stockOf(chip.dataset.sku);
        if (n === null || n > 0) return;
        chip.disabled = true;
        chip.classList.add('is-oos');
        const noteEl = document.createElement('small');
        noteEl.className = 'oos-note';
        noteEl.textContent = 'sold out';
        chip.append(noteEl);
      });
    }
  }

  /* ---- polling ---------------------------------------------------------
     One endpoint carries prices, stock and bundle options, so a single
     request every 15 seconds keeps the whole shop live. Hidden tabs stop
     polling and refresh the moment they come back.                     */
  const STOCK_POLL_MS = 15000;
  let stockTimer = null;

  async function refreshLive(force) {
    const data = await apiGet('/api/catalogue');
    if (!data) return;
    const before = JSON.stringify([CATALOGUE, STOCK.options]);
    absorbCatalogue(data);
    const changed = force || before !== JSON.stringify([CATALOGUE, STOCK.options]);
    if (!changed) return;
    paintPrices();
    applyStock();
  }

  function startStockPolling() {
    refreshLive(true);
    if (stockTimer) return;
    stockTimer = setInterval(() => {
      if (document.visibilityState === 'visible') refreshLive(false);
    }, STOCK_POLL_MS);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') refreshLive(true);
    });
  }

  /* ---------- donate QR popup ----------
     Opens from the footer icon and the contact page card. Closes on the
     backdrop, the X, or Escape, and puts focus back where it came from. */
  {
    const qr = $('#qrModal');
    if (qr) {
      let lastFocus = null;
      const openQr = () => {
        lastFocus = document.activeElement;
        qr.hidden = false;
        document.body.style.overflow = 'hidden';
        $('[data-qr-close].qr-x', qr)?.focus();
      };
      const closeQr = () => {
        qr.hidden = true;
        document.body.style.overflow = '';
        if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
      };
      $$('[data-qr-open]').forEach(b => on(b, 'click', e => {
        e.preventDefault();
        if (qr.hidden) openQr();
      }));
      // if the QR file has not been added yet, say so rather than showing a
      // broken image. It loads while the dialog is still hidden, so the 404 can
      // land before this runs - check the current state too.
      const qrImg = $('.qr-frame img', qr);
      const frame = qrImg?.closest('.qr-frame');
      const showMissing = () => {
        if (!frame || frame.classList.contains('qr-missing')) return;
        frame.classList.add('qr-missing');
        frame.innerHTML = '<p>QR image not added yet.<br><span>Save it as <code>assets/img/qr-instapay.jpg</code></span></p>';
      };
      if (qrImg) {
        on(qrImg, 'error', showMissing);
        if (qrImg.complete && qrImg.naturalWidth === 0) showMissing();
      }
      $$('[data-qr-close]', qr).forEach(b => on(b, 'click', closeQr));
      on(document, 'keydown', e => {
        if (qr.hidden) return;
        if (e.key === 'Escape') { closeQr(); return; }
        if (e.key !== 'Tab') return;
        // keep Tab inside the dialog while it is open
        const f = $$('button, [href], img, [tabindex]:not([tabindex="-1"])', qr).filter(n => !n.disabled && n.offsetParent !== null);
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      });
    }
  }

  /* ---------- 9. BOOT ---------- */
  $$('[data-year]').forEach(el => el.textContent = new Date().getFullYear());
  paint();
  showStep(0);

  // Connect to the database when the page was served by breezeguard-db/server.mjs
  // (that server injects window.__BG_DB__). On a plain static host like Netlify
  // the flag is absent, so nothing is requested and the console stays clean.
  DB.online = !!window.__BG_DB__;
  if (DB.online) {
    document.documentElement.dataset.db = 'on';
    revInit();
    loadCatalogue();
    loadCoupons();
    watchCouponChanges();
    paintRealStats();
    startStockPolling();
    apiGet('/api/settings').then(s => {
      if (!s) return;
      if (Number.isFinite(Number(s.free_shipping_threshold))) FREE_SHIP = Number(s.free_shipping_threshold);
      if (Number.isFinite(Number(s.shipping_metro))) SHIP_RATES.metro = Number(s.shipping_metro);
      if (Number.isFinite(Number(s.shipping_provincial))) SHIP_RATES.provincial = Number(s.shipping_provincial);
      // figures printed in the help text read from the same settings row, so
      // changing a rate in the dashboard cannot leave a stale number behind
      const shipLive = { metro: SHIP_RATES.metro, provincial: SHIP_RATES.provincial, free: FREE_SHIP };
      $('[data-live-ship]').forEach(el => {
        const v = shipLive[el.dataset.liveShip];
        if (Number.isFinite(Number(v))) el.textContent = money(Number(v));
      });
      if (s.announcement) {
        const bar = $('.promo .wrap');
        if (bar) bar.textContent = s.announcement;
      }
      $$('[data-free-ship-note]').forEach(el => el.textContent = `Free shipping automatically applies over ${money(FREE_SHIP)}.`);
      paint();
    }).catch(() => { /* shop still works from localStorage */ });
  }
})();